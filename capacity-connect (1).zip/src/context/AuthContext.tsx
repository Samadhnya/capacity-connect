import React, { createContext, useContext, useState, useEffect } from 'react';
import { AuthContextType, UserProfile, SignupPayload } from '../types/auth';
import { UserRole } from '../types';
import { authService, INITIAL_ACCOUNTS } from '../services/authService';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [role, setRole] = useState<UserRole | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Initialize from storage or default to Trainee demo account
  useEffect(() => {
    try {
      const activeSession = authService.getCurrentSession();
      if (activeSession) {
        setUser(activeSession);
        setRole(activeSession.role);
      } else {
        // Seed default trainee demo account so initial load is ready
        const defaultTrainee = INITIAL_ACCOUNTS[0];
        const { passwordHash: _, ...profile } = defaultTrainee;
        setUser(profile);
        setRole(profile.role);
        localStorage.setItem('capacity_connect_auth_session', JSON.stringify(profile));
      }
    } catch (e) {
      console.error('Failed to init auth context:', e);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const login = async (
    email: string,
    password: string,
    selectedRole: UserRole,
    rememberMe = true
  ): Promise<{ success: boolean; error?: string }> => {
    setIsLoading(true);
    try {
      const result = await authService.login(email, password, selectedRole, rememberMe);
      if (result.success && result.user) {
        setUser(result.user);
        setRole(result.user.role);
        return { success: true };
      }
      return { success: false, error: result.error };
    } finally {
      setIsLoading(false);
    }
  };

  const signup = async (payload: SignupPayload): Promise<{ success: boolean; error?: string }> => {
    setIsLoading(true);
    try {
      const result = await authService.signup(payload);
      if (result.success && result.user) {
        setUser(result.user);
        setRole(result.user.role);
        return { success: true };
      }
      return { success: false, error: result.error };
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    authService.logout();
    setUser(null);
    setRole(null);
  };

  const updateProfile = (updatedData: Partial<UserProfile>) => {
    const updated = authService.updateUser(updatedData);
    if (updated) {
      setUser(updated);
      setRole(updated.role);
    }
  };

  const value: AuthContextType = {
    user,
    role,
    isAuthenticated: !!user,
    isLoading,
    login,
    signup,
    logout,
    updateProfile,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
