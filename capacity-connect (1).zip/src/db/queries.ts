import { db } from './index.ts';
import {
  users,
  enrollments,
  courses,
  courseModules,
  certificates,
  notifications,
  learningActivities,
  assessmentScores,
} from './schema.ts';
import { eq, desc, and, sql, asc } from 'drizzle-orm';

// -----------------------------------------------------------------------------
// USER QUERIES
// -----------------------------------------------------------------------------
export async function getTraineeProfile(identifier: string) {
  try {
    const found = await db
      .select()
      .from(users)
      .where(eq(users.email, identifier))
      .limit(1);

    if (found.length > 0) return found[0];

    const byUid = await db
      .select()
      .from(users)
      .where(eq(users.uid, identifier))
      .limit(1);

    return byUid[0] || null;
  } catch (error) {
    console.error('Error fetching user profile:', error);
    throw new Error('Database query failed while fetching user profile', { cause: error });
  }
}

export async function updateTraineeProfile(
  identifier: string,
  data: Partial<typeof users.$inferInsert>
) {
  try {
    const existing = await getTraineeProfile(identifier);
    if (!existing) {
      throw new Error(`User not found for identifier: ${identifier}`);
    }

    const updated = await db
      .update(users)
      .set({
        ...data,
        updatedAt: new Date(),
      })
      .where(eq(users.id, existing.id))
      .returning();

    return updated[0];
  } catch (error) {
    console.error('Error updating profile:', error);
    throw new Error('Database query failed while updating profile', { cause: error });
  }
}

// -----------------------------------------------------------------------------
// COURSE DISCOVERY & DETAILS QUERIES
// -----------------------------------------------------------------------------
export async function getAllCourses(userEmail?: string) {
  try {
    let currentUserId: number | null = null;
    if (userEmail) {
      const u = await getTraineeProfile(userEmail);
      if (u) currentUserId = u.id;
    }

    // Retrieve courses along with enrollment counts
    const allCourses = await db
      .select({
        id: courses.id,
        title: courses.title,
        code: courses.code,
        description: courses.description,
        trainerName: courses.trainerName,
        trainerId: courses.trainerId,
        category: courses.category,
        duration: courses.duration,
        level: courses.level,
        status: courses.status,
        rating: courses.rating,
        totalModules: courses.totalModules,
        createdAt: courses.createdAt,
        enrolledCount: sql<number>`(SELECT COUNT(*)::int FROM "enrollments" WHERE "enrollments"."course_id" = "courses"."id")`,
      })
      .from(courses)
      .orderBy(desc(courses.createdAt));

    // Get current user's enrollments to flag `isEnrolled` and `progress`
    let userEnrollmentMap: Record<string, { progress: number; status: string; completed: boolean }> = {};
    if (currentUserId) {
      const userEnrolls = await db
        .select()
        .from(enrollments)
        .where(eq(enrollments.userId, currentUserId));

      userEnrolls.forEach((e) => {
        userEnrollmentMap[e.courseId] = {
          progress: e.progress || 0,
          status: e.status || (e.completed ? 'COMPLETED' : (e.progress || 0) > 0 ? 'IN_PROGRESS' : 'NOT_STARTED'),
          completed: !!e.completed,
        };
      });
    }

    return allCourses.map((c) => ({
      ...c,
      isEnrolled: !!userEnrollmentMap[c.id],
      progress: userEnrollmentMap[c.id]?.progress || 0,
      enrollmentStatus: userEnrollmentMap[c.id]?.status || 'NOT_ENROLLED',
      completed: userEnrollmentMap[c.id]?.completed || false,
    }));
  } catch (error) {
    console.error('Error fetching all courses:', error);
    throw new Error('Database query failed while fetching courses', { cause: error });
  }
}

export async function getCourseById(courseId: string, userEmail?: string) {
  try {
    const courseRes = await db
      .select({
        id: courses.id,
        title: courses.title,
        code: courses.code,
        description: courses.description,
        trainerName: courses.trainerName,
        trainerId: courses.trainerId,
        category: courses.category,
        duration: courses.duration,
        level: courses.level,
        status: courses.status,
        rating: courses.rating,
        totalModules: courses.totalModules,
        createdAt: courses.createdAt,
        enrolledCount: sql<number>`(SELECT COUNT(*)::int FROM "enrollments" WHERE "enrollments"."course_id" = "courses"."id")`,
      })
      .from(courses)
      .where(eq(courses.id, courseId))
      .limit(1);

    if (courseRes.length === 0) return null;
    const course = courseRes[0];

    // Fetch modules
    const modules = await db
      .select()
      .from(courseModules)
      .where(eq(courseModules.courseId, courseId))
      .orderBy(asc(courseModules.moduleOrder));

    // Check user enrollment
    let enrollmentInfo: any = null;
    if (userEmail) {
      const u = await getTraineeProfile(userEmail);
      if (u) {
        const enrollRes = await db
          .select()
          .from(enrollments)
          .where(and(eq(enrollments.courseId, courseId), eq(enrollments.userId, u.id)))
          .limit(1);

        if (enrollRes.length > 0) {
          enrollmentInfo = enrollRes[0];
        }
      }
    }

    return {
      ...course,
      modules,
      isEnrolled: !!enrollmentInfo,
      progress: enrollmentInfo?.progress || 0,
      enrollmentStatus: enrollmentInfo?.status || 'NOT_ENROLLED',
      completed: enrollmentInfo?.completed || false,
      enrollmentDate: enrollmentInfo?.enrolledAt || null,
      lastActivity: enrollmentInfo?.lastActivity || null,
    };
  } catch (error) {
    console.error('Error fetching course by ID:', error);
    throw new Error('Database query failed while fetching course details', { cause: error });
  }
}

// -----------------------------------------------------------------------------
// ENROLLMENT QUERIES
// -----------------------------------------------------------------------------
export async function enrollTraineeInCourse(courseId: string, userEmail: string) {
  try {
    const user = await getTraineeProfile(userEmail);
    if (!user) {
      throw new Error('Authenticated trainee user not found');
    }

    const course = await db
      .select()
      .from(courses)
      .where(eq(courses.id, courseId))
      .limit(1);

    if (course.length === 0) {
      throw new Error(`Course with ID ${courseId} does not exist`);
    }

    // Check duplicate enrollment
    const existing = await db
      .select()
      .from(enrollments)
      .where(and(eq(enrollments.userId, user.id), eq(enrollments.courseId, courseId)))
      .limit(1);

    if (existing.length > 0) {
      return {
        alreadyEnrolled: true,
        enrollment: existing[0],
        message: 'Trainee is already enrolled in this course',
      };
    }

    // Insert new enrollment
    const inserted = await db
      .insert(enrollments)
      .values({
        userId: user.id,
        courseId,
        progress: 10, // Starting onboarding progress
        completed: false,
        status: 'IN_PROGRESS',
        lastActivity: 'Enrolled in program',
      })
      .returning();

    // Log learning activity
    await db.insert(learningActivities).values({
      userId: user.id,
      title: `Enrolled in ${course[0].title}`,
      description: `Commenced curriculum modules in ${course[0].category}`,
      timestamp: 'Just now',
      type: 'enrolled',
    });

    // Notify trainee
    await db.insert(notifications).values({
      userId: user.id,
      title: 'Course Enrollment Confirmed',
      message: `You have successfully enrolled in ${course[0].title} (${course[0].code}). Access learning resources and module tests from your workspace.`,
      type: 'success',
      date: 'Just now',
    });

    return {
      alreadyEnrolled: false,
      enrollment: inserted[0],
      message: 'Successfully enrolled in course',
    };
  } catch (error) {
    console.error('Error enrolling trainee in course:', error);
    throw error;
  }
}

export async function getTraineeEnrolledCourses(userId: number) {
  try {
    const enrolled = await db
      .select({
        enrollmentId: enrollments.id,
        courseId: courses.id,
        title: courses.title,
        code: courses.code,
        description: courses.description,
        trainerName: courses.trainerName,
        category: courses.category,
        duration: courses.duration,
        level: courses.level,
        status: courses.status,
        progress: enrollments.progress,
        completed: enrollments.completed,
        enrollmentStatus: enrollments.status,
        lastActivity: enrollments.lastActivity,
        enrolledAt: enrollments.enrolledAt,
        lastAccessedAt: enrollments.lastAccessedAt,
      })
      .from(enrollments)
      .innerJoin(courses, eq(enrollments.courseId, courses.id))
      .where(eq(enrollments.userId, userId))
      .orderBy(desc(enrollments.lastAccessedAt));

    return enrolled;
  } catch (error) {
    console.error('Error fetching trainee enrolled courses:', error);
    throw new Error('Database query failed while fetching enrolled courses', { cause: error });
  }
}

export async function updateCourseProgress(
  courseId: string,
  userEmail: string,
  progress: number,
  lastActivity?: string
) {
  try {
    const user = await getTraineeProfile(userEmail);
    if (!user) throw new Error('User not found');

    const completed = progress >= 100;
    const status = completed ? 'COMPLETED' : progress > 0 ? 'IN_PROGRESS' : 'NOT_STARTED';

    const updated = await db
      .update(enrollments)
      .set({
        progress,
        completed,
        status,
        lastActivity: lastActivity || (completed ? 'Curriculum completed' : 'Studied module'),
        lastAccessedAt: new Date(),
      })
      .where(and(eq(enrollments.userId, user.id), eq(enrollments.courseId, courseId)))
      .returning();

    return updated[0];
  } catch (error) {
    console.error('Error updating course progress:', error);
    throw error;
  }
}

// -----------------------------------------------------------------------------
// TRAINER COURSE MANAGEMENT QUERIES
// -----------------------------------------------------------------------------
export async function getTrainerCourses(trainerEmail: string) {
  try {
    const trainer = await getTraineeProfile(trainerEmail);
    if (!trainer) throw new Error('Trainer account not found');

    // Return courses created by this trainer or matching trainerName
    const myCourses = await db
      .select({
        id: courses.id,
        title: courses.title,
        code: courses.code,
        description: courses.description,
        trainerName: courses.trainerName,
        trainerId: courses.trainerId,
        category: courses.category,
        duration: courses.duration,
        level: courses.level,
        status: courses.status,
        rating: courses.rating,
        totalModules: courses.totalModules,
        createdAt: courses.createdAt,
        enrolledCount: sql<number>`(SELECT COUNT(*)::int FROM "enrollments" WHERE "enrollments"."course_id" = "courses"."id")`,
      })
      .from(courses)
      .where(sql`${courses.trainerId} = ${trainer.id} OR ${courses.trainerName} = ${trainer.name}`)
      .orderBy(desc(courses.createdAt));

    return myCourses;
  } catch (error) {
    console.error('Error fetching trainer courses:', error);
    throw error;
  }
}

export async function createCourse(
  trainerEmail: string,
  courseData: {
    title: string;
    description: string;
    category: string;
    duration: string;
    level: string;
    status?: string;
    modules?: string[];
  }
) {
  try {
    const trainer = await getTraineeProfile(trainerEmail);
    if (!trainer) throw new Error('Trainer account not found');

    const courseId = `c-${Date.now()}`;
    const code = `${courseData.category.substring(0, 3).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`;

    const newCourse = await db
      .insert(courses)
      .values({
        id: courseId,
        title: courseData.title,
        code,
        description: courseData.description,
        trainerName: trainer.name,
        trainerId: trainer.id,
        category: courseData.category,
        duration: courseData.duration || '6 Weeks',
        level: courseData.level || 'Intermediate',
        status: courseData.status || 'PUBLISHED',
        rating: '5.0',
        totalModules: courseData.modules ? courseData.modules.length : 3,
      })
      .returning();

    // Insert initial modules if provided
    if (courseData.modules && courseData.modules.length > 0) {
      const moduleInserts = courseData.modules.map((modTitle, idx) => ({
        courseId,
        title: modTitle,
        duration: '1 Week',
        moduleOrder: idx + 1,
        completed: false,
      }));
      await db.insert(courseModules).values(moduleInserts);
    }

    return newCourse[0];
  } catch (error) {
    console.error('Error creating course:', error);
    throw error;
  }
}

export async function updateCourse(
  courseId: string,
  trainerEmail: string,
  updateData: {
    title?: string;
    description?: string;
    category?: string;
    duration?: string;
    level?: string;
    status?: string;
  }
) {
  try {
    const trainer = await getTraineeProfile(trainerEmail);
    if (!trainer) throw new Error('Trainer account not found');

    // Ownership check: trainer must own the course or be Admin
    const targetCourse = await db
      .select()
      .from(courses)
      .where(eq(courses.id, courseId))
      .limit(1);

    if (targetCourse.length === 0) {
      throw new Error(`Course ${courseId} not found`);
    }

    const c = targetCourse[0];
    const isOwner = c.trainerId === trainer.id || c.trainerName === trainer.name || trainer.role === 'Admin';
    if (!isOwner) {
      throw new Error('Unauthorized: You can only modify courses authored by your account');
    }

    const updated = await db
      .update(courses)
      .set({
        ...updateData,
      })
      .where(eq(courses.id, courseId))
      .returning();

    return updated[0];
  } catch (error) {
    console.error('Error updating course:', error);
    throw error;
  }
}

export async function deleteCourse(courseId: string, trainerEmail: string) {
  try {
    const trainer = await getTraineeProfile(trainerEmail);
    if (!trainer) throw new Error('Trainer account not found');

    const targetCourse = await db
      .select()
      .from(courses)
      .where(eq(courses.id, courseId))
      .limit(1);

    if (targetCourse.length === 0) throw new Error(`Course ${courseId} not found`);

    const c = targetCourse[0];
    const isOwner = c.trainerId === trainer.id || c.trainerName === trainer.name || trainer.role === 'Admin';
    if (!isOwner) {
      throw new Error('Unauthorized: You can only delete courses authored by your account');
    }

    await db.delete(courses).where(eq(courses.id, courseId));
    return { success: true };
  } catch (error) {
    console.error('Error deleting course:', error);
    throw error;
  }
}

// -----------------------------------------------------------------------------
// MODULE QUERIES
// -----------------------------------------------------------------------------
export async function getCourseModules(courseId: string) {
  try {
    return await db
      .select()
      .from(courseModules)
      .where(eq(courseModules.courseId, courseId))
      .orderBy(asc(courseModules.moduleOrder));
  } catch (error) {
    console.error('Error fetching course modules:', error);
    throw error;
  }
}

export async function addCourseModule(
  courseId: string,
  trainerEmail: string,
  moduleData: { title: string; duration?: string; moduleOrder?: number }
) {
  try {
    const trainer = await getTraineeProfile(trainerEmail);
    if (!trainer) throw new Error('Trainer account not found');

    const targetCourse = await db
      .select()
      .from(courses)
      .where(eq(courses.id, courseId))
      .limit(1);

    if (targetCourse.length === 0) throw new Error(`Course ${courseId} not found`);

    const c = targetCourse[0];
    const isOwner = c.trainerId === trainer.id || c.trainerName === trainer.name || trainer.role === 'Admin';
    if (!isOwner) throw new Error('Unauthorized to add modules to this course');

    const inserted = await db
      .insert(courseModules)
      .values({
        courseId,
        title: moduleData.title,
        duration: moduleData.duration || '1 Week',
        moduleOrder: moduleData.moduleOrder || 1,
        completed: false,
      })
      .returning();

    // Increment course module count
    await db
      .update(courses)
      .set({
        totalModules: sql`${courses.totalModules} + 1`,
      })
      .where(eq(courses.id, courseId));

    return inserted[0];
  } catch (error) {
    console.error('Error adding course module:', error);
    throw error;
  }
}

export async function getCourseEnrolledTrainees(courseId: string) {
  try {
    const result = await db
      .select({
        enrollmentId: enrollments.id,
        progress: enrollments.progress,
        completed: enrollments.completed,
        status: enrollments.status,
        enrolledAt: enrollments.enrolledAt,
        lastAccessedAt: enrollments.lastAccessedAt,
        userId: users.id,
        name: users.name,
        email: users.email,
        phone: users.phone,
        department: users.department,
        designation: users.designation,
        division: users.division,
      })
      .from(enrollments)
      .innerJoin(users, eq(enrollments.userId, users.id))
      .where(eq(enrollments.courseId, courseId))
      .orderBy(desc(enrollments.enrolledAt));

    return result;
  } catch (error) {
    console.error('Error fetching course enrolled trainees:', error);
    throw error;
  }
}

// -----------------------------------------------------------------------------
// CERTIFICATES & NOTIFICATIONS QUERIES
// -----------------------------------------------------------------------------
export async function getTraineeCertificates(userId: number) {
  try {
    return await db
      .select()
      .from(certificates)
      .where(eq(certificates.userId, userId))
      .orderBy(desc(certificates.createdAt));
  } catch (error) {
    console.error('Error fetching certificates:', error);
    throw error;
  }
}

export async function getTraineeNotifications(userId: number) {
  try {
    return await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.id));
  } catch (error) {
    console.error('Error fetching notifications:', error);
    throw error;
  }
}

export async function markNotificationAsRead(notificationId: number, userId: number) {
  try {
    const updated = await db
      .update(notifications)
      .set({ read: true })
      .where(eq(notifications.id, notificationId))
      .returning();

    return updated[0];
  } catch (error) {
    console.error('Error marking notification as read:', error);
    throw error;
  }
}

// -----------------------------------------------------------------------------
// TRAINEE DASHBOARD AGGREGATE
// -----------------------------------------------------------------------------
export async function getTraineeDashboardData(userId: number) {
  try {
    const [enrolled, certs, notifs, activities, scores] = await Promise.all([
      getTraineeEnrolledCourses(userId),
      getTraineeCertificates(userId),
      getTraineeNotifications(userId),
      db
        .select()
        .from(learningActivities)
        .where(eq(learningActivities.userId, userId))
        .orderBy(desc(learningActivities.id))
        .limit(5),
      db
        .select()
        .from(assessmentScores)
        .where(eq(assessmentScores.userId, userId))
        .orderBy(desc(assessmentScores.id)),
    ]);

    const completedCoursesCount = enrolled.filter((c) => c.completed || c.progress === 100).length;
    const avgScore =
      scores.length > 0
        ? Math.round(
            scores.reduce((acc, s) => acc + (s.score / s.maxScore) * 100, 0) / scores.length
          )
        : 88;

    return {
      enrolledCourses: enrolled,
      totalEnrolledCount: enrolled.length,
      completedCoursesCount,
      activeCoursesCount: enrolled.length - completedCoursesCount,
      certificates: certs,
      certificatesCount: certs.length,
      notifications: notifs,
      unreadNotificationsCount: notifs.filter((n) => !n.read).length,
      recentActivities: activities,
      assessmentScores: scores,
      averageScorePercentage: avgScore,
    };
  } catch (error) {
    console.error('Error fetching trainee dashboard data:', error);
    throw error;
  }
}
