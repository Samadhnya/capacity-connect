import { relations } from 'drizzle-orm';
import { integer, pgTable, serial, text, timestamp, boolean } from 'drizzle-orm/pg-core';

// 1. Users Table (Stores Trainees, Trainers, Admins)
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(), // Auth unique identifier or ID
  email: text('email').notNull().unique(),
  name: text('name').notNull(),
  phone: text('phone'),
  role: text('role').notNull().default('Trainee'), // Trainee, Trainer, Admin
  department: text('department').default('India Meteorological Department (IMD)'),
  designation: text('designation').default('Meteorologist Grade-I'),
  division: text('division').default('National Weather Forecasting Centre (NWFC)'),
  location: text('location').default('Mausam Bhawan, Lodhi Road, New Delhi'),
  qualification: text('qualification'),
  workExperience: text('work_experience'),
  skills: text('skills'),
  interests: text('interests'),
  specialization: text('specialization'),
  employeeId: text('employee_id').default('IMD-ND-7842'),
  joiningYear: text('joining_year').default('2022'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// 2. Courses Table
export const courses = pgTable('courses', {
  id: text('id').primaryKey(), // e.g. 'c-1'
  title: text('title').notNull(),
  code: text('code').notNull(),
  description: text('description'),
  trainerName: text('trainer_name').notNull(),
  trainerId: integer('trainer_id').references(() => users.id),
  category: text('category').notNull(), // Meteorology, Oceanography, Climate Dynamics, Hydrology, Instrumentation
  duration: text('duration').notNull(),
  level: text('level').notNull(), // Beginner, Intermediate, Advanced
  status: text('status').default('PUBLISHED'), // DRAFT, PUBLISHED, ARCHIVED
  rating: text('rating').default('4.9'),
  totalModules: integer('total_modules').default(4),
  createdAt: timestamp('created_at').defaultNow(),
});

// 3. Course Modules Table
export const courseModules = pgTable('course_modules', {
  id: serial('id').primaryKey(),
  courseId: text('course_id')
    .references(() => courses.id, { onDelete: 'cascade' })
    .notNull(),
  title: text('title').notNull(),
  duration: text('duration').default('1 Week'),
  moduleOrder: integer('module_order').default(1),
  completed: boolean('completed').default(false),
  createdAt: timestamp('created_at').defaultNow(),
});

// 4. Trainee Course Enrollments Table
export const enrollments = pgTable('enrollments', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => users.id)
    .notNull(),
  courseId: text('course_id')
    .references(() => courses.id)
    .notNull(),
  progress: integer('progress').default(0), // 0 to 100 percentage
  completed: boolean('completed').default(false),
  status: text('status').default('IN_PROGRESS'), // NOT_STARTED, IN_PROGRESS, COMPLETED
  lastActivity: text('last_activity').default('Enrolled in program'),
  enrolledAt: timestamp('enrolled_at').defaultNow(),
  lastAccessedAt: timestamp('last_accessed_at').defaultNow(),
});

// 5. Assessment Submissions / Scores Table
export const assessmentScores = pgTable('assessment_scores', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => users.id)
    .notNull(),
  courseId: text('course_id')
    .references(() => courses.id)
    .notNull(),
  assessmentTitle: text('assessment_title').notNull(),
  score: integer('score').notNull(),
  maxScore: integer('max_score').notNull(),
  passed: boolean('passed').default(false),
  submittedAt: timestamp('submitted_at').defaultNow(),
});

// 6. Certificates Table
export const certificates = pgTable('certificates', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => users.id)
    .notNull(),
  courseId: text('course_id')
    .references(() => courses.id)
    .notNull(),
  courseName: text('course_name').notNull(),
  certificateNumber: text('certificate_number').notNull().unique(),
  issueDate: text('issue_date').notNull(),
  grade: text('grade').default('Distinction (A+)'),
  score: text('score').default('94%'),
  organization: text('organization').default('Ministry of Earth Sciences (MoES) - India Meteorological Department'),
  status: text('status').default('Issued'), // Issued, Pending, Verified
  createdAt: timestamp('created_at').defaultNow(),
});

// 7. Notifications Table
export const notifications = pgTable('notifications', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => users.id)
    .notNull(),
  title: text('title').notNull(),
  message: text('message').notNull(),
  type: text('type').default('info'), // info, success, warning, alert
  read: boolean('read').default(false),
  date: text('date').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

// 8. Recent Learning Activities Table
export const learningActivities = pgTable('learning_activities', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => users.id)
    .notNull(),
  title: text('title').notNull(),
  description: text('description').notNull(),
  timestamp: text('timestamp').notNull(),
  type: text('type').default('module_completed'), // module_completed, quiz_passed, enrolled, cert_earned
  createdAt: timestamp('created_at').defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  enrollments: many(enrollments),
  certificates: many(certificates),
  assessmentScores: many(assessmentScores),
  notifications: many(notifications),
  learningActivities: many(learningActivities),
  createdCourses: many(courses),
}));

export const coursesRelations = relations(courses, ({ one, many }) => ({
  trainer: one(users, {
    fields: [courses.trainerId],
    references: [users.id],
  }),
  enrollments: many(enrollments),
  modules: many(courseModules),
  certificates: many(certificates),
}));

export const courseModulesRelations = relations(courseModules, ({ one }) => ({
  course: one(courses, {
    fields: [courseModules.courseId],
    references: [courses.id],
  }),
}));

export const enrollmentsRelations = relations(enrollments, ({ one }) => ({
  user: one(users, {
    fields: [enrollments.userId],
    references: [users.id],
  }),
  course: one(courses, {
    fields: [enrollments.courseId],
    references: [courses.id],
  }),
}));
