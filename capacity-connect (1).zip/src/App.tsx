import React, { useState } from 'react';
import { AppPage, UserRole, Course, Assessment, Resource, AnnouncementItem } from './types';
import {
  initialCourses,
  initialResources,
  initialAssessments,
  initialCertificates,
  initialTrainees,
  initialTrainers,
  initialNotifications,
  initialAnnouncements,
  initialCompetencies,
} from './data/mockData';
import { useAuth } from './context/AuthContext';
import { ProtectedRoute } from './components/auth/ProtectedRoute';
import { INITIAL_ACCOUNTS } from './services/authService';
import { courseApiService } from './services/courseApiService';

// Layout components
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { DashboardLayout } from './components/layout/DashboardLayout';
import { AssessmentRunnerModal } from './components/common/AssessmentRunnerModal';

// Public pages
import { LandingPage } from './pages/public/LandingPage';
import { AboutPage } from './pages/public/AboutPage';
import { FeaturesPage } from './pages/public/FeaturesPage';
import { CourseCataloguePage } from './pages/public/CourseCataloguePage';
import { LoginPage } from './pages/public/LoginPage';
import { SignupPage } from './pages/public/SignupPage';
import { ForgotPasswordPage } from './pages/public/ForgotPasswordPage';

// Trainee pages
import { TraineeDashboard } from './pages/trainee/TraineeDashboard';
import { MyProfile } from './pages/trainee/MyProfile';
import { ExploreCourses } from './pages/trainee/ExploreCourses';
import { MyCourses } from './pages/trainee/MyCourses';
import { CourseDetails } from './pages/trainee/CourseDetails';
import { LearningResources } from './pages/trainee/LearningResources';
import { MCQAssessments } from './pages/trainee/MCQAssessments';
import { AssessmentResult } from './pages/trainee/AssessmentResult';
import { ProgressTracking } from './pages/trainee/ProgressTracking';
import { Certificates } from './pages/trainee/Certificates';
import { Feedback } from './pages/trainee/Feedback';
import { Notifications as TraineeNotifications } from './pages/trainee/Notifications';
import { Settings as TraineeSettings } from './pages/trainee/Settings';

// Trainer pages
import { TrainerDashboard } from './pages/trainer/TrainerDashboard';
import { TrainerProfile } from './pages/trainer/TrainerProfile';
import { TrainerCourses } from './pages/trainer/TrainerCourses';
import { CreateCourse } from './pages/trainer/CreateCourse';
import { EditCourse } from './pages/trainer/EditCourse';
import { Questionnaires } from './pages/trainer/Questionnaires';
import { CreateAssessment } from './pages/trainer/CreateAssessment';
import { TraineesList } from './pages/trainer/TraineesList';
import { TraineePerformance } from './pages/trainer/TraineePerformance';
import { TrainerLibrary } from './pages/trainer/TrainerLibrary';
import { UploadMaterial } from './pages/trainer/UploadMaterial';
import { TrainerNotifications } from './pages/trainer/TrainerNotifications';
import { TrainerSettings } from './pages/trainer/TrainerSettings';

// Admin pages
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { UserManagement } from './pages/admin/UserManagement';
import { AdminTrainees } from './pages/admin/AdminTrainees';
import { AdminTrainers } from './pages/admin/AdminTrainers';
import { AdminCourses } from './pages/admin/AdminCourses';
import { AdminEnrollments } from './pages/admin/AdminEnrollments';
import { AdminAssessments } from './pages/admin/AdminAssessments';
import { AdminCertifications } from './pages/admin/AdminCertifications';
import { CompetencyMapping } from './pages/admin/CompetencyMapping';
import { AdminNotifications } from './pages/admin/AdminNotifications';
import { AdminAnnouncements } from './pages/admin/AdminAnnouncements';
import { AdminAnalytics } from './pages/admin/AdminAnalytics';
import { AdminSettings } from './pages/admin/AdminSettings';

export default function App() {
  const { user, role, isAuthenticated, logout, login } = useAuth();

  // Navigation State
  const [currentPage, setCurrentPage] = useState<AppPage>('home');

  // Application Data State
  const [courses, setCourses] = useState<Course[]>(initialCourses);
  const [resources, setResources] = useState<Resource[]>(initialResources);
  const [assessments, setAssessments] = useState<Assessment[]>(initialAssessments);
  const [certificates, setCertificates] = useState(initialCertificates);
  const [trainees, setTrainees] = useState(initialTrainees);
  const [trainers, setTrainers] = useState(initialTrainers);
  const [notifications, setNotifications] = useState(initialNotifications);
  const [announcements, setAnnouncements] = useState(initialAnnouncements);
  const [competencies, setCompetencies] = useState(initialCompetencies);

  // Selected item states
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(courses[0]);
  const [selectedAssessment, setSelectedAssessment] = useState<Assessment | null>(assessments[0]);
  const [isQuizRunnerOpen, setIsQuizRunnerOpen] = useState(false);

  // Sync courses with PostgreSQL database on load and when user identity changes
  React.useEffect(() => {
    let isMounted = true;
    const syncDbCourses = async () => {
      try {
        const res = await courseApiService.getCourses(user?.email);
        if (res.courses && res.courses.length > 0 && isMounted) {
          const merged: Course[] = res.courses.map((dc) => {
            const match = initialCourses.find((fc) => fc.id === dc.id);
            return {
              id: dc.id,
              title: dc.title,
              description: dc.description || (match?.description ?? ''),
              trainer: dc.trainerName,
              trainerRole: match?.trainerRole || 'Scientist / Course Director',
              category: dc.category,
              duration: dc.duration,
              level: (dc.level as any) || 'Intermediate',
              rating: parseFloat(dc.rating) || 4.9,
              enrolledCount: dc.enrolledCount,
              modulesCount: dc.totalModules || 4,
              progress: dc.progress,
              isEnrolled: dc.isEnrolled,
              syllabus: match?.syllabus || [],
            };
          });
          setCourses(merged);
          if (merged.length > 0) {
            setSelectedCourse((prev) => merged.find((m) => m.id === prev?.id) || merged[0]);
          }
        }
      } catch (err) {
        console.warn('App: error syncing courses with database:', err);
      }
    };
    syncDbCourses();
    return () => {
      isMounted = false;
    };
  }, [user?.email]);

  // Quick switch role handler
  const handleRoleChange = async (targetRole: UserRole) => {
    const matchedAccount = INITIAL_ACCOUNTS.find((a) => a.role === targetRole);
    if (matchedAccount) {
      await login(matchedAccount.email, matchedAccount.passwordHash, targetRole, true);
    }
  };

  // Navigation dispatcher
  const navigateTo = (page: AppPage) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLogout = () => {
    logout();
    navigateTo('home');
  };

  const handleLoginSuccess = (userRole: UserRole) => {
    if (userRole === 'Trainee') navigateTo('trainee-dashboard');
    else if (userRole === 'Trainer') navigateTo('trainer-dashboard');
    else navigateTo('admin-dashboard');
  };

  // Course Actions
  const handleEnrollCourse = (courseId: string) => {
    setCourses((prev) =>
      prev.map((c) =>
        c.id === courseId
          ? { ...c, isEnrolled: true, progress: c.progress || 10, enrolledCount: c.enrolledCount + 1 }
          : c
      )
    );
  };

  const handleToggleModule = (courseId: string, moduleIndex: number) => {
    setCourses((prev) =>
      prev.map((c) => {
        if (c.id !== courseId) return c;
        const updatedSyllabus = c.syllabus.map((s, idx) =>
          idx === moduleIndex ? { ...s, completed: !s.completed } : s
        );
        const completedCount = updatedSyllabus.filter((s) => s.completed).length;
        const newProgress = Math.round((completedCount / updatedSyllabus.length) * 100);
        const updated = { ...c, syllabus: updatedSyllabus, progress: newProgress };
        if (selectedCourse?.id === courseId) {
          setSelectedCourse(updated);
        }
        return updated;
      })
    );
  };

  const handleAddCourse = (newCourse: Course) => {
    setCourses([newCourse, ...courses]);
  };

  const handleUpdateCourse = (updated: Course) => {
    setCourses(courses.map((c) => (c.id === updated.id ? updated : c)));
    if (selectedCourse?.id === updated.id) {
      setSelectedCourse(updated);
    }
  };

  // Assessment Actions
  const handleStartAssessment = (assessment: Assessment) => {
    setSelectedAssessment(assessment);
    setIsQuizRunnerOpen(true);
  };

  const handleAssessmentComplete = (score: number, maxScore: number) => {
    if (!selectedAssessment) return;
    const isPassed = score >= selectedAssessment.passingMarks;

    setAssessments((prev) =>
      prev.map((a) =>
        a.id === selectedAssessment.id
          ? { ...a, status: 'Completed', score, maxScore }
          : a
      )
    );

    // If passed, auto-issue certificate if not yet existing
    if (isPassed) {
      const alreadyHasCert = certificates.some(
        (cert) => cert.courseTitle === selectedAssessment.courseTitle
      );
      if (!alreadyHasCert) {
        const newCert = {
          id: `cert-${Date.now()}`,
          certificateNumber: `MoES-IMD-2026-${Math.floor(1000 + Math.random() * 9000)}`,
          courseTitle: selectedAssessment.courseTitle,
          recipientName: user?.name || 'Arjun Singhania',
          recipientRole: user?.designation || 'Meteorologist Grade-I',
          issueDate: new Date().toLocaleDateString('en-US', {
            month: 'long',
            day: 'numeric',
            year: 'numeric',
          }),
          score: `${Math.round((score / maxScore) * 100)}%`,
          grade: score / maxScore >= 0.9 ? 'Distinction (A+)' : 'Grade A',
          organization: 'Ministry of Earth Sciences (MoES) - India Meteorological Department',
        };
        setCertificates([newCert, ...certificates]);
      }
    }

    navigateTo('trainee-assessment-result');
  };

  // Resource Actions
  const handleUploadResource = (res: Resource) => {
    setResources([res, ...resources]);
  };

  // Announcement Actions
  const handleAddAnnouncement = (item: AnnouncementItem) => {
    setAnnouncements([item, ...announcements]);
  };

  // Notification Actions
  const handleToggleNotificationRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: !n.read } : n))
    );
  };

  const handleMarkAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  // Determine whether current view is a dashboard or a public page
  const isDashboardPage =
    currentPage.startsWith('trainee-') ||
    currentPage.startsWith('trainer-') ||
    currentPage.startsWith('admin-');

  // Active Role representation
  const activeRole: UserRole = role || 'Trainee';

  // Breadcrumbs Generator
  const getBreadcrumbs = () => {
    const root = { label: 'CAPACITY CONNECT', page: 'home' as AppPage };
    const roleLabel = activeRole;
    const roleDashPage: AppPage =
      activeRole === 'Trainee'
        ? 'trainee-dashboard'
        : activeRole === 'Trainer'
        ? 'trainer-dashboard'
        : 'admin-dashboard';
    const roleCrumb = { label: `${roleLabel} Portal`, page: roleDashPage };

    switch (currentPage) {
      case 'trainee-dashboard':
        return [root, { label: 'Trainee Dashboard' }];
      case 'trainee-profile':
        return [root, roleCrumb, { label: 'My Profile' }];
      case 'trainee-explore-courses':
        return [root, roleCrumb, { label: 'Explore Courses' }];
      case 'trainee-my-courses':
        return [root, roleCrumb, { label: 'My Courses' }];
      case 'trainee-course-details':
        return [
          root,
          roleCrumb,
          { label: 'My Courses', page: 'trainee-my-courses' as AppPage },
          { label: selectedCourse?.title || 'Course Details' },
        ];
      case 'trainee-learning-resources':
        return [root, roleCrumb, { label: 'Learning Resources' }];
      case 'trainee-mcq-assessments':
        return [root, roleCrumb, { label: 'MCQ Assessments' }];
      case 'trainee-assessment-result':
        return [
          root,
          roleCrumb,
          { label: 'MCQ Assessments', page: 'trainee-mcq-assessments' as AppPage },
          { label: 'Assessment Results' },
        ];
      case 'trainee-progress-tracking':
        return [root, roleCrumb, { label: 'Progress Tracking' }];
      case 'trainee-certificates':
        return [root, roleCrumb, { label: 'Certificates' }];
      case 'trainee-feedback':
        return [root, roleCrumb, { label: 'Feedback' }];
      case 'trainee-notifications':
        return [root, roleCrumb, { label: 'Notifications' }];
      case 'trainee-settings':
        return [root, roleCrumb, { label: 'Settings' }];

      case 'trainer-dashboard':
        return [root, { label: 'Trainer Dashboard' }];
      case 'trainer-profile':
        return [root, roleCrumb, { label: 'Trainer Profile' }];
      case 'trainer-my-courses':
        return [root, roleCrumb, { label: 'My Courses' }];
      case 'trainer-create-course':
        return [root, roleCrumb, { label: 'Create Course' }];
      case 'trainer-edit-course':
        return [root, roleCrumb, { label: 'Edit Course' }];
      case 'trainer-questionnaires':
        return [root, roleCrumb, { label: 'Questionnaires' }];
      case 'trainer-create-assessment':
        return [root, roleCrumb, { label: 'Create Assessment' }];
      case 'trainer-trainees':
        return [root, roleCrumb, { label: 'Trainees' }];
      case 'trainer-trainee-performance':
        return [root, roleCrumb, { label: 'Trainee Performance' }];
      case 'trainer-library':
        return [root, roleCrumb, { label: 'Trainer Library' }];
      case 'trainer-upload-material':
        return [root, roleCrumb, { label: 'Upload Learning Material' }];
      case 'trainer-notifications':
        return [root, roleCrumb, { label: 'Notifications' }];
      case 'trainer-settings':
        return [root, roleCrumb, { label: 'Settings' }];

      case 'admin-dashboard':
        return [root, { label: 'Admin Dashboard' }];
      case 'admin-users':
        return [root, roleCrumb, { label: 'User Management' }];
      case 'admin-trainees':
        return [root, roleCrumb, { label: 'Trainees' }];
      case 'admin-trainers':
        return [root, roleCrumb, { label: 'Trainers' }];
      case 'admin-courses':
        return [root, roleCrumb, { label: 'Courses' }];
      case 'admin-enrollments':
        return [root, roleCrumb, { label: 'Enrollments' }];
      case 'admin-assessments':
        return [root, roleCrumb, { label: 'Assessments' }];
      case 'admin-certifications':
        return [root, roleCrumb, { label: 'Certifications' }];
      case 'admin-competency-mapping':
        return [root, roleCrumb, { label: 'Competency Mapping' }];
      case 'admin-notifications':
        return [root, roleCrumb, { label: 'Notifications' }];
      case 'admin-announcements':
        return [root, roleCrumb, { label: 'Announcements' }];
      case 'admin-analytics':
        return [root, roleCrumb, { label: 'Analytics' }];
      case 'admin-settings':
        return [root, roleCrumb, { label: 'Settings' }];

      default:
        return [root];
    }
  };

  // Determine which role owns the target dashboard page
  const getRequiredRoleForPage = (page: AppPage): UserRole[] => {
    if (page.startsWith('trainee-')) return ['Trainee'];
    if (page.startsWith('trainer-')) return ['Trainer'];
    if (page.startsWith('admin-')) return ['Admin'];
    return ['Trainee', 'Trainer', 'Admin'];
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#f6faff] text-[#10243e]">
      {/* Top Navbar */}
      <Navbar
        currentPage={currentPage}
        currentRole={activeRole}
        isLoggedIn={isAuthenticated}
        onNavigate={navigateTo}
        onRoleChange={handleRoleChange}
        onLogout={handleLogout}
      />

      {/* Main Content Router */}
      <div className="flex-1 flex flex-col">
        {!isDashboardPage ? (
          /* Public Routed Pages */
          <div className="flex-1">
            {currentPage === 'home' && <LandingPage onNavigate={navigateTo} />}
            {currentPage === 'about' && <AboutPage onNavigate={navigateTo} />}
            {currentPage === 'features' && <FeaturesPage onNavigate={navigateTo} />}
            {currentPage === 'courses' && (
              <CourseCataloguePage
                courses={courses}
                onNavigate={navigateTo}
                onSelectCourse={setSelectedCourse}
                onEnroll={handleEnrollCourse}
              />
            )}
            {currentPage === 'login' && (
              <LoginPage onNavigate={navigateTo} onLoginSuccess={handleLoginSuccess} />
            )}
            {currentPage === 'signup' && (
              <SignupPage onNavigate={navigateTo} onSignupSuccess={handleLoginSuccess} />
            )}
            {currentPage === 'forgot-password' && (
              <ForgotPasswordPage onNavigate={navigateTo} />
            )}
          </div>
        ) : (
          /* Role-Protected Dashboard Layout & Routed Pages */
          <DashboardLayout
            currentRole={activeRole}
            currentPage={currentPage}
            onNavigate={navigateTo}
            onRoleChange={handleRoleChange}
            onLogout={handleLogout}
            breadcrumbsItems={getBreadcrumbs()}
            unreadNotificationsCount={unreadCount}
          >
            <ProtectedRoute
              allowedRoles={getRequiredRoleForPage(currentPage)}
              currentRole={role}
              isAuthenticated={isAuthenticated}
              onNavigate={navigateTo}
              onSwitchRole={handleRoleChange}
            >
              {/* TRAINEE ROUTES */}
              {currentPage === 'trainee-dashboard' && (
                <TraineeDashboard
                  courses={courses}
                  assessments={assessments}
                  onNavigate={navigateTo}
                  onSelectCourse={setSelectedCourse}
                  onStartAssessment={handleStartAssessment}
                />
              )}
              {currentPage === 'trainee-profile' && <MyProfile onNavigate={navigateTo} />}
              {currentPage === 'trainee-explore-courses' && (
                <ExploreCourses
                  courses={courses}
                  onNavigate={navigateTo}
                  onSelectCourse={setSelectedCourse}
                  onEnroll={handleEnrollCourse}
                />
              )}
              {currentPage === 'trainee-my-courses' && (
                <MyCourses
                  courses={courses}
                  onNavigate={navigateTo}
                  onSelectCourse={setSelectedCourse}
                />
              )}
              {currentPage === 'trainee-course-details' && (
                <CourseDetails
                  course={selectedCourse}
                  assessments={assessments}
                  onNavigate={navigateTo}
                  onStartAssessment={handleStartAssessment}
                  onToggleModule={handleToggleModule}
                />
              )}
              {currentPage === 'trainee-learning-resources' && (
                <LearningResources resources={resources} onNavigate={navigateTo} />
              )}
              {currentPage === 'trainee-mcq-assessments' && (
                <MCQAssessments
                  assessments={assessments}
                  onNavigate={navigateTo}
                  onStartAssessment={handleStartAssessment}
                />
              )}
              {currentPage === 'trainee-assessment-result' && (
                <AssessmentResult
                  assessments={assessments}
                  onNavigate={navigateTo}
                  onStartAssessment={handleStartAssessment}
                />
              )}
              {currentPage === 'trainee-progress-tracking' && (
                <ProgressTracking courses={courses} onNavigate={navigateTo} />
              )}
              {currentPage === 'trainee-certificates' && (
                <Certificates certificates={certificates} onNavigate={navigateTo} />
              )}
              {currentPage === 'trainee-feedback' && (
                <Feedback courses={courses} onNavigate={navigateTo} />
              )}
              {currentPage === 'trainee-notifications' && (
                <TraineeNotifications
                  notifications={notifications}
                  onNavigate={navigateTo}
                  onMarkAllRead={handleMarkAllNotificationsRead}
                  onToggleRead={handleToggleNotificationRead}
                />
              )}
              {currentPage === 'trainee-settings' && <TraineeSettings onNavigate={navigateTo} />}

              {/* TRAINER ROUTES */}
              {currentPage === 'trainer-dashboard' && (
                <TrainerDashboard
                  courses={courses}
                  trainees={trainees}
                  assessments={assessments}
                  onNavigate={navigateTo}
                  onSelectCourse={setSelectedCourse}
                />
              )}
              {currentPage === 'trainer-profile' && <TrainerProfile onNavigate={navigateTo} />}
              {currentPage === 'trainer-my-courses' && (
                <TrainerCourses
                  courses={courses}
                  onNavigate={navigateTo}
                  onSelectCourse={setSelectedCourse}
                />
              )}
              {currentPage === 'trainer-create-course' && (
                <CreateCourse onNavigate={navigateTo} onAddCourse={handleAddCourse} />
              )}
              {currentPage === 'trainer-edit-course' && (
                <EditCourse
                  course={selectedCourse}
                  onNavigate={navigateTo}
                  onUpdateCourse={handleUpdateCourse}
                />
              )}
              {currentPage === 'trainer-questionnaires' && (
                <Questionnaires
                  assessments={assessments}
                  onNavigate={navigateTo}
                  onSelectAssessment={setSelectedAssessment}
                />
              )}
              {currentPage === 'trainer-create-assessment' && (
                <CreateAssessment
                  courses={courses}
                  onNavigate={navigateTo}
                  onAddAssessment={(newAssessment) => setAssessments([newAssessment, ...assessments])}
                />
              )}
              {currentPage === 'trainer-trainees' && (
                <TraineesList trainees={trainees} onNavigate={navigateTo} />
              )}
              {currentPage === 'trainer-trainee-performance' && (
                <TraineePerformance
                  trainees={trainees}
                  onNavigate={navigateTo}
                />
              )}
              {currentPage === 'trainer-library' && (
                <TrainerLibrary
                  resources={resources}
                  onNavigate={navigateTo}
                />
              )}
              {currentPage === 'trainer-upload-material' && (
                <UploadMaterial onNavigate={navigateTo} onAddResource={handleUploadResource} />
              )}
              {currentPage === 'trainer-notifications' && (
                <TrainerNotifications
                  notifications={notifications}
                  onNavigate={navigateTo}
                  onMarkAllRead={handleMarkAllNotificationsRead}
                  onToggleRead={handleToggleNotificationRead}
                />
              )}
              {currentPage === 'trainer-settings' && <TrainerSettings onNavigate={navigateTo} />}

              {/* ADMIN ROUTES */}
              {currentPage === 'admin-dashboard' && (
                <AdminDashboard
                  courses={courses}
                  trainees={trainees}
                  trainers={trainers}
                  onNavigate={navigateTo}
                />
              )}
              {currentPage === 'admin-users' && (
                <UserManagement
                  trainees={trainees}
                  trainers={trainers}
                  onNavigate={navigateTo}
                />
              )}
              {currentPage === 'admin-trainees' && (
                <AdminTrainees trainees={trainees} onNavigate={navigateTo} />
              )}
              {currentPage === 'admin-trainers' && (
                <AdminTrainers trainers={trainers} onNavigate={navigateTo} />
              )}
              {currentPage === 'admin-courses' && (
                <AdminCourses
                  courses={courses}
                  onNavigate={navigateTo}
                  onSelectCourse={setSelectedCourse}
                />
              )}
              {currentPage === 'admin-enrollments' && (
                <AdminEnrollments
                  courses={courses}
                  trainees={trainees}
                  onNavigate={navigateTo}
                />
              )}
              {currentPage === 'admin-assessments' && (
                <AdminAssessments assessments={assessments} onNavigate={navigateTo} />
              )}
              {currentPage === 'admin-certifications' && (
                <AdminCertifications certificates={certificates} onNavigate={navigateTo} />
              )}
              {currentPage === 'admin-competency-mapping' && (
                <CompetencyMapping competencies={competencies} onNavigate={navigateTo} />
              )}
              {currentPage === 'admin-notifications' && (
                <AdminNotifications
                  notifications={notifications}
                  onNavigate={navigateTo}
                  onMarkAllRead={handleMarkAllNotificationsRead}
                  onToggleRead={handleToggleNotificationRead}
                />
              )}
              {currentPage === 'admin-announcements' && (
                <AdminAnnouncements
                  announcements={announcements}
                  onNavigate={navigateTo}
                  onAddAnnouncement={handleAddAnnouncement}
                />
              )}
              {currentPage === 'admin-analytics' && <AdminAnalytics onNavigate={navigateTo} />}
              {currentPage === 'admin-settings' && <AdminSettings onNavigate={navigateTo} />}
            </ProtectedRoute>
          </DashboardLayout>
        )}
      </div>

      {/* Global Interactive Assessment Quiz Modal */}
      <AssessmentRunnerModal
        assessment={selectedAssessment}
        isOpen={isQuizRunnerOpen}
        onClose={() => setIsQuizRunnerOpen(false)}
        onComplete={handleAssessmentComplete}
      />

      {/* Global Footer (shown on public pages and accessible at base) */}
      {!isDashboardPage && <Footer onNavigate={navigateTo} />}
    </div>
  );
}
