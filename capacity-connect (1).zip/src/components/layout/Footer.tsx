import React from 'react';
import { GraduationCap, ShieldCheck, Mail, Globe, MapPin } from 'lucide-react';
import { AppPage } from '../../types';

interface FooterProps {
  onNavigate: (page: AppPage) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer>
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 text-left mb-8 pb-8 border-b border-[#143e66]">
        {/* Brand Col */}
        <div className="md:col-span-1">
          <div className="flex items-center gap-2 mb-2">
            <GraduationCap className="text-[#58b9f0]" size={26} />
            <b className="text-lg text-white">CAPACITY CONNECT</b>
          </div>
          <p className="text-xs text-[#8faac2] leading-relaxed mb-3">
            Digital Capacity Building & Learning Management Portal for specialized meteorological, oceanographic, and climate research personnel.
          </p>
          <div className="flex items-center gap-2 text-[11px] text-[#58b9f0] bg-[#0c3154] px-2.5 py-1 rounded-md border border-[#174673] w-max">
            <ShieldCheck size={14} /> Problem Statement: 26075
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
            Navigation
          </h4>
          <ul className="space-y-2 text-xs p-0 m-0 list-none">
            <li>
              <button
                onClick={() => onNavigate('home')}
                className="hover:text-[#58b9f0] transition-colors cursor-pointer text-left"
              >
                Home
              </button>
            </li>
            <li>
              <button
                onClick={() => onNavigate('about')}
                className="hover:text-[#58b9f0] transition-colors cursor-pointer text-left"
              >
                About MoES & IMD
              </button>
            </li>
            <li>
              <button
                onClick={() => onNavigate('features')}
                className="hover:text-[#58b9f0] transition-colors cursor-pointer text-left"
              >
                Platform Features
              </button>
            </li>
            <li>
              <button
                onClick={() => onNavigate('courses')}
                className="hover:text-[#58b9f0] transition-colors cursor-pointer text-left"
              >
                Course Catalogue
              </button>
            </li>
          </ul>
        </div>

        {/* User Portals */}
        <div>
          <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
            Role Portals
          </h4>
          <ul className="space-y-2 text-xs p-0 m-0 list-none">
            <li>
              <button
                onClick={() => onNavigate('trainee-dashboard')}
                className="hover:text-[#58b9f0] transition-colors cursor-pointer text-left"
              >
                Trainee Learning Desk
              </button>
            </li>
            <li>
              <button
                onClick={() => onNavigate('trainer-dashboard')}
                className="hover:text-[#58b9f0] transition-colors cursor-pointer text-left"
              >
                Trainer Management Console
              </button>
            </li>
            <li>
              <button
                onClick={() => onNavigate('admin-dashboard')}
                className="hover:text-[#58b9f0] transition-colors cursor-pointer text-left"
              >
                Admin Governance Hub
              </button>
            </li>
            <li>
              <button
                onClick={() => onNavigate('login')}
                className="hover:text-[#58b9f0] transition-colors cursor-pointer text-left"
              >
                Portal Authentication
              </button>
            </li>
          </ul>
        </div>

        {/* Ministry Information */}
        <div>
          <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
            Institutional Oversight
          </h4>
          <div className="space-y-2 text-xs text-[#8faac2]">
            <p className="flex items-start gap-2 m-0">
              <MapPin size={14} className="text-[#58b9f0] shrink-0 mt-0.5" />
              <span>Mausam Bhawan, Lodhi Road, New Delhi 110003</span>
            </p>
            <p className="flex items-center gap-2 m-0">
              <Globe size={14} className="text-[#58b9f0] shrink-0" />
              <span>Ministry of Earth Sciences (MoES)</span>
            </p>
            <p className="flex items-center gap-2 m-0">
              <Mail size={14} className="text-[#58b9f0] shrink-0" />
              <span>capacity.connect@imd.gov.in</span>
            </p>
          </div>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row items-center justify-between text-xs text-[#738ea7] max-w-6xl mx-auto gap-2">
        <p className="m-0">
          © 2026 CAPACITY CONNECT – India Meteorological Department. All rights reserved.
        </p>
        <p className="m-0 text-[11px]">
          Smart Education & Capacity Building Initiative • Government of India
        </p>
      </div>
    </footer>
  );
};
