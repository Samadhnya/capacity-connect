import React, { useState } from 'react';
import {
  GraduationCap,
  LayoutDashboard,
  User,
  Compass,
  BookOpen,
  FileText,
  FileQuestion,
  Award,
  BarChart3,
  MessageSquare,
  Bell,
  Settings,
  PlusCircle,
  Edit3,
  Users,
  FolderArchive,
  UploadCloud,
  CheckCircle2,
  Shield,
  LogOut,
  Menu,
  X,
  Megaphone,
  Briefcase,
  TrendingUp,
} from 'lucide-react';
import { AppPage, UserRole } from '../../types';
import { Breadcrumbs } from '../common/Breadcrumbs';
import { useAuth } from '../../context/AuthContext';

interface SidebarItem {
  id: AppPage;
  label: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  badge?: number;
}

interface DashboardLayoutProps {
  currentRole: UserRole;
  currentPage: AppPage;
  onNavigate: (page: AppPage) => void;
  onRoleChange: (role: UserRole) => void;
  onLogout: () => void;
  children: React.ReactNode;
  breadcrumbsItems?: { label: string; page?: AppPage }[];
  showBack?: boolean;
  backPage?: AppPage;
  unreadNotificationsCount?: number;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({
  currentRole,
  currentPage,
  onNavigate,
  onRoleChange,
  onLogout,
  children,
  breadcrumbsItems,
  showBack,
  backPage,
  unreadNotificationsCount = 2,
}) => {
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const { user } = useAuth();

  // Trainee Navigation Items
  const traineeItems: SidebarItem[] = [
    { id: 'trainee-dashboard', label: 'Trainee Dashboard', icon: LayoutDashboard },
    { id: 'trainee-profile', label: 'My Profile', icon: User },
    { id: 'trainee-explore-courses', label: 'Explore Courses', icon: Compass },
    { id: 'trainee-my-courses', label: 'My Courses', icon: BookOpen },
    { id: 'trainee-course-details', label: 'Course Details', icon: FileText },
    { id: 'trainee-learning-resources', label: 'Learning Resources', icon: FolderArchive },
    { id: 'trainee-mcq-assessments', label: 'MCQ Assessments', icon: FileQuestion },
    { id: 'trainee-assessment-result', label: 'Assessment Result', icon: CheckCircle2 },
    { id: 'trainee-progress-tracking', label: 'Progress Tracking', icon: BarChart3 },
    { id: 'trainee-certificates', label: 'Certificates', icon: Award },
    { id: 'trainee-feedback', label: 'Feedback', icon: MessageSquare },
    { id: 'trainee-notifications', label: 'Notifications', icon: Bell, badge: unreadNotificationsCount },
    { id: 'trainee-settings', label: 'Settings', icon: Settings },
  ];

  // Trainer Navigation Items
  const trainerItems: SidebarItem[] = [
    { id: 'trainer-dashboard', label: 'Trainer Dashboard', icon: LayoutDashboard },
    { id: 'trainer-profile', label: 'Trainer Profile', icon: User },
    { id: 'trainer-my-courses', label: 'My Courses', icon: BookOpen },
    { id: 'trainer-create-course', label: 'Create Course', icon: PlusCircle },
    { id: 'trainer-edit-course', label: 'Edit Course', icon: Edit3 },
    { id: 'trainer-questionnaires', label: 'Questionnaires', icon: FileQuestion },
    { id: 'trainer-create-assessment', label: 'Create Assessment', icon: PlusCircle },
    { id: 'trainer-trainees', label: 'Trainees', icon: Users },
    { id: 'trainer-trainee-performance', label: 'Trainee Performance', icon: TrendingUp },
    { id: 'trainer-library', label: 'Trainer Library', icon: FolderArchive },
    { id: 'trainer-upload-material', label: 'Upload Learning Material', icon: UploadCloud },
    { id: 'trainer-notifications', label: 'Notifications', icon: Bell, badge: unreadNotificationsCount },
    { id: 'trainer-settings', label: 'Settings', icon: Settings },
  ];

  // Admin Navigation Items
  const adminItems: SidebarItem[] = [
    { id: 'admin-dashboard', label: 'Admin Dashboard', icon: LayoutDashboard },
    { id: 'admin-users', label: 'User Management', icon: Users },
    { id: 'admin-trainees', label: 'Trainees', icon: User },
    { id: 'admin-trainers', label: 'Trainers', icon: Briefcase },
    { id: 'admin-courses', label: 'Courses', icon: BookOpen },
    { id: 'admin-enrollments', label: 'Enrollments', icon: FileText },
    { id: 'admin-assessments', label: 'Assessments', icon: FileQuestion },
    { id: 'admin-certifications', label: 'Certifications', icon: Award },
    { id: 'admin-competency-mapping', label: 'Competency Mapping', icon: Shield },
    { id: 'admin-notifications', label: 'Notifications', icon: Bell, badge: unreadNotificationsCount },
    { id: 'admin-announcements', label: 'Announcements', icon: Megaphone },
    { id: 'admin-analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'admin-settings', label: 'Settings', icon: Settings },
  ];

  const currentItems =
    currentRole === 'Trainee'
      ? traineeItems
      : currentRole === 'Trainer'
      ? trainerItems
      : adminItems;

  const handleNavigate = (page: AppPage) => {
    onNavigate(page);
    setMobileSidebarOpen(false);
  };

  const handleRoleSwitch = (newRole: UserRole) => {
    onRoleChange(newRole);
    if (newRole === 'Trainee') onNavigate('trainee-dashboard');
    else if (newRole === 'Trainer') onNavigate('trainer-dashboard');
    else onNavigate('admin-dashboard');
    setMobileSidebarOpen(false);
  };

  return (
    <div className="layout">
      {/* Mobile sidebar overlay backdrop */}
      {mobileSidebarOpen && (
        <div
          className="fixed inset-0 bg-[#071e35]/70 z-40 lg:hidden"
          onClick={() => setMobileSidebarOpen(false)}
        />
      )}

      {/* Sidebar (Responsive for Desktop and Mobile Drawer) */}
      <aside
        className={`fixed lg:static top-0 bottom-0 left-0 z-50 w-64 lg:w-auto transition-transform duration-200 ease-in-out overflow-y-auto ${
          mobileSidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="flex items-center justify-between pb-3 lg:hidden">
          <span className="text-xs font-bold text-white uppercase tracking-wider">
            Menu Navigation
          </span>
          <button
            onClick={() => setMobileSidebarOpen(false)}
            className="text-white hover:text-[#58b9f0] p-1"
          >
            <X size={20} />
          </button>
        </div>

        {/* Brand in Sidebar */}
        <b>
          <div className="flex items-center gap-2">
            <GraduationCap size={22} />
            <span>CAPACITY CONNECT</span>
          </div>
          <small>LEARNING PORTAL</small>
          <div className="sidebar-role-badge">
            Role: {currentRole}
          </div>
        </b>

        {/* Authenticated User Badge Card */}
        {user && (
          <div className="mx-1 mb-3 p-2.5 bg-[#092644] rounded-xl border border-[#1b436e] text-left">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-[#0b63b6] text-white flex items-center justify-center font-bold text-xs shrink-0 border border-[#4ca4e6]">
                {user.name.split(' ').map((n) => n[0]).slice(0, 2).join('')}
              </div>
              <div className="overflow-hidden">
                <div className="text-xs font-bold text-white truncate">{user.name}</div>
                <div className="text-[10px] text-[#9fc7eb] truncate">{user.email}</div>
              </div>
            </div>
            <div className="mt-2 pt-2 border-t border-[#153a63] flex items-center justify-between text-[10px] text-[#6d9ac2]">
              <span className="truncate">{user.department?.split('-')[0] || 'MoES / IMD'}</span>
              <span className="px-1.5 py-0.5 rounded bg-[#103a64] text-[#a5d2fa] font-semibold text-[9px]">
                {user.role}
              </span>
            </div>
          </div>
        )}

        {/* Quick Role Switcher Inside Sidebar */}
        <div className="mb-3 px-1">
          <label className="text-[10px] font-bold text-[#6285a8] uppercase tracking-wider block mb-1">
            Active Role Workspace
          </label>
          <select
            value={currentRole}
            onChange={(e) => handleRoleSwitch(e.target.value as UserRole)}
            className="w-full bg-[#0d3861] text-[#e0efff] text-xs font-semibold py-1.5 px-2 rounded-lg border border-[#1b4b7a] focus:outline-none cursor-pointer"
          >
            <option value="Trainee">Trainee Area</option>
            <option value="Trainer">Trainer Area</option>
            <option value="Admin">Admin Area</option>
          </select>
        </div>

        {/* Navigation Items */}
        <div className="space-y-0.5">
          {currentItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavigate(item.id)}
                className={`side-btn ${isActive ? 'active' : ''}`}
              >
                <Icon size={17} />
                <span className="truncate">{item.label}</span>
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="badge-pill">{item.badge}</span>
                )}
              </button>
            );
          })}
        </div>

        {/* Logout button */}
        <button onClick={onLogout} className="side-btn logout text-[#ff7070] hover:text-[#ff9b9b] cursor-pointer">
          <LogOut size={17} />
          <span>Logout</span>
        </button>
      </aside>

      {/* Main Content Area */}
      <section className="dash min-h-screen flex flex-col">
        {/* Top bar with Breadcrumbs & Mobile Menu Trigger */}
        <div className="dash-topbar">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileSidebarOpen(true)}
              className="lg:hidden p-2 rounded-lg bg-white border border-[#dce8f3] text-[#082e52] hover:bg-[#f0f7ff]"
              title="Open Navigation"
            >
              <Menu size={18} />
            </button>
            {breadcrumbsItems && (
              <Breadcrumbs
                items={breadcrumbsItems}
                onNavigate={handleNavigate}
                showBack={showBack}
                backPage={backPage}
              />
            )}
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 bg-white px-3 py-1.5 rounded-full border border-[#dce8f3] text-xs font-semibold text-[#082e52]">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>Portal Live • IMD HQ</span>
            </div>

            {user && (
              <div className="hidden md:flex items-center gap-2 bg-white pl-2 pr-3 py-1 rounded-full border border-[#dce8f3]">
                <div className="w-6 h-6 rounded-full bg-[#0b63b6] text-white flex items-center justify-center text-[10px] font-bold">
                  {user.name[0]}
                </div>
                <div className="text-left leading-tight">
                  <div className="text-xs font-bold text-[#082e52]">{user.name}</div>
                  <div className="text-[9px] text-[#66798c]">{user.role}</div>
                </div>
              </div>
            )}

            <button
              onClick={() =>
                handleNavigate(
                  currentRole === 'Trainee'
                    ? 'trainee-notifications'
                    : currentRole === 'Trainer'
                    ? 'trainer-notifications'
                    : 'admin-notifications'
                )
              }
              className="relative p-2 rounded-lg bg-white border border-[#dce8f3] text-[#506579] hover:text-[#0b63b6] hover:bg-[#f0f7ff] cursor-pointer"
              title="Notifications"
            >
              <Bell size={17} />
              {unreadNotificationsCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white rounded-full text-[9px] font-bold flex items-center justify-center">
                  {unreadNotificationsCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Main Routed Page Content */}
        <div className="flex-1 pb-10">{children}</div>
      </section>
    </div>
  );
};
