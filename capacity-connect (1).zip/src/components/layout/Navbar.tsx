import React, { useState } from 'react';
import { GraduationCap, Menu, X, Shield, ArrowRight, UserCheck } from 'lucide-react';
import { AppPage, UserRole } from '../../types';

interface NavbarProps {
  currentPage: AppPage;
  currentRole: UserRole;
  isLoggedIn: boolean;
  onNavigate: (page: AppPage) => void;
  onRoleChange: (role: UserRole) => void;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentPage,
  currentRole,
  isLoggedIn,
  onNavigate,
  onRoleChange,
  onLogout,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const go = (page: AppPage) => {
    onNavigate(page);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const getDashboardPage = (role: UserRole): AppPage => {
    if (role === 'Trainee') return 'trainee-dashboard';
    if (role === 'Trainer') return 'trainer-dashboard';
    return 'admin-dashboard';
  };

  return (
    <nav>
      {/* Brand logo & title */}
      <button className="brand" onClick={() => go('home')}>
        <i>
          <GraduationCap size={24} />
        </i>
        <div>
          <b>
            CAPACITY<small>CONNECT</small>
          </b>
          <span className="hidden sm:inline-block text-[10px] text-[#66798c] font-medium leading-none">
            MoES • IMD Digital Portal
          </span>
        </div>
      </button>

      {/* Desktop Links */}
      <div className={`links ${mobileMenuOpen ? 'show' : ''}`}>
        <button
          className={`nav-link ${currentPage === 'home' ? 'active' : ''}`}
          onClick={() => go('home')}
        >
          Home
        </button>
        <button
          className={`nav-link ${currentPage === 'about' ? 'active' : ''}`}
          onClick={() => go('about')}
        >
          About MoES
        </button>
        <button
          className={`nav-link ${currentPage === 'features' ? 'active' : ''}`}
          onClick={() => go('features')}
        >
          Features
        </button>
        <button
          className={`nav-link ${currentPage === 'courses' ? 'active' : ''}`}
          onClick={() => go('courses')}
        >
          Catalogue
        </button>

        {isLoggedIn ? (
          <div className="flex items-center gap-3 border-l border-[#e7eef5] pl-3 ml-2 flex-wrap">
            {/* Quick Role Switcher for seamless testing across Trainee, Trainer, Admin */}
            <div className="flex items-center gap-1.5 bg-[#f0f7ff] px-2 py-1 rounded-lg border border-[#cde2f5]">
              <Shield size={13} className="text-[#0b63b6]" />
              <span className="text-[11px] font-bold text-[#082e52]">Role:</span>
              <select
                value={currentRole}
                onChange={(e) => {
                  const newRole = e.target.value as UserRole;
                  onRoleChange(newRole);
                  go(getDashboardPage(newRole));
                }}
                className="text-xs font-bold text-[#0b63b6] bg-transparent border-0 cursor-pointer focus:outline-none pr-1"
              >
                <option value="Trainee">Trainee</option>
                <option value="Trainer">Trainer</option>
                <option value="Admin">Admin</option>
              </select>
            </div>

            <button
              onClick={() => go(getDashboardPage(currentRole))}
              className="primary !py-2 !px-3.5 !text-xs cursor-pointer"
            >
              <UserCheck size={14} />
              <span>{currentRole} Portal</span>
            </button>

            <button
              onClick={() => go('login')}
              className="text-xs text-[#0b63b6] hover:text-[#08427b] font-semibold py-1.5 px-2 hover:bg-[#f0f7ff] rounded-md transition-colors cursor-pointer"
              title="Sign in with a different account"
            >
              Sign In
            </button>

            <button
              onClick={() => go('signup')}
              className="text-xs text-[#0b63b6] hover:text-[#08427b] font-semibold py-1.5 px-2 hover:bg-[#f0f7ff] rounded-md transition-colors cursor-pointer"
              title="Register a new trainee or trainer account"
            >
              Sign Up
            </button>

            <button
              onClick={onLogout}
              className="text-xs text-[#506579] hover:text-[#cf222e] font-semibold py-1.5 px-2 hover:bg-[#fff0f0] rounded-md transition-colors cursor-pointer"
            >
              Sign Out
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-2.5">
            <button
              className={`nav-link font-semibold ${currentPage === 'login' ? 'active' : ''}`}
              onClick={() => go('login')}
            >
              Sign In
            </button>
            <button
              className="primary !py-2 !px-4 !text-xs cursor-pointer inline-flex items-center gap-1.5"
              onClick={() => go('signup')}
            >
              <span>Sign Up</span>
              <ArrowRight size={13} />
            </button>
          </div>
        )}
      </div>

      {/* Hamburger for mobile */}
      <button
        className="hamb"
        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        aria-label="Toggle navigation"
      >
        {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
      </button>
    </nav>
  );
};
