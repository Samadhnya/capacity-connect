import React from 'react';
import { ChevronRight, ArrowLeft } from 'lucide-react';
import { AppPage } from '../../types';

interface BreadcrumbsProps {
  items: { label: string; page?: AppPage }[];
  onNavigate: (page: AppPage) => void;
  showBack?: boolean;
  backPage?: AppPage;
}

export const Breadcrumbs: React.FC<BreadcrumbsProps> = ({
  items,
  onNavigate,
  showBack,
  backPage,
}) => {
  return (
    <div className="flex items-center gap-2 text-xs text-[#66798c] flex-wrap">
      {showBack && backPage && (
        <button
          onClick={() => onNavigate(backPage)}
          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-white border border-[#dce8f3] text-[#082e52] hover:bg-[#f0f7ff] hover:text-[#0b63b6] font-semibold transition-colors mr-2 cursor-pointer shadow-xs"
          title="Go back"
        >
          <ArrowLeft size={13} />
          <span>Back</span>
        </button>
      )}

      {items.map((item, index) => {
        const isLast = index === items.length - 1;
        return (
          <React.Fragment key={index}>
            {index > 0 && <ChevronRight size={13} className="text-[#a4b5c6]" />}
            {item.page && !isLast ? (
              <button
                onClick={() => onNavigate(item.page!)}
                className="hover:text-[#0b63b6] hover:underline font-medium cursor-pointer"
              >
                {item.label}
              </button>
            ) : (
              <span className={isLast ? 'text-[#082e52] font-bold' : 'font-medium'}>
                {item.label}
              </span>
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
};
