import React, { useState } from 'react';
import { CheckCircle2, AlertCircle, HelpCircle, ArrowRight, ArrowLeft } from 'lucide-react';
import { Modal } from './Modal';
import { Assessment } from '../../types';

interface AssessmentRunnerModalProps {
  assessment: Assessment | null;
  isOpen: boolean;
  onClose: () => void;
  onComplete: (score: number, maxScore: number) => void;
}

export const AssessmentRunnerModal: React.FC<AssessmentRunnerModalProps> = ({
  assessment,
  isOpen,
  onClose,
  onComplete,
}) => {
  if (!assessment) return null;

  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const questions = assessment.questions;
  const currentQuestion = questions[currentIndex];

  const handleSelectOption = (optionIndex: number) => {
    if (isSubmitted) return;
    setSelectedAnswers((prev) => ({
      ...prev,
      [currentIndex]: optionIndex,
    }));
  };

  const calculateScore = () => {
    let correct = 0;
    questions.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.correctIndex) {
        correct++;
      }
    });
    return Math.round((correct / questions.length) * assessment.totalMarks);
  };

  const handleSubmit = () => {
    setIsSubmitted(true);
    const score = calculateScore();
    onComplete(score, assessment.totalMarks);
  };

  const handleReset = () => {
    setSelectedAnswers({});
    setIsSubmitted(false);
    setCurrentIndex(0);
  };

  const totalAnswered = Object.keys(selectedAnswers).length;
  const finalScore = isSubmitted ? calculateScore() : 0;
  const isPassed = isSubmitted && finalScore >= assessment.passingMarks;

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => {
        handleReset();
        onClose();
      }}
      title={assessment.title}
      subtitle={`Course: ${assessment.courseTitle} • Total Marks: ${assessment.totalMarks} (Pass: ${assessment.passingMarks})`}
      maxWidth="max-w-2xl"
    >
      {!isSubmitted ? (
        <div>
          {/* Progress bar */}
          <div className="mb-4">
            <div className="flex justify-between text-xs text-[#66798c] font-semibold mb-1">
              <span>Question {currentIndex + 1} of {questions.length}</span>
              <span>Answered: {totalAnswered} / {questions.length}</span>
            </div>
            <div className="w-full bg-[#e2ecf5] h-2 rounded-full overflow-hidden">
              <div
                className="bg-[#0b63b6] h-full transition-all duration-300"
                style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
              />
            </div>
          </div>

          {/* Question Box */}
          <div className="bg-[#fbfcff] border border-[#dce8f3] rounded-xl p-5 mb-5 shadow-xs">
            <span className="text-xs font-bold text-[#0b63b6] uppercase tracking-wide block mb-1">
              Question {currentIndex + 1}
            </span>
            <p className="text-base font-semibold text-[#082e52] m-0 leading-relaxed">
              {currentQuestion.question}
            </p>
          </div>

          {/* Options */}
          <div className="space-y-2.5 mb-6">
            {currentQuestion.options.map((option, optIdx) => {
              const isSelected = selectedAnswers[currentIndex] === optIdx;
              return (
                <label
                  key={optIdx}
                  onClick={() => handleSelectOption(optIdx)}
                  className={`flex items-start gap-3 p-3.5 rounded-xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'border-[#0b63b6] bg-[#eff7ff] shadow-xs'
                      : 'border-[#dce8f3] bg-white hover:bg-[#fafcff]'
                  }`}
                >
                  <input
                    type="radio"
                    name={`q-${currentIndex}`}
                    checked={isSelected}
                    onChange={() => handleSelectOption(optIdx)}
                    className="mt-0.5 text-[#0b63b6] accent-[#0b63b6] cursor-pointer"
                  />
                  <span className={`text-sm ${isSelected ? 'text-[#082e52] font-semibold' : 'text-[#30485f]'}`}>
                    {option}
                  </span>
                </label>
              );
            })}
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center justify-between pt-4 border-t border-[#edf2f6]">
            <button
              onClick={() => setCurrentIndex((prev) => Math.max(0, prev - 1))}
              disabled={currentIndex === 0}
              className="secondary text-xs font-semibold py-2 px-3 inline-flex items-center gap-1.5 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <ArrowLeft size={14} /> Previous
            </button>

            {currentIndex < questions.length - 1 ? (
              <button
                onClick={() => setCurrentIndex((prev) => Math.min(questions.length - 1, prev + 1))}
                className="primary text-xs font-semibold py-2 px-4 inline-flex items-center gap-1.5 cursor-pointer"
              >
                Next <ArrowRight size={14} />
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                disabled={totalAnswered < questions.length}
                className="primary text-xs font-bold py-2 px-5 inline-flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
              >
                Submit Assessment <CheckCircle2 size={14} />
              </button>
            )}
          </div>
        </div>
      ) : (
        /* Results View */
        <div className="py-2">
          <div className={`p-6 rounded-2xl text-center mb-6 border ${
            isPassed ? 'bg-emerald-50 border-emerald-200' : 'bg-amber-50 border-amber-200'
          }`}>
            {isPassed ? (
              <CheckCircle2 size={44} className="text-emerald-600 mx-auto mb-2" />
            ) : (
              <AlertCircle size={44} className="text-amber-600 mx-auto mb-2" />
            )}
            <h4 className="text-2xl font-bold text-[#082e52] mb-1">
              {isPassed ? 'Assessment Passed!' : 'Needs Improvement'}
            </h4>
            <p className="text-sm text-[#4d647a] mb-4">
              {isPassed
                ? 'Great work! You have satisfied the proficiency benchmark for this module.'
                : 'You scored below the passing mark. Review the explanations below and try again.'}
            </p>
            <div className="inline-flex items-center gap-6 bg-white px-6 py-3 rounded-xl border border-[#dce8f3] shadow-xs">
              <div>
                <span className="text-[10px] uppercase font-bold text-[#8295a7] block">Your Score</span>
                <span className="text-2xl font-black text-[#0b63b6]">{finalScore} / {assessment.totalMarks}</span>
              </div>
              <div className="border-l border-[#dce8f3] pl-6">
                <span className="text-[10px] uppercase font-bold text-[#8295a7] block">Passing Mark</span>
                <span className="text-lg font-bold text-[#082e52]">{assessment.passingMarks}</span>
              </div>
            </div>
          </div>

          <h5 className="text-sm font-bold text-[#082e52] mb-3 flex items-center gap-1.5">
            <HelpCircle size={16} className="text-[#0b63b6]" /> Detailed Answer Review
          </h5>

          <div className="space-y-4 max-h-72 overflow-y-auto pr-1">
            {questions.map((q, idx) => {
              const userChoice = selectedAnswers[idx];
              const isCorrect = userChoice === q.correctIndex;
              return (
                <div key={idx} className="p-3.5 rounded-xl border border-[#e2edf6] bg-white text-xs">
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <span className="font-bold text-[#082e52]">
                      Q{idx + 1}. {q.question}
                    </span>
                    <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                      isCorrect ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                    }`}>
                      {isCorrect ? 'Correct' : 'Incorrect'}
                    </span>
                  </div>
                  <p className="text-[#55697d] m-0 mb-1">
                    <span className="font-semibold">Your answer:</span> {q.options[userChoice] ?? 'Unanswered'}
                  </p>
                  {!isCorrect && (
                    <p className="text-emerald-700 m-0 mb-1">
                      <span className="font-semibold">Correct answer:</span> {q.options[q.correctIndex]}
                    </p>
                  )}
                  <p className="text-[#788ca0] italic m-0 pt-1 border-t border-[#f0f4f8]">
                    <span className="font-semibold">Explanation:</span> {q.explanation}
                  </p>
                </div>
              );
            })}
          </div>

          <div className="flex justify-end gap-2 mt-6 pt-4 border-t border-[#edf2f6]">
            <button
              onClick={handleReset}
              className="secondary text-xs font-semibold py-2 px-4 cursor-pointer"
            >
              Retake Assessment
            </button>
            <button
              onClick={onClose}
              className="primary text-xs font-bold py-2 px-4 cursor-pointer"
            >
              Close & Save
            </button>
          </div>
        </div>
      )}
    </Modal>
  );
};
