import React from 'react';
import { LucideIcon, Inbox } from 'lucide-react';

interface EmptyStateProps {
  icon?: LucideIcon;
  title: string;
  description: string;
  actionText?: string;
  onAction?: () => void;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon: Icon = Inbox,
  title,
  description,
  actionText,
  onAction,
}) => {
  return (
    <div className="bg-white border border-[#dce8f3] rounded-2xl p-10 text-center flex flex-col items-center justify-center my-6 shadow-xs">
      <div className="w-14 h-14 rounded-2xl bg-[#e8f5ff] text-[#0b63b6] flex items-center justify-center mb-4">
        <Icon size={28} />
      </div>
      <h3 className="text-lg font-bold text-[#082e52] m-0 mb-1.5">{title}</h3>
      <p className="text-sm text-[#66798c] max-w-md m-0 mb-5 leading-relaxed">
        {description}
      </p>
      {actionText && onAction && (
        <button
          onClick={onAction}
          className="primary text-sm font-semibold cursor-pointer"
        >
          {actionText}
        </button>
      )}
    </div>
  );
};
