import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { AppPage } from '../../types';

interface PageHeaderProps {
  badge?: string;
  title: string;
  subtitle?: string;
  actionText?: string;
  actionIcon?: React.ReactNode;
  onAction?: () => void;
  backPage?: AppPage;
  onBack?: (page: AppPage) => void;
  children?: React.ReactNode;
}

export const PageHeader: React.FC<PageHeaderProps> = ({
  badge,
  title,
  subtitle,
  actionText,
  actionIcon,
  onAction,
  backPage,
  onBack,
  children,
}) => {
  return (
    <div className="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#e7eef5] pb-5">
      <div>
        <div className="flex items-center gap-2 mb-1.5">
          {backPage && onBack && (
            <button
              onClick={() => onBack(backPage)}
              className="p-1 rounded-md text-[#506579] hover:bg-[#e7f5ff] hover:text-[#0b63b6] cursor-pointer transition-colors"
              title="Go back"
            >
              <ArrowLeft size={18} />
            </button>
          )}
          {badge && (
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-[#0b63b6] bg-[#e7f5ff] px-2.5 py-0.5 rounded-full border border-[#cbe6fa]">
              {badge}
            </span>
          )}
        </div>
        <h1 className="text-2xl md:text-3xl font-extrabold text-[#082e52] tracking-tight m-0">
          {title}
        </h1>
        {subtitle && (
          <p className="text-[#66798c] text-sm mt-1 mb-0 max-w-2xl leading-relaxed">
            {subtitle}
          </p>
        )}
      </div>

      <div className="flex items-center gap-3">
        {children}
        {actionText && onAction && (
          <button
            onClick={onAction}
            className="primary text-sm font-bold shadow-sm inline-flex items-center gap-2 cursor-pointer"
          >
            {actionIcon}
            <span>{actionText}</span>
          </button>
        )}
      </div>
    </div>
  );
};
