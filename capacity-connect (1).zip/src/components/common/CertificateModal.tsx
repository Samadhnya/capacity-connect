import React from 'react';
import { Award, Download, Printer, ShieldCheck, CheckCircle } from 'lucide-react';
import { Modal } from './Modal';
import { Certificate } from '../../types';

interface CertificateModalProps {
  certificate: Certificate | null;
  isOpen: boolean;
  onClose: () => void;
}

export const CertificateModal: React.FC<CertificateModalProps> = ({
  certificate,
  isOpen,
  onClose,
}) => {
  if (!certificate) return null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Verified Digital Certificate"
      subtitle="Ministry of Earth Sciences (MoES) - India Meteorological Department"
      maxWidth="max-w-3xl"
    >
      <div className="bg-[#fbfcff] border-2 border-[#c5dcf0] rounded-xl p-8 my-2 relative overflow-hidden text-center shadow-inner">
        {/* Certificate Watermark / Background Accent */}
        <div className="absolute top-0 left-0 right-0 h-3 bg-gradient-to-r from-[#082e52] via-[#0b63b6] to-[#29a9e8]" />
        
        <div className="flex items-center justify-center gap-2 text-xs font-bold tracking-widest text-[#0b63b6] uppercase mb-4 mt-2">
          <ShieldCheck size={16} /> Official Certificate of Competency Completion
        </div>

        <h2 className="text-2xl md:text-3xl font-serif text-[#082e52] font-black tracking-tight mb-1">
          CAPACITY CONNECT
        </h2>
        <p className="text-xs text-[#66798c] uppercase tracking-widest mb-6">
          National Capacity Building in Meteorological & Climate Sciences
        </p>

        <p className="text-sm text-[#4a5f73] italic mb-2">This is to certify that</p>
        <h3 className="text-2xl font-bold text-[#082e52] mb-1 font-serif underline decoration-[#0b63b6] underline-offset-8">
          {certificate.recipientName}
        </h3>
        <p className="text-xs text-[#66798c] mb-6 font-medium">
          {certificate.recipientRole}
        </p>

        <p className="text-sm text-[#4a5f73] max-w-lg mx-auto leading-relaxed mb-4">
          has successfully undertaken rigorous professional coursework, laboratory modules, and evaluation assessments for:
        </p>

        <div className="bg-white border border-[#dce8f3] rounded-lg py-3 px-6 inline-block my-2 shadow-xs">
          <span className="text-base font-bold text-[#0b63b6] block">
            {certificate.courseTitle}
          </span>
          <span className="text-xs text-[#66798c] font-semibold">
            Result: {certificate.score} • {certificate.grade}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-4 mt-8 pt-6 border-t border-[#e2eef7] text-left text-xs text-[#506579]">
          <div>
            <span className="block text-[#8295a7] font-semibold text-[10px] uppercase">Certificate Number</span>
            <span className="font-mono font-bold text-[#082e52] text-xs">{certificate.certificateNumber}</span>
            <span className="block mt-1 text-[#8295a7] font-semibold text-[10px] uppercase">Issued Date</span>
            <span className="font-medium text-[#082e52]">{certificate.issueDate}</span>
          </div>
          <div className="text-right flex flex-col items-end justify-end">
            <div className="inline-flex items-center gap-1 text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full text-[11px] font-bold border border-emerald-200 mb-2">
              <CheckCircle size={13} /> Tamper-Proof Cryptographic ID
            </div>
            <p className="text-[10px] text-[#8295a7] m-0 font-medium">
              MoES Central Certification Registry
            </p>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between mt-6 pt-4 border-t border-[#edf2f6] gap-3">
        <span className="text-xs text-[#66798c]">
          Verified against IMD Smart Education Framework
        </span>
        <div className="flex gap-2">
          <button
            onClick={() => window.print()}
            className="secondary text-xs font-semibold py-2 px-3 inline-flex items-center gap-1.5 cursor-pointer"
          >
            <Printer size={14} /> Print
          </button>
          <button
            onClick={() => {
              alert(`Certificate ${certificate.certificateNumber} downloaded as PDF.`);
            }}
            className="primary text-xs font-bold py-2 px-4 inline-flex items-center gap-1.5 cursor-pointer"
          >
            <Download size={14} /> Download PDF
          </button>
        </div>
      </div>
    </Modal>
  );
};
