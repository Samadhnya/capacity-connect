import React from 'react';
import { ShieldAlert, ArrowLeft, LogIn, Lock, Home } from 'lucide-react';
import { AppPage, UserRole } from '../../types';

interface UnauthorizedPageProps {
  requiredRole: UserRole | string;
  currentRole: UserRole | null;
  onNavigate: (page: AppPage) => void;
  onSwitchRole?: (role: UserRole) => void;
}

export const UnauthorizedPage: React.FC<UnauthorizedPageProps> = ({
  requiredRole,
  currentRole,
  onNavigate,
  onSwitchRole,
}) => {
  const getDashboardPage = (role: UserRole | null): AppPage => {
    if (role === 'Trainee') return 'trainee-dashboard';
    if (role === 'Trainer') return 'trainer-dashboard';
    if (role === 'Admin') return 'admin-dashboard';
    return 'login';
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-6 bg-[#f6faff]">
      <div className="max-w-lg w-full bg-white rounded-2xl shadow-xl border border-[#d6e4f0] p-8 text-center animate-fade-in">
        <div className="w-16 h-16 bg-amber-50 border border-amber-200 text-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-5 shadow-inner">
          <ShieldAlert size={36} />
        </div>

        <span className="inline-block px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-rose-50 text-rose-600 border border-rose-200 mb-3">
          403 Access Forbidden
        </span>

        <h1 className="text-2xl font-black text-[#082e52] mb-3">
          Institutional Access Restricted
        </h1>

        <p className="text-sm text-[#506579] leading-relaxed mb-6">
          You are currently signed in as a <strong className="text-[#082e52]">{currentRole || 'Guest'}</strong>.
          The requested page requires verified <strong className="text-[#0b63b6]">{requiredRole}</strong> credentials
          under Ministry of Earth Sciences security policy.
        </p>

        <div className="bg-[#f0f7ff] border border-[#cde2f5] rounded-xl p-4 mb-6 text-left text-xs text-[#082e52] space-y-1.5">
          <div className="font-bold flex items-center gap-1.5 text-[#0b63b6]">
            <Lock size={14} /> Security Compliance Notice
          </div>
          <div>• Role-based access control enforces data segregation between trainees, mentors, and administrators.</div>
          <div>• To access this workspace, please log in with authorized {requiredRole} institutional credentials.</div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
          {currentRole ? (
            <button
              onClick={() => onNavigate(getDashboardPage(currentRole))}
              className="primary w-full sm:w-auto !py-2.5 !px-5 !text-xs cursor-pointer inline-flex items-center justify-center gap-2"
            >
              <ArrowLeft size={14} />
              Return to My {currentRole} Dashboard
            </button>
          ) : (
            <button
              onClick={() => onNavigate('login')}
              className="primary w-full sm:w-auto !py-2.5 !px-5 !text-xs cursor-pointer inline-flex items-center justify-center gap-2"
            >
              <LogIn size={14} /> Sign In
            </button>
          )}

          {onSwitchRole && (
            <button
              onClick={() => {
                onSwitchRole(requiredRole as UserRole);
                onNavigate(getDashboardPage(requiredRole as UserRole));
              }}
              className="secondary w-full sm:w-auto !py-2.5 !px-5 !text-xs cursor-pointer inline-flex items-center justify-center gap-2 font-bold"
            >
              Switch to {requiredRole} Account
            </button>
          )}

          <button
            onClick={() => onNavigate('home')}
            className="text text-xs text-[#506579] hover:text-[#0b63b6] font-semibold py-2 px-3 inline-flex items-center gap-1 cursor-pointer"
          >
            <Home size={14} /> Portal Home
          </button>
        </div>
      </div>
    </div>
  );
};
