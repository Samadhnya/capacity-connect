import React from 'react';
import { UserRole, AppPage } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { UnauthorizedPage } from './UnauthorizedPage';

interface ProtectedRouteProps {
  allowedRoles: UserRole[];
  currentRole: UserRole | null;
  isAuthenticated: boolean;
  onNavigate: (page: AppPage) => void;
  onSwitchRole?: (role: UserRole) => void;
  children: React.ReactNode;
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  allowedRoles,
  currentRole,
  isAuthenticated,
  onNavigate,
  onSwitchRole,
  children,
}) => {
  // 1. If not authenticated, require login
  if (!isAuthenticated) {
    return (
      <div className="min-h-[75vh] flex items-center justify-center p-6 bg-[#f6faff]">
        <div className="max-w-md w-full bg-white rounded-2xl p-8 border border-[#d6e4f0] shadow-lg text-center">
          <div className="w-14 h-14 bg-[#e8f5ff] text-[#0b63b6] rounded-2xl flex items-center justify-center mx-auto mb-4">
            <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
          <h2 className="text-xl font-bold text-[#082e52] mb-2">Authentication Required</h2>
          <p className="text-xs text-[#506579] mb-6">
            Please sign in with your official MoES/IMD credentials to access this protected portal section.
          </p>
          <button
            onClick={() => onNavigate('login')}
            className="primary w-full !py-2.5 !text-xs cursor-pointer font-bold"
          >
            Go to Sign In
          </button>
        </div>
      </div>
    );
  }

  // 2. Role Check
  if (currentRole && !allowedRoles.includes(currentRole)) {
    return (
      <UnauthorizedPage
        requiredRole={allowedRoles[0]}
        currentRole={currentRole}
        onNavigate={onNavigate}
        onSwitchRole={onSwitchRole}
      />
    );
  }

  return <>{children}</>;
};
