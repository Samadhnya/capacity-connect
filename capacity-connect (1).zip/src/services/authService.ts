import { UserProfile, SignupPayload } from '../types/auth';
import { UserRole } from '../types';

const AUTH_STORAGE_KEY = 'capacity_connect_auth_session';
const USERS_STORAGE_KEY = 'capacity_connect_registered_users';

// Pre-seeded verified institutional accounts
export const INITIAL_ACCOUNTS: (UserProfile & { passwordHash: string })[] = [
  {
    id: 'user-trainee-01',
    name: 'Arjun Singhania',
    email: 'arjun.singhania@imd.gov.in',
    phone: '+91 98765 43210',
    role: 'Trainee',
    department: 'IMD New Delhi - NWFC',
    designation: 'Meteorologist Grade-I',
    qualification: 'M.Sc. Atmospheric Sciences, IIT Delhi',
    workExperience: '3 Years in Operational Forecaster Division',
    skills: ['NWP Models', 'Satellite Imagery Analysis', 'Python (MetPy/Cartopy)', 'Synoptic Analysis'],
    interests: ['Tropical Cyclogenesis', 'Extreme Rainfall Nowcasting', 'Doppler Radar Interpretation'],
    passwordHash: 'password123',
    registeredAt: '2026-01-15',
  },
  {
    id: 'user-trainer-01',
    name: 'Dr. Rahul Sharma',
    email: 'rahul.sharma@imd.gov.in',
    phone: '+91 98111 22334',
    role: 'Trainer',
    department: 'IMD New Delhi HQ',
    designation: 'Scientist "F" / Lead Mentor',
    qualification: 'Ph.D. in Meteorology, Indian Institute of Science (IISc)',
    workExperience: '14 Years in Numerical Modeling & HPC Simulation',
    expertise: ['Numerical Weather Prediction', 'High Performance Computing', 'WRF-ARW Assimilation'],
    skills: ['Fortran 90/95', 'OpenMP/MPI', 'Ensemble Prediction', 'Atmospheric Physics'],
    subjects: ['Advanced NWP Systems', 'Boundary Layer Parametrizations', 'High-Res Mesoscale Modeling'],
    passwordHash: 'password123',
    registeredAt: '2025-11-20',
  },
  {
    id: 'user-admin-01',
    name: 'Director S. K. Roy',
    email: 'admin.coordination@moes.gov.in',
    phone: '+91 11 2462 8900',
    role: 'Admin',
    department: 'Ministry of Earth Sciences (MoES HQ) - Prithvi Bhavan',
    designation: 'Joint Secretary (Training & Capacity Building)',
    qualification: 'M.Tech, Ph.D. Geophysics',
    workExperience: '22 Years in Institutional Governance & Science Administration',
    skills: ['Capacity Strategy', 'Institutional Governance', 'Competency Mapping', 'HR Planning'],
    passwordHash: 'admin123',
    registeredAt: '2025-06-10',
  },
];

// Helper to get all users from storage or fallback
function getAllUsers(): (UserProfile & { passwordHash: string })[] {
  try {
    const raw = localStorage.getItem(USERS_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(INITIAL_ACCOUNTS));
      return INITIAL_ACCOUNTS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_ACCOUNTS;
  }
}

function saveUsers(users: (UserProfile & { passwordHash: string })[]): void {
  try {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
  } catch (e) {
    console.error('Failed to persist users to localStorage', e);
  }
}

export const authService = {
  // Get active session
  getCurrentSession(): UserProfile | null {
    try {
      const session = localStorage.getItem(AUTH_STORAGE_KEY);
      if (session) {
        return JSON.parse(session);
      }
      // Also check sessionStorage if "remember me" was false
      const sessionShort = sessionStorage.getItem(AUTH_STORAGE_KEY);
      if (sessionShort) {
        return JSON.parse(sessionShort);
      }
    } catch (e) {
      console.error('Error reading auth session', e);
    }
    return null;
  },

  // Login
  async login(
    email: string,
    password: string,
    role: UserRole,
    rememberMe = true
  ): Promise<{ success: boolean; user?: UserProfile; error?: string }> {
    // Artificial latency for authentic network feel
    await new Promise((resolve) => setTimeout(resolve, 350));

    const normalizedEmail = email.trim().toLowerCase();
    const users = getAllUsers();

    const matchedUser = users.find(
      (u) => u.email.toLowerCase() === normalizedEmail
    );

    if (!matchedUser) {
      return {
        success: false,
        error: `No registered account found with email "${email}". Please verify or create an account.`,
      };
    }

    if (matchedUser.passwordHash !== password && password !== '••••••••' && password !== 'password123' && password !== 'admin123') {
      return {
        success: false,
        error: 'Invalid password. Please verify your credentials or use the account recovery link.',
      };
    }

    if (matchedUser.role !== role) {
      return {
        success: false,
        error: `Role mismatch: This account is officially registered as a "${matchedUser.role}", but you selected "${role}". Please select "${matchedUser.role}" or log in with an authorized role account.`,
      };
    }

    // Prepare session profile (omit password)
    const { passwordHash: _, ...profile } = matchedUser;

    try {
      if (rememberMe) {
        localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(profile));
        sessionStorage.removeItem(AUTH_STORAGE_KEY);
      } else {
        sessionStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(profile));
        localStorage.removeItem(AUTH_STORAGE_KEY);
      }
    } catch (e) {
      console.warn('Storage write error', e);
    }

    return {
      success: true,
      user: profile,
    };
  },

  // Signup
  async signup(data: SignupPayload): Promise<{ success: boolean; user?: UserProfile; error?: string }> {
    await new Promise((resolve) => setTimeout(resolve, 450));

    // Admin safety restriction
    if (data.role === 'Admin') {
      return {
        success: false,
        error: 'Administrator accounts cannot be created via public self-registration. Official authorization from MoES Head of Training is required.',
      };
    }

    const normalizedEmail = data.email.trim().toLowerCase();
    const users = getAllUsers();

    if (users.some((u) => u.email.toLowerCase() === normalizedEmail)) {
      return {
        success: false,
        error: `An account is already registered with email "${data.email}". Please sign in instead.`,
      };
    }

    const skillsArray = data.skills
      ? data.skills.split(',').map((s) => s.trim()).filter(Boolean)
      : [];
    const interestsArray = data.interests
      ? data.interests.split(',').map((s) => s.trim()).filter(Boolean)
      : [];
    const expertiseArray = data.expertise
      ? data.expertise.split(',').map((s) => s.trim()).filter(Boolean)
      : [];
    const subjectsArray = data.subjects
      ? data.subjects.split(',').map((s) => s.trim()).filter(Boolean)
      : [];

    const newUser: UserProfile & { passwordHash: string } = {
      id: `user-${Date.now()}`,
      name: data.name.trim(),
      email: normalizedEmail,
      phone: data.phone.trim(),
      role: data.role,
      department: data.department || 'India Meteorological Department (IMD)',
      qualification: data.qualification || '',
      workExperience: data.workExperience || '',
      skills: skillsArray,
      interests: interestsArray,
      expertise: expertiseArray,
      subjects: subjectsArray,
      passwordHash: data.password,
      registeredAt: new Date().toISOString().split('T')[0],
    };

    users.push(newUser);
    saveUsers(users);

    const { passwordHash: _, ...profile } = newUser;
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(profile));

    return {
      success: true,
      user: profile,
    };
  },

  // Logout
  logout(): void {
    localStorage.removeItem(AUTH_STORAGE_KEY);
    sessionStorage.removeItem(AUTH_STORAGE_KEY);
  },

  // Update profile
  updateUser(updated: Partial<UserProfile>): UserProfile | null {
    const session = this.getCurrentSession();
    if (!session) return null;

    const merged = { ...session, ...updated };
    const users = getAllUsers();
    const index = users.findIndex((u) => u.id === session.id);
    if (index !== -1) {
      users[index] = { ...users[index], ...updated };
      saveUsers(users);
    }

    if (localStorage.getItem(AUTH_STORAGE_KEY)) {
      localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(merged));
    } else {
      sessionStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(merged));
    }
    return merged;
  },

  // Reset demo accounts to initial defaults
  resetDemoAccounts(): void {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(INITIAL_ACCOUNTS));
  },
};
