// Client-side API Service for Trainee Dashboard & Profile
import { UserProfile } from '../types/auth';

export interface TraineeEnrolledCourse {
  enrollmentId: number;
  courseId: string;
  title: string;
  code: string;
  description: string;
  trainerName: string;
  category: string;
  duration: string;
  level: string;
  progress: number;
  completed: boolean;
  enrolledAt: string;
  lastAccessedAt: string;
}

export interface TraineeCertificateItem {
  id: number;
  courseId: string;
  courseName: string;
  certificateNumber: string;
  issueDate: string;
  grade: string;
  score: string;
  organization: string;
  status: string;
}

export interface TraineeNotificationItem {
  id: number;
  title: string;
  message: string;
  type: string;
  read: boolean;
  date: string;
}

export interface TraineeLearningActivityItem {
  id: number;
  title: string;
  description: string;
  timestamp: string;
  type: string;
}

export interface TraineeAssessmentScoreItem {
  id: number;
  courseId: string;
  assessmentTitle: string;
  score: number;
  maxScore: number;
  passed: boolean;
  submittedAt: string;
}

export interface TraineeDashboardData {
  enrolledCourses: TraineeEnrolledCourse[];
  totalEnrolledCount: number;
  completedCoursesCount: number;
  activeCoursesCount: number;
  certificates: TraineeCertificateItem[];
  certificatesCount: number;
  notifications: TraineeNotificationItem[];
  unreadNotificationsCount: number;
  recentActivities: TraineeLearningActivityItem[];
  assessmentScores: TraineeAssessmentScoreItem[];
  averageScorePercentage: number;
}

function getAuthHeaders(userEmail?: string): HeadersInit {
  return {
    'Content-Type': 'application/json',
    'x-user-email': userEmail || 'arjun.singhania@imd.gov.in',
  };
}

export const traineeApiService = {
  // 1. Get Trainee Profile from PostgreSQL database
  async getProfile(userEmail?: string): Promise<{ profile: any; error?: string }> {
    try {
      const response = await fetch('/api/trainee/profile', {
        headers: getAuthHeaders(userEmail),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch trainee profile');
      }
      return { profile: data.profile };
    } catch (err: any) {
      console.warn('traineeApiService.getProfile error:', err);
      return { profile: null, error: err.message };
    }
  },

  // 2. Update Trainee Profile in PostgreSQL database
  async updateProfile(
    profileData: Partial<UserProfile> & { division?: string; location?: string; specialization?: string },
    userEmail?: string
  ): Promise<{ success: boolean; profile?: any; error?: string }> {
    try {
      const response = await fetch('/api/trainee/profile', {
        method: 'PUT',
        headers: getAuthHeaders(userEmail),
        body: JSON.stringify(profileData),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to update profile');
      }
      return { success: true, profile: data.profile };
    } catch (err: any) {
      console.error('traineeApiService.updateProfile error:', err);
      return { success: false, error: err.message };
    }
  },

  // 3. Get Trainee Dashboard real statistics
  async getDashboardData(userEmail?: string): Promise<{ dashboard: TraineeDashboardData | null; error?: string }> {
    try {
      const response = await fetch('/api/trainee/dashboard', {
        headers: getAuthHeaders(userEmail),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch dashboard data');
      }
      return { dashboard: data.dashboard };
    } catch (err: any) {
      console.warn('traineeApiService.getDashboardData error:', err);
      return { dashboard: null, error: err.message };
    }
  },

  // 4. Get Trainee Enrolled Courses
  async getEnrolledCourses(userEmail?: string): Promise<{ courses: TraineeEnrolledCourse[]; error?: string }> {
    try {
      const response = await fetch('/api/trainee/courses', {
        headers: getAuthHeaders(userEmail),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch courses');
      }
      return { courses: data.courses || [] };
    } catch (err: any) {
      console.warn('traineeApiService.getEnrolledCourses error:', err);
      return { courses: [], error: err.message };
    }
  },

  // 5. Get Trainee Certificates
  async getCertificates(userEmail?: string): Promise<{ certificates: TraineeCertificateItem[]; error?: string }> {
    try {
      const response = await fetch('/api/trainee/certificates', {
        headers: getAuthHeaders(userEmail),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch certificates');
      }
      return { certificates: data.certificates || [] };
    } catch (err: any) {
      console.warn('traineeApiService.getCertificates error:', err);
      return { certificates: [], error: err.message };
    }
  },

  // 6. Get Trainee Notifications
  async getNotifications(userEmail?: string): Promise<{ notifications: TraineeNotificationItem[]; error?: string }> {
    try {
      const response = await fetch('/api/trainee/notifications', {
        headers: getAuthHeaders(userEmail),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch notifications');
      }
      return { notifications: data.notifications || [] };
    } catch (err: any) {
      console.warn('traineeApiService.getNotifications error:', err);
      return { notifications: [], error: err.message };
    }
  },

  // 7. Mark notification as read
  async markNotificationRead(id: number, userEmail?: string): Promise<boolean> {
    try {
      const response = await fetch(`/api/trainee/notifications/${id}/read`, {
        method: 'PATCH',
        headers: getAuthHeaders(userEmail),
      });
      return response.ok;
    } catch (err) {
      console.warn('traineeApiService.markNotificationRead error:', err);
      return false;
    }
  },
};
