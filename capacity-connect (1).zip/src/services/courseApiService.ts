// API client service for Courses, Enrollments, Modules, and Trainer Management
import { UserProfile } from '../types/auth';

export interface DbCourse {
  id: string;
  title: string;
  code: string;
  description: string;
  trainerName: string;
  trainerId?: number | null;
  category: string;
  duration: string;
  level: string;
  status: string; // PUBLISHED, DRAFT, ARCHIVED
  rating: string;
  totalModules: number;
  enrolledCount: number;
  isEnrolled: boolean;
  progress: number;
  enrollmentStatus: string; // NOT_ENROLLED, NOT_STARTED, IN_PROGRESS, COMPLETED
  completed: boolean;
  enrollmentDate?: string | null;
  lastActivity?: string | null;
  modules?: DbCourseModule[];
}

export interface DbCourseModule {
  id: number;
  courseId: string;
  title: string;
  duration: string;
  moduleOrder: number;
  completed: boolean;
}

export interface DbCourseTrainee {
  enrollmentId: number;
  progress: number;
  completed: boolean;
  status: string;
  enrolledAt: string;
  lastAccessedAt: string;
  userId: number;
  name: string;
  email: string;
  phone: string;
  department: string;
  designation: string;
  division: string;
}

function getHeaders(userEmail?: string): HeadersInit {
  return {
    'Content-Type': 'application/json',
    'x-user-email': userEmail || 'arjun.singhania@imd.gov.in',
  };
}

export const courseApiService = {
  // 1. Get all courses with enrollment counts and trainee status
  async getCourses(userEmail?: string): Promise<{ courses: DbCourse[]; error?: string }> {
    try {
      const response = await fetch('/api/courses', {
        headers: getHeaders(userEmail),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch courses');
      }
      return { courses: data.courses || [] };
    } catch (err: any) {
      console.warn('courseApiService.getCourses error:', err);
      return { courses: [], error: err.message };
    }
  },

  // 2. Get course details by ID including syllabus modules
  async getCourseById(courseId: string, userEmail?: string): Promise<{ course: DbCourse | null; error?: string }> {
    try {
      const response = await fetch(`/api/courses/${courseId}`, {
        headers: getHeaders(userEmail),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch course details');
      }
      return { course: data.course };
    } catch (err: any) {
      console.warn('courseApiService.getCourseById error:', err);
      return { course: null, error: err.message };
    }
  },

  // 3. Trainee enrolls in a course
  async enrollCourse(
    courseId: string,
    userEmail?: string
  ): Promise<{ success: boolean; alreadyEnrolled?: boolean; message?: string; error?: string }> {
    try {
      const response = await fetch('/api/enrollments', {
        method: 'POST',
        headers: getHeaders(userEmail),
        body: JSON.stringify({ courseId }),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Enrollment failed');
      }
      return {
        success: true,
        alreadyEnrolled: data.alreadyEnrolled,
        message: data.message,
      };
    } catch (err: any) {
      console.error('courseApiService.enrollCourse error:', err);
      return { success: false, error: err.message };
    }
  },

  // 4. Get current trainee's enrolled courses with progress & status
  async getMyEnrolledCourses(userEmail?: string): Promise<{ courses: any[]; error?: string }> {
    try {
      const response = await fetch('/api/enrollments/my', {
        headers: getHeaders(userEmail),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch my courses');
      }
      return { courses: data.courses || [] };
    } catch (err: any) {
      console.warn('courseApiService.getMyEnrolledCourses error:', err);
      return { courses: [], error: err.message };
    }
  },

  // 5. Update trainee course progress (0 - 100%)
  async updateProgress(
    courseId: string,
    progress: number,
    lastActivity?: string,
    userEmail?: string
  ): Promise<{ success: boolean; enrollment?: any; error?: string }> {
    try {
      const response = await fetch(`/api/courses/${courseId}/progress`, {
        method: 'PATCH',
        headers: getHeaders(userEmail),
        body: JSON.stringify({ progress, lastActivity }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to update progress');
      return { success: true, enrollment: data.enrollment };
    } catch (err: any) {
      console.error('courseApiService.updateProgress error:', err);
      return { success: false, error: err.message };
    }
  },

  // 6. Trainer creates a new course
  async createCourse(
    courseData: {
      title: string;
      description: string;
      category: string;
      duration: string;
      level: string;
      status?: string;
      modules?: string[];
    },
    userEmail?: string
  ): Promise<{ success: boolean; course?: DbCourse; error?: string }> {
    try {
      const response = await fetch('/api/courses', {
        method: 'POST',
        headers: getHeaders(userEmail),
        body: JSON.stringify(courseData),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to create course');
      return { success: true, course: data.course };
    } catch (err: any) {
      console.error('courseApiService.createCourse error:', err);
      return { success: false, error: err.message };
    }
  },

  // 7. Trainer updates their course
  async updateCourse(
    courseId: string,
    updateData: {
      title?: string;
      description?: string;
      category?: string;
      duration?: string;
      level?: string;
      status?: string;
    },
    userEmail?: string
  ): Promise<{ success: boolean; course?: DbCourse; error?: string }> {
    try {
      const response = await fetch(`/api/courses/${courseId}`, {
        method: 'PUT',
        headers: getHeaders(userEmail),
        body: JSON.stringify(updateData),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to update course');
      return { success: true, course: data.course };
    } catch (err: any) {
      console.error('courseApiService.updateCourse error:', err);
      return { success: false, error: err.message };
    }
  },

  // 8. Trainer deletes their course
  async deleteCourse(courseId: string, userEmail?: string): Promise<{ success: boolean; error?: string }> {
    try {
      const response = await fetch(`/api/courses/${courseId}`, {
        method: 'DELETE',
        headers: getHeaders(userEmail),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to delete course');
      return { success: true };
    } catch (err: any) {
      console.error('courseApiService.deleteCourse error:', err);
      return { success: false, error: err.message };
    }
  },

  // 9. Trainer fetches their authored courses
  async getTrainerCourses(userEmail?: string): Promise<{ courses: DbCourse[]; error?: string }> {
    try {
      const response = await fetch('/api/trainer/courses', {
        headers: getHeaders(userEmail),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to fetch trainer courses');
      return { courses: data.courses || [] };
    } catch (err: any) {
      console.warn('courseApiService.getTrainerCourses error:', err);
      return { courses: [], error: err.message };
    }
  },

  // 10. Trainer fetches enrolled trainees for a course
  async getCourseEnrolledTrainees(courseId: string, userEmail?: string): Promise<{ trainees: DbCourseTrainee[]; error?: string }> {
    try {
      const response = await fetch(`/api/courses/${courseId}/enrollments`, {
        headers: getHeaders(userEmail),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to fetch enrolled trainees');
      return { trainees: data.trainees || [] };
    } catch (err: any) {
      console.warn('courseApiService.getCourseEnrolledTrainees error:', err);
      return { trainees: [], error: err.message };
    }
  },

  // 11. Add a module to a course
  async addModule(
    courseId: string,
    moduleData: { title: string; duration?: string; moduleOrder?: number },
    userEmail?: string
  ): Promise<{ success: boolean; module?: DbCourseModule; error?: string }> {
    try {
      const response = await fetch(`/api/courses/${courseId}/modules`, {
        method: 'POST',
        headers: getHeaders(userEmail),
        body: JSON.stringify(moduleData),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to add module');
      return { success: true, module: data.module };
    } catch (err: any) {
      console.error('courseApiService.addModule error:', err);
      return { success: false, error: err.message };
    }
  },
};
