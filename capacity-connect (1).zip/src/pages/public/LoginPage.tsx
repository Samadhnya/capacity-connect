import React, { useState } from 'react';
import {
  GraduationCap,
  ArrowRight,
  ShieldCheck,
  Lock,
  Mail,
  Eye,
  EyeOff,
  AlertCircle,
  KeyRound,
  CheckCircle2,
} from 'lucide-react';
import { AppPage, UserRole } from '../../types';
import { useAuth } from '../../context/AuthContext';

interface LoginPageProps {
  onNavigate: (page: AppPage) => void;
  onLoginSuccess?: (role: UserRole) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onNavigate, onLoginSuccess }) => {
  const { login } = useAuth();

  const [role, setRole] = useState<UserRole>('Trainee');
  const [email, setEmail] = useState('arjun.singhania@imd.gov.in');
  const [password, setPassword] = useState('password123');
  const [rememberMe, setRememberMe] = useState(true);
  const [showPassword, setShowPassword] = useState(false);

  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<{ email?: string; password?: string }>({});

  // Quick preset accounts handler
  const handleRoleSelection = (selected: UserRole) => {
    setRole(selected);
    setErrorMessage(null);
    setFieldErrors({});
    if (selected === 'Trainee') {
      setEmail('arjun.singhania@imd.gov.in');
      setPassword('password123');
    } else if (selected === 'Trainer') {
      setEmail('rahul.sharma@imd.gov.in');
      setPassword('password123');
    } else {
      setEmail('admin.coordination@moes.gov.in');
      setPassword('admin123');
    }
  };

  const validate = (): boolean => {
    const errors: { email?: string; password?: string } = {};
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!email.trim()) {
      errors.email = 'Email address is required.';
    } else if (!emailRegex.test(email.trim())) {
      errors.email = 'Please enter a valid official email address.';
    }

    if (!password) {
      errors.password = 'Password is required.';
    } else if (password.length < 6) {
      errors.password = 'Password must be at least 6 characters.';
    }

    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!validate()) return;

    setIsLoading(true);
    try {
      const result = await login(email, password, role, rememberMe);
      if (result.success) {
        if (onLoginSuccess) {
          onLoginSuccess(role);
        } else {
          // Automatic Role Redirection
          if (role === 'Trainee') onNavigate('trainee-dashboard');
          else if (role === 'Trainer') onNavigate('trainer-dashboard');
          else onNavigate('admin-dashboard');
        }
      } else {
        setErrorMessage(result.error || 'Authentication failed. Please check credentials.');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'A network error occurred while connecting to authentication service.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="auth">
      <div className="authinfo">
        <GraduationCap size={44} className="text-[#58b9f0]" />
        <h1>Welcome back.</h1>
        <p>
          Access courses, learning resources, assessments, and professional development tools from one secure platform.
        </p>
        <div className="mt-8 space-y-3 text-sm text-[#dbeefe]">
          <p className="flex items-center gap-2 m-0">
            <ShieldCheck size={18} className="text-[#58b9f0] shrink-0" />
            <span>Role-based institutional access (Trainee, Trainer, Admin)</span>
          </p>
          <p className="flex items-center gap-2 m-0">
            <ShieldCheck size={18} className="text-[#58b9f0] shrink-0" />
            <span>Centralized MoES & IMD learning resources</span>
          </p>
          <p className="flex items-center gap-2 m-0">
            <ShieldCheck size={18} className="text-[#58b9f0] shrink-0" />
            <span>Real-time competency progress tracking & certificates</span>
          </p>
        </div>

        <div className="mt-12 pt-6 border-t border-[#ffffff20] text-xs text-[#a2d0f5]">
          Problem Statement 26075 • Ministry of Earth Sciences
        </div>
      </div>

      <div className="flex items-center justify-center p-6 bg-[#f6faff]">
        <form className="form" onSubmit={handleSubmit} noValidate>
          <h2>Sign in</h2>
          <p className="subtitle">Select your institutional role and sign in with your official account.</p>

          {/* Error Alert Box */}
          {errorMessage && (
            <div className="mb-4 p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-start gap-2.5 animate-shake">
              <AlertCircle size={18} className="shrink-0 text-rose-500 mt-0.5" />
              <div className="leading-relaxed">{errorMessage}</div>
            </div>
          )}

          {/* Role selector buttons */}
          <label>Select User Role</label>
          <div className="grid grid-cols-3 gap-2 mb-3">
            {(['Trainee', 'Trainer', 'Admin'] as UserRole[]).map((r) => (
              <button
                key={r}
                type="button"
                onClick={() => handleRoleSelection(r)}
                className={`py-2 px-2 rounded-xl text-xs font-bold transition-all border text-center cursor-pointer ${
                  role === r
                    ? 'bg-[#0b63b6] text-white border-[#0b63b6] shadow-sm'
                    : 'bg-white text-[#506579] border-[#d8e6f3] hover:border-[#0b63b6] hover:text-[#082e52]'
                }`}
              >
                {r}
              </button>
            ))}
          </div>

          {/* Email field */}
          <label className="flex items-center justify-between">
            <span>Email Address</span>
            {fieldErrors.email && (
              <span className="text-[11px] text-rose-500 font-semibold">{fieldErrors.email}</span>
            )}
          </label>
          <div className="relative mb-3">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#71879c]">
              <Mail size={16} />
            </div>
            <input
              type="email"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                if (fieldErrors.email) setFieldErrors({ ...fieldErrors, email: undefined });
              }}
              placeholder="e.g. name@imd.gov.in"
              className={`!pl-9.5 w-full ${fieldErrors.email ? '!border-rose-400 !bg-rose-50/20' : ''}`}
            />
          </div>

          {/* Password field with show/hide */}
          <div className="flex items-center justify-between mt-2 mb-0">
            <label className="m-0">Password</label>
            <button
              type="button"
              onClick={() => onNavigate('forgot-password')}
              className="text-xs text-[#0b63b6] hover:underline font-semibold cursor-pointer"
            >
              Forgot Password?
            </button>
          </div>
          <div className="relative mb-2">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#71879c]">
              <Lock size={16} />
            </div>
            <input
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                if (fieldErrors.password) setFieldErrors({ ...fieldErrors, password: undefined });
              }}
              placeholder="Enter account password"
              className={`!pl-9.5 !pr-10 w-full ${fieldErrors.password ? '!border-rose-400 !bg-rose-50/20' : ''}`}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-[#71879c] hover:text-[#0b63b6] cursor-pointer"
              title={showPassword ? 'Hide password' : 'Show password'}
            >
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
          {fieldErrors.password && (
            <p className="text-[11px] text-rose-500 font-semibold mb-2 mt-0">
              {fieldErrors.password}
            </p>
          )}

          {/* Remember me & Demo fast-login indicator */}
          <div className="flex items-center justify-between mt-2 mb-4">
            <label className="flex items-center gap-2 m-0 cursor-pointer text-xs text-[#506579] font-medium">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="w-4 h-4 rounded text-[#0b63b6] focus:ring-0 cursor-pointer"
              />
              Remember me on this workstation
            </label>
          </div>

          {/* Submit button */}
          <button
            type="submit"
            disabled={isLoading}
            className="primary cursor-pointer w-full flex items-center justify-center gap-2 !py-2.5"
          >
            {isLoading ? (
              <>
                <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24" fill="none">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                <span>Authenticating Credentials...</span>
              </>
            ) : (
              <>
                <span>Sign In as {role}</span>
                <ArrowRight size={16} />
              </>
            )}
          </button>

          {/* Create account link */}
          <div className="mt-6 pt-4 border-t border-[#edf4fa] text-center text-sm text-[#66798c]">
            Don't have an institutional account?{' '}
            <button
              type="button"
              className="text font-bold text-[#0b63b6] hover:underline cursor-pointer"
              onClick={() => onNavigate('signup')}
            >
              Register here
            </button>
          </div>

          {/* Official Demo Credentials helper */}
          <div className="mt-4 p-3.5 bg-[#e8f5ff] rounded-xl text-xs text-[#08427b] border border-[#cbe6fa]">
            <div className="font-bold flex items-center gap-1.5 mb-1 text-[#0b63b6]">
              <KeyRound size={13} /> Official Demo Credentials (Pre-filled):
            </div>
            <div className="grid grid-cols-1 gap-1 text-[11px] text-[#33597d]">
              <div>• <b>Trainee:</b> arjun.singhania@imd.gov.in / password123</div>
              <div>• <b>Trainer:</b> rahul.sharma@imd.gov.in / password123</div>
              <div>• <b>Admin:</b> admin.coordination@moes.gov.in / admin123</div>
            </div>
          </div>
        </form>
      </div>
    </main>
  );
};
