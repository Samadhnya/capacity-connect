import React from 'react';
import {
  ShieldCheck,
  ArrowRight,
  BookOpen,
  Award,
  BarChart3,
  Bell,
  FileQuestion,
  Users,
  GraduationCap,
  Compass,
  Cpu,
  CheckCircle,
  LogIn,
  UserPlus,
} from 'lucide-react';
import { AppPage } from '../../types';
import { initialCourses } from '../../data/mockData';

interface LandingPageProps {
  onNavigate: (page: AppPage) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate }) => {
  return (
    <>
      {/* Hero Section */}
      <section className="hero">
        <div>
          <span className="badge">
            <ShieldCheck size={15} /> MoES Smart Education Portal • PS 26075
          </span>
          <h1>
            Build Skills.<br />
            <em>Learn. Grow.</em>
          </h1>
          <p>
            A centralized digital capacity building and learning management platform designed for the Ministry of Earth Sciences (MoES) and India Meteorological Department (IMD) to upskill workforce in numerical weather prediction, satellite analysis, and disaster early warning systems.
          </p>
          <div className="actions flex flex-wrap items-center gap-3">
            <button className="primary" onClick={() => onNavigate('courses')}>
              <span>Explore Courses</span>
              <ArrowRight size={16} />
            </button>
            <button
              className="secondary flex items-center gap-2 font-bold text-[#0b63b6] hover:bg-[#e7f5ff] border-[#b0d5f5]"
              onClick={() => onNavigate('login')}
            >
              <LogIn size={16} />
              <span>Sign In</span>
            </button>
            <button
              className="secondary flex items-center gap-2 font-bold bg-[#082e52] text-white hover:bg-[#06203a] border-[#082e52]"
              onClick={() => onNavigate('signup')}
            >
              <UserPlus size={16} />
              <span>Sign Up</span>
            </button>
          </div>
          <div className="stats">
            <div>
              <b>3 Roles</b>
              <small>Trainee, Trainer & Admin</small>
            </div>
            <div>
              <b>24/7</b>
              <small>Learning Access</small>
            </div>
            <div>
              <b>100%</b>
              <small>Digital & Verifiable</small>
            </div>
          </div>
        </div>

        {/* Mock Preview Card (Preserving Original Design) */}
        <div className="mock">
          <div className="mocktop">
            <span>
              <GraduationCap size={16} /> CAPACITY CONNECT
            </span>
            <span className="flex items-center gap-1 text-xs">
              <Bell size={14} /> Active Batch 2026
            </span>
          </div>
          <h3>Continue Learning</h3>
          <div className="mockstats">
            <div>
              <BookOpen />
              <b>12</b>
              <small>Courses</small>
            </div>
            <div>
              <Award />
              <b>5</b>
              <small>Certificates</small>
            </div>
            <div>
              <BarChart3 />
              <b>82%</b>
              <small>Progress</small>
            </div>
          </div>
          <div className="learning">
            <BookOpen />
            <div className="w-full">
              <small>In Progress • Week 4 of 6</small>
              <b>Numerical Weather Prediction (NWP) Modeling</b>
              <progress value="72" max="100" />
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-[#edf2f6] flex items-center justify-between text-xs text-[#66798c]">
            <span className="flex items-center gap-1 font-semibold text-emerald-700">
              <CheckCircle size={14} className="text-emerald-500" /> Next Quiz: 4D-Var Data Assimilation
            </span>
            <button
              onClick={() => onNavigate('trainee-dashboard')}
              className="text-[#0b63b6] font-bold hover:underline cursor-pointer"
            >
              Open Dashboard →
            </button>
          </div>
        </div>
      </section>

      {/* Featured Courses Teaser */}
      <section className="py-16 px-[7%] bg-white border-b border-[#edf4fa]">
        <div className="head">
          <span>CURATED CURRICULUM</span>
          <h2>Specialized Meteorological & Earth Science Programs</h2>
          <p>
            Developed by lead scientists and meteorological directors to standardize technical skills across IMD field stations and research divisions.
          </p>
        </div>

        <div className="coursegrid">
          {initialCourses.slice(0, 3).map((course) => (
            <article key={course.id} className="course">
              <div className="cover">
                <span>{course.level}</span>
                <BookOpen size={20} />
              </div>
              <div className="body">
                <h3>{course.title}</h3>
                <p>{course.description}</p>
                <small>
                  <Users size={14} /> {course.trainer} ({course.trainerRole?.split(',')[0]})
                </small>
                <small>
                  <Compass size={14} /> {course.duration} • {course.modulesCount} Modules
                </small>
                <button
                  className="primary"
                  onClick={() => onNavigate('courses')}
                >
                  View Details <ArrowRight size={14} />
                </button>
              </div>
            </article>
          ))}
        </div>

        <div className="text-center mt-10">
          <button
            onClick={() => onNavigate('courses')}
            className="secondary font-bold text-sm px-6 py-2.5"
          >
            View All Courses & Syllabi ({initialCourses.length}) →
          </button>
        </div>
      </section>

      {/* Features Grid (Preserving Original Design) */}
      <section className="section" id="features">
        <div className="head">
          <span>PLATFORM FEATURES</span>
          <h2>Everything you need to learn and grow</h2>
          <p>One centralized ecosystem connecting trainees, trainers, and administrators across the Ministry of Earth Sciences.</p>
        </div>

        <div className="grid">
          {[
            ['Learning Resources', BookOpen, 'Access lectures, numerical codes, high-resolution radar datasets, and research manuals.'],
            ['MCQ Assessments', FileQuestion, 'Attempt module-wise evaluations with instant score calculation and rationales.'],
            ['Certifications', Award, 'Earn digitally signed, tamper-proof certificates verifying technical competencies.'],
            ['Competency Mapping', Users, 'Identify workforce skills gaps and match trainers based on domain expertise.'],
            ['Performance Tracking', BarChart3, 'Monitor participation rates, test outcomes, and learning trajectory visually.'],
            ['Announcements & Notices', Bell, 'Receive operational alerts, training notifications, and schedule revisions in real time.'],
          ].map(([title, Icon, desc], i) => (
            <article key={i}>
              <i>
                <Icon size={24} />
              </i>
              <h3>{title as string}</h3>
              <p>{desc as string}</p>
            </article>
          ))}
        </div>
      </section>

      {/* How It Works Steps (Preserving Original Design) */}
      <section className="steps">
        <div className="head">
          <span>HOW IT WORKS</span>
          <h2>Simple 4-Step Learning Journey</h2>
          <p>Structured workflow designed for scientific officers and meteorological trainees.</p>
        </div>

        <div className="stepgrid">
          {[
            { step: '01', title: 'Create Account', desc: 'Register with your official MoES/IMD organizational credentials.' },
            { step: '02', title: 'Choose Role', desc: 'Access tailored views for Trainee, Trainer, or Administrator.' },
            { step: '03', title: 'Interactive Learning', desc: 'Complete weekly modules, hands-on notebooks, and video lectures.' },
            { step: '04', title: 'Certify & Track', desc: 'Pass assessments and receive tamper-proof digital certificates.' },
          ].map((item, idx) => (
            <div key={idx} className="flex-col !items-start">
              <strong>{item.step}</strong>
              <b className="text-base mt-2">{item.title}</b>
              <p className="text-xs text-[#66798c] m-0 mt-1 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Call to Action (Preserving Original Design) */}
      <section className="cta">
        <div>
          <span>CAPACITY CONNECT</span>
          <h2>One platform. Multiple possibilities.</h2>
          <p>Empower scientific officers, enhance forecasting competencies, and streamline learning digitally.</p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => onNavigate('login')}
            className="bg-white/20 hover:bg-white/30 text-white font-bold py-3 px-5 rounded-xl text-sm flex items-center gap-2 transition-colors cursor-pointer"
          >
            <LogIn size={16} />
            <span>Sign In</span>
          </button>
          <button
            onClick={() => onNavigate('signup')}
            className="bg-white text-[#0b63b6] hover:bg-[#f0f7ff] font-bold py-3 px-6 rounded-xl text-sm flex items-center gap-2 transition-colors cursor-pointer shadow-md"
          >
            <span>Sign Up</span>
            <ArrowRight size={18} />
          </button>
        </div>
      </section>
    </>
  );
};
