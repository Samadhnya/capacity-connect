import React from 'react';
import { ArrowRight, Globe, Award, ShieldCheck, Users, Target, BookOpen } from 'lucide-react';
import { AppPage } from '../../types';

interface AboutPageProps {
  onNavigate: (page: AppPage) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ onNavigate }) => {
  return (
    <main className="page max-w-6xl mx-auto">
      <div className="head">
        <span>SMART EDUCATION • PROBLEM STATEMENT ID: 26075</span>
        <h1>About CAPACITY CONNECT</h1>
        <p>
          A dedicated national digital capacity building and learning management framework for the Ministry of Earth Sciences (MoES) and India Meteorological Department (IMD).
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 my-10">
        <div className="bg-white p-8 rounded-2xl border border-[#dce8f3] shadow-xs">
          <div className="w-12 h-12 rounded-xl bg-[#e7f5ff] text-[#0b63b6] flex items-center justify-center mb-4">
            <Target size={24} />
          </div>
          <h2 className="text-xl font-bold text-[#082e52] mb-3">Our Objective</h2>
          <p className="text-sm text-[#506579] leading-relaxed mb-4">
            To eliminate geographical hurdles and fragmentation in scientific personnel training across all IMD Regional Meteorological Centres (RMCs), Meteorological Centres (MCs), and premier institutions like IITM Pune, NCMRWF Noida, and INCOIS Hyderabad.
          </p>
          <p className="text-sm text-[#506579] leading-relaxed">
            Through high-definition modular digital curricula, trainees can master complex topics including numerical weather prediction, cyclone tracking protocols, Doppler radar velocity displays, and seismological data logging.
          </p>
        </div>

        <div className="bg-white p-8 rounded-2xl border border-[#dce8f3] shadow-xs">
          <div className="w-12 h-12 rounded-xl bg-[#e7f5ff] text-[#0b63b6] flex items-center justify-center mb-4">
            <Globe size={24} />
          </div>
          <h2 className="text-xl font-bold text-[#082e52] mb-3">Institutional Scope</h2>
          <p className="text-sm text-[#506579] leading-relaxed mb-4">
            Serving over 1,200 active meteorologists, scientific officers, IT engineers, and technical assistants deployed in coastal radars, Himalayan weather observatories, and central HPC computing facilities.
          </p>
          <div className="space-y-2 text-xs font-semibold text-[#082e52]">
            <div className="flex items-center gap-2 p-2 bg-[#f6faff] rounded-lg">
              <span className="w-2 h-2 rounded-full bg-[#0b63b6]" />
              <span>India Meteorological Department (IMD) - Mausam Bhawan</span>
            </div>
            <div className="flex items-center gap-2 p-2 bg-[#f6faff] rounded-lg">
              <span className="w-2 h-2 rounded-full bg-[#0b63b6]" />
              <span>National Centre for Medium Range Weather Forecasting (NCMRWF)</span>
            </div>
            <div className="flex items-center gap-2 p-2 bg-[#f6faff] rounded-lg">
              <span className="w-2 h-2 rounded-full bg-[#0b63b6]" />
              <span>Indian National Centre for Ocean Information Services (INCOIS)</span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-r from-[#072e52] to-[#0b63b6] text-white p-8 md:p-12 rounded-2xl my-10 shadow-lg">
        <h2 className="text-2xl md:text-3xl font-bold mb-4">
          Problem Statement 26075: Smart Education Theme
        </h2>
        <p className="text-sm text-[#dceaff] max-w-3xl leading-relaxed mb-6">
          The manual administration of seasonal training workshops resulted in inconsistent skill metrics, unmapped competency levels, and delayed certification. CAPACITY CONNECT bridges this gap by unifying LMS course delivery, automated MCQ examinations with verifiable certificates, and role-based training oversight.
        </p>
        <div className="flex flex-wrap gap-4">
          <button
            onClick={() => onNavigate('courses')}
            className="bg-white text-[#0b63b6] font-bold text-sm px-6 py-3 rounded-xl hover:bg-[#f0f7ff] transition-colors inline-flex items-center gap-2 cursor-pointer"
          >
            <span>Explore Course Catalog</span>
            <ArrowRight size={16} />
          </button>
          <button
            onClick={() => onNavigate('features')}
            className="bg-[#ffffff20] text-white border border-white/30 font-bold text-sm px-6 py-3 rounded-xl hover:bg-[#ffffff30] transition-colors cursor-pointer"
          >
            Review Platform Features
          </button>
        </div>
      </div>
    </main>
  );
};
