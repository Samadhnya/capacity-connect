import React, { useState, useEffect } from 'react';
import {
  BookOpen,
  Users,
  Clock3,
  Search,
  Filter,
  ArrowRight,
  CheckCircle,
  GraduationCap,
  Sparkles,
  RefreshCw,
  Loader2,
  AlertCircle,
  Check,
} from 'lucide-react';
import { AppPage, Course } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { courseApiService, DbCourse } from '../../services/courseApiService';

interface CourseCataloguePageProps {
  courses: Course[];
  onNavigate: (page: AppPage) => void;
  onSelectCourse: (course: Course) => void;
  onEnroll: (courseId: string) => void;
}

export const CourseCataloguePage: React.FC<CourseCataloguePageProps> = ({
  courses: fallbackCourses,
  onNavigate,
  onSelectCourse,
  onEnroll,
}) => {
  const { user, isAuthenticated } = useAuth();
  const [dbCourses, setDbCourses] = useState<DbCourse[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [enrollingId, setEnrollingId] = useState<string | null>(null);
  const [enrollSuccessMessage, setEnrollSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedLevel, setSelectedLevel] = useState('All');
  const [sortBy, setSortBy] = useState<'rating' | 'enrolled' | 'title'>('rating');

  const categories = [
    'All',
    'Meteorology',
    'Remote Sensing',
    'Climate & Forecasting',
    'Disaster Management',
    'Oceanography',
    'Instrumentation',
    'Hydrology',
  ];

  const fetchCourses = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const email = user?.email || 'arjun.singhania@imd.gov.in';
      const result = await courseApiService.getCourses(email);
      if (result.courses && result.courses.length > 0) {
        setDbCourses(result.courses);
      }
    } catch (err: any) {
      console.warn('Error fetching courses:', err);
      setErrorMessage('Could not connect to live database catalogue.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchCourses();
  }, [user?.email]);

  // Merge DB courses with fallback courses
  const combinedCourses: Course[] =
    dbCourses.length > 0
      ? dbCourses.map((dc) => {
          const match = fallbackCourses.find((fc) => fc.id === dc.id);
          return {
            id: dc.id,
            title: dc.title,
            description: dc.description || (match?.description ?? ''),
            trainer: dc.trainerName,
            trainerRole: match?.trainerRole || 'Scientist / Course Director',
            category: dc.category,
            duration: dc.duration,
            level: (dc.level as any) || 'Intermediate',
            rating: parseFloat(dc.rating) || 4.9,
            enrolledCount: dc.enrolledCount,
            modulesCount: dc.totalModules || 4,
            progress: dc.progress,
            isEnrolled: dc.isEnrolled,
            syllabus: match?.syllabus || [],
          };
        })
      : fallbackCourses;

  const filteredCourses = combinedCourses
    .filter((c) => {
      const matchesSearch =
        c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.trainer.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === 'All' || c.category === selectedCategory;
      const matchesLevel = selectedLevel === 'All' || c.level === selectedLevel;
      return matchesSearch && matchesCategory && matchesLevel;
    })
    .sort((a, b) => {
      if (sortBy === 'enrolled') return b.enrolledCount - a.enrolledCount;
      if (sortBy === 'title') return a.title.localeCompare(b.title);
      return b.rating - a.rating;
    });

  const handleEnrollNow = async (course: Course) => {
    if (!isAuthenticated) {
      onNavigate('login');
      return;
    }

    setEnrollingId(course.id);
    setErrorMessage(null);
    try {
      const email = user?.email || 'arjun.singhania@imd.gov.in';
      const res = await courseApiService.enrollCourse(course.id, email);
      if (res.success) {
        setEnrollSuccessMessage(res.message || `Successfully enrolled in ${course.title}!`);
        // Update local state
        setDbCourses((prev) =>
          prev.map((c) =>
            c.id === course.id
              ? { ...c, isEnrolled: true, enrolledCount: c.enrolledCount + 1, progress: 10, enrollmentStatus: 'IN_PROGRESS' }
              : c
          )
        );
        onEnroll(course.id);
        setTimeout(() => setEnrollSuccessMessage(null), 4000);
      } else {
        setErrorMessage(res.error || 'Failed to complete enrollment.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Error connecting to enrollment service.');
    } finally {
      setEnrollingId(null);
    }
  };

  const handleViewCourse = (course: Course) => {
    onSelectCourse(course);
    onNavigate('trainee-course-details');
  };

  return (
    <main className="page max-w-7xl mx-auto">
      <div className="head">
        <div className="flex items-center justify-between gap-3">
          <span>LEARNING CATALOGUE • MoES & IMD</span>
          <button
            onClick={fetchCourses}
            disabled={isLoading}
            className="secondary !py-1.5 !px-3 !text-xs cursor-pointer flex items-center gap-1.5 shrink-0"
            title="Refresh catalogue from PostgreSQL"
          >
            <RefreshCw size={13} className={isLoading ? 'animate-spin' : ''} />
            <span>Sync Catalogue</span>
          </button>
        </div>
        <h1>Explore Courses</h1>
        <p>
          Discover structured training programs for professional competency development in meteorological, climate, and oceanographic operational domains stored in PostgreSQL.
        </p>
      </div>

      {enrollSuccessMessage && (
        <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-semibold flex items-center gap-2 animate-fade-in">
          <CheckCircle size={18} className="text-emerald-600 shrink-0" />
          <span>{enrollSuccessMessage}</span>
          <button
            onClick={() => onNavigate('trainee-my-courses')}
            className="ml-auto underline font-bold cursor-pointer text-xs"
          >
            Go to My Courses →
          </button>
        </div>
      )}

      {errorMessage && (
        <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm font-semibold flex items-center gap-2 animate-fade-in">
          <AlertCircle size={18} className="text-rose-600 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-white border border-[#dce8f3] rounded-2xl p-5 mb-8 shadow-xs">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div className="relative md:col-span-2">
            <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#889eb5]" />
            <input
              type="text"
              placeholder="Search courses, instructors, topics..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm focus:outline-none focus:border-[#0b63b6]"
            />
          </div>

          <div>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              aria-label="Filter by Category"
              className="w-full py-2.5 px-3 rounded-xl border border-[#d4e1eb] bg-white text-xs font-semibold text-[#082e52] focus:outline-none"
            >
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  Category: {cat}
                </option>
              ))}
            </select>
          </div>

          <div className="flex gap-2">
            <select
              value={selectedLevel}
              onChange={(e) => setSelectedLevel(e.target.value)}
              aria-label="Filter by Level"
              className="w-1/2 py-2.5 px-2.5 rounded-xl border border-[#d4e1eb] bg-white text-xs font-semibold text-[#082e52] focus:outline-none"
            >
              <option value="All">All Levels</option>
              <option value="Beginner">Beginner</option>
              <option value="Intermediate">Intermediate</option>
              <option value="Advanced">Advanced</option>
            </select>

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              aria-label="Sort Courses"
              className="w-1/2 py-2.5 px-2.5 rounded-xl border border-[#d4e1eb] bg-white text-xs font-semibold text-[#082e52] focus:outline-none"
            >
              <option value="rating">Top Rated</option>
              <option value="enrolled">Most Popular</option>
              <option value="title">Alphabetical</option>
            </select>
          </div>
        </div>
      </div>

      {isLoading ? (
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-16 text-center text-[#647b92]">
          <Loader2 size={36} className="animate-spin text-[#0b63b6] mx-auto mb-3" />
          <p className="text-sm font-semibold">Loading courses from PostgreSQL database...</p>
        </div>
      ) : filteredCourses.length === 0 ? (
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-12 text-center text-[#647b92]">
          <BookOpen size={36} className="text-[#889eb5] mx-auto mb-2" />
          <h3 className="text-base font-bold text-[#082e52]">No courses matched your query</h3>
          <p className="text-xs text-[#506579] mt-1">Try clearing your search terms or filters.</p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('All');
              setSelectedLevel('All');
            }}
            className="secondary !text-xs !py-2 !px-4 mt-3 cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="coursegrid">
          {filteredCourses.map((course) => (
            <article key={course.id} className="course flex flex-col justify-between">
              <div>
                <div className="cover">
                  <span>{course.level}</span>
                  <BookOpen size={20} />
                </div>
                <div className="meta">
                  <span>{course.category}</span>
                  <span className="font-bold text-amber-600">★ {course.rating}</span>
                </div>
                <h3>{course.title}</h3>
                <p>{course.description}</p>
                <div className="teacher">
                  <div className="w-6 h-6 rounded-full bg-[#0b63b6] text-white flex items-center justify-center text-[10px] font-bold">
                    {course.trainer[0]}
                  </div>
                  <span>{course.trainer}</span>
                </div>
                <div className="flex items-center gap-3 text-xs text-[#71879c] mt-2 mb-4">
                  <span className="flex items-center gap-1">
                    <Clock3 size={13} /> {course.duration}
                  </span>
                  <span className="flex items-center gap-1">
                    <Users size={13} /> {course.enrolledCount} enrolled
                  </span>
                </div>
              </div>

              <div className="border-t border-[#edf2f6] pt-3 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => handleViewCourse(course)}
                  className="secondary flex-1 !text-xs !py-2.5 font-bold cursor-pointer"
                >
                  View Details
                </button>

                {course.isEnrolled ? (
                  <button
                    type="button"
                    onClick={() => handleViewCourse(course)}
                    className="secondary !text-xs !py-2.5 !px-3 font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 cursor-pointer flex items-center gap-1"
                  >
                    <Check size={14} /> Enrolled
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled={enrollingId === course.id}
                    onClick={() => handleEnrollNow(course)}
                    className="primary flex-1 !text-xs !py-2.5 font-bold cursor-pointer flex items-center justify-center gap-1"
                  >
                    {enrollingId === course.id ? (
                      <>
                        <Loader2 size={13} className="animate-spin" />
                        <span>Enrolling...</span>
                      </>
                    ) : (
                      <>
                        <span>Enroll Now</span>
                        <ArrowRight size={13} />
                      </>
                    )}
                  </button>
                )}
              </div>
            </article>
          ))}
        </div>
      )}
    </main>
  );
};
