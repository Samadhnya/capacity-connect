import React, { useState } from 'react';
import {
  GraduationCap,
  ArrowRight,
  ShieldCheck,
  Lock,
  Mail,
  User,
  Phone,
  Building,
  Briefcase,
  BookOpen,
  Award,
  AlertCircle,
  Eye,
  EyeOff,
  CheckCircle2,
  Info,
} from 'lucide-react';
import { AppPage, UserRole } from '../../types';
import { useAuth } from '../../context/AuthContext';

interface SignupPageProps {
  onNavigate: (page: AppPage) => void;
  onSignupSuccess?: (role: UserRole) => void;
}

export const SignupPage: React.FC<SignupPageProps> = ({ onNavigate, onSignupSuccess }) => {
  const { signup } = useAuth();

  // Role Selection (Trainee or Trainer)
  const [role, setRole] = useState<UserRole>('Trainee');

  // Common Fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [department, setDepartment] = useState('India Meteorological Department (IMD) - New Delhi HQ');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Trainee Specific Fields
  const [qualification, setQualification] = useState('M.Sc. Atmospheric Sciences / Meteorology');
  const [workExperience, setWorkExperience] = useState('2 Years at Regional Meteorological Centre');
  const [skills, setSkills] = useState('NWP Models, Radar Interpretation, Python');
  const [interests, setInterests] = useState('Severe Weather Forecasting, Cyclone Dynamics');

  // Trainer Specific Fields
  const [trainerQualification, setTrainerQualification] = useState('Ph.D. Atmospheric Physics / Physical Oceanography');
  const [trainerExperience, setTrainerExperience] = useState('8+ Years Research & Operational Training');
  const [expertise, setExpertise] = useState('Numerical Weather Prediction, Doppler Weather Radar, HPC');
  const [trainerSkills, setTrainerSkills] = useState('Fortran, WRF Modeling, Data Assimilation, Python');
  const [subjects, setSubjects] = useState('Advanced Synoptic Meteorology, Atmospheric Thermodynamics');

  // Status & Validation States
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [adminNotice, setAdminNotice] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phoneRegex = /^[\d\s+\-()]{8,15}$/;

    if (!name.trim()) newErrors.name = 'Full name is required.';
    if (!email.trim()) {
      newErrors.email = 'Official email is required.';
    } else if (!emailRegex.test(email.trim())) {
      newErrors.email = 'Please provide a valid official email address.';
    }

    if (!phone.trim()) {
      newErrors.phone = 'Phone / intercom number is required.';
    } else if (!phoneRegex.test(phone.trim())) {
      newErrors.phone = 'Please provide a valid contact number (8-15 digits).';
    }

    if (!password) {
      newErrors.password = 'Password is required.';
    } else if (password.length < 8) {
      newErrors.password = 'Password must be at least 8 characters long.';
    }

    if (!confirmPassword) {
      newErrors.confirmPassword = 'Confirmation password is required.';
    } else if (password !== confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match.';
    }

    if (role === 'Trainee') {
      if (!qualification.trim()) newErrors.qualification = 'Qualification is required.';
      if (!workExperience.trim()) newErrors.workExperience = 'Work experience is required.';
      if (!skills.trim()) newErrors.skills = 'Please enter at least one skill.';
    } else if (role === 'Trainer') {
      if (!trainerQualification.trim()) newErrors.trainerQualification = 'Qualification is required.';
      if (!trainerExperience.trim()) newErrors.trainerExperience = 'Work experience is required.';
      if (!expertise.trim()) newErrors.expertise = 'Please specify primary expertise areas.';
      if (!subjects.trim()) newErrors.subjects = 'Please list teaching/training subjects.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    try {
      const payload = {
        name,
        email,
        phone,
        password,
        confirmPassword,
        role,
        department,
        ...(role === 'Trainee'
          ? {
              qualification,
              workExperience,
              skills,
              interests,
            }
          : {
              qualification: trainerQualification,
              workExperience: trainerExperience,
              expertise,
              skills: trainerSkills,
              subjects,
            }),
      };

      const result = await signup(payload);

      if (result.success) {
        if (onSignupSuccess) {
          onSignupSuccess(role);
        } else {
          // Automatic Role Redirection
          if (role === 'Trainee') onNavigate('trainee-dashboard');
          else if (role === 'Trainer') onNavigate('trainer-dashboard');
        }
      } else {
        setErrorMessage(result.error || 'Failed to complete registration.');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Network error encountered during registration.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="auth">
      <div className="authinfo">
        <GraduationCap size={44} className="text-[#58b9f0]" />
        <h1>Institutional Onboarding</h1>
        <p>
          Register for the MoES CAPACITY CONNECT network. Gain direct access to certified courses, HPC model tutorials, radar archives, and peer assessments.
        </p>
        <div className="mt-8 space-y-3 text-sm text-[#dbeefe]">
          <p className="flex items-center gap-2 m-0">
            <ShieldCheck size={18} className="text-[#58b9f0] shrink-0" />
            <span>Verified governmental identity onboarding</span>
          </p>
          <p className="flex items-center gap-2 m-0">
            <ShieldCheck size={18} className="text-[#58b9f0] shrink-0" />
            <span>Integrated competency profiling & certificate tracking</span>
          </p>
          <p className="flex items-center gap-2 m-0">
            <ShieldCheck size={18} className="text-[#58b9f0] shrink-0" />
            <span>IMD, IITM, INCOIS & NCMRWF scientific inter-connectivity</span>
          </p>
        </div>

        <div className="mt-12 pt-6 border-t border-[#ffffff20] text-xs text-[#a2d0f5]">
          Problem Statement 26075 • Ministry of Earth Sciences
        </div>
      </div>

      <div className="flex items-center justify-center p-6 bg-[#f6faff]">
        <form className="form max-w-xl" onSubmit={handleSubmit} noValidate>
          <h2>Create account</h2>
          <p className="subtitle">
            Provide your departmental and professional details to establish your institutional profile.
          </p>

          {/* Error Banner */}
          {errorMessage && (
            <div className="mb-4 p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-start gap-2.5 animate-shake">
              <AlertCircle size={18} className="shrink-0 text-rose-500 mt-0.5" />
              <div className="leading-relaxed">{errorMessage}</div>
            </div>
          )}

          {/* Role Selection with Admin Security Notice */}
          <label>Registering As</label>
          <div className="grid grid-cols-3 gap-2 mb-4">
            <button
              type="button"
              onClick={() => {
                setRole('Trainee');
                setAdminNotice(false);
              }}
              className={`py-2 px-2 rounded-xl text-xs font-bold transition-all border text-center cursor-pointer ${
                role === 'Trainee' && !adminNotice
                  ? 'bg-[#0b63b6] text-white border-[#0b63b6] shadow-sm'
                  : 'bg-white text-[#506579] border-[#d8e6f3] hover:border-[#0b63b6]'
              }`}
            >
              Trainee
            </button>
            <button
              type="button"
              onClick={() => {
                setRole('Trainer');
                setAdminNotice(false);
              }}
              className={`py-2 px-2 rounded-xl text-xs font-bold transition-all border text-center cursor-pointer ${
                role === 'Trainer' && !adminNotice
                  ? 'bg-[#0b63b6] text-white border-[#0b63b6] shadow-sm'
                  : 'bg-white text-[#506579] border-[#d8e6f3] hover:border-[#0b63b6]'
              }`}
            >
              Trainer
            </button>
            <button
              type="button"
              onClick={() => setAdminNotice(true)}
              className={`py-2 px-2 rounded-xl text-xs font-bold transition-all border text-center cursor-pointer ${
                adminNotice
                  ? 'bg-amber-500 text-white border-amber-500 shadow-sm'
                  : 'bg-white text-[#506579] border-[#d8e6f3] hover:border-amber-400'
              }`}
            >
              Admin
            </button>
          </div>

          {/* Admin Policy Notice */}
          {adminNotice && (
            <div className="mb-5 p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 flex items-start gap-2.5">
              <Info size={18} className="shrink-0 text-amber-600 mt-0.5" />
              <div>
                <b className="block mb-1">Administrative Access Policy:</b>
                Administrator accounts cannot be self-registered publicly. MoES headquarters maintains strict authorization protocols.
                If you are a designated system administrator, please log in using your issued administrative credentials.
                <button
                  type="button"
                  onClick={() => onNavigate('login')}
                  className="block mt-2 font-bold text-[#0b63b6] hover:underline"
                >
                  Go to Admin Sign In →
                </button>
              </div>
            </div>
          )}

          {/* Section 1: Common Profile Details */}
          <div className="space-y-3">
            <div>
              <label className="flex items-center justify-between">
                <span>Full Name</span>
                {errors.name && <span className="text-[11px] text-rose-500 font-semibold">{errors.name}</span>}
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#71879c]">
                  <User size={16} />
                </div>
                <input
                  type="text"
                  placeholder="e.g. Dr. Kavita Raman"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    if (errors.name) setErrors({ ...errors, name: '' });
                  }}
                  className={`!pl-9.5 w-full ${errors.name ? '!border-rose-400 !bg-rose-50/20' : ''}`}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="flex items-center justify-between">
                  <span>Official Email</span>
                  {errors.email && <span className="text-[11px] text-rose-500 font-semibold">{errors.email}</span>}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#71879c]">
                    <Mail size={16} />
                  </div>
                  <input
                    type="email"
                    placeholder="name@imd.gov.in"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (errors.email) setErrors({ ...errors, email: '' });
                    }}
                    className={`!pl-9.5 w-full ${errors.email ? '!border-rose-400 !bg-rose-50/20' : ''}`}
                  />
                </div>
              </div>

              <div>
                <label className="flex items-center justify-between">
                  <span>Phone / Intercom</span>
                  {errors.phone && <span className="text-[11px] text-rose-500 font-semibold">{errors.phone}</span>}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#71879c]">
                    <Phone size={16} />
                  </div>
                  <input
                    type="tel"
                    placeholder="+91 98765 43210"
                    value={phone}
                    onChange={(e) => {
                      setPhone(e.target.value);
                      if (errors.phone) setErrors({ ...errors, phone: '' });
                    }}
                    className={`!pl-9.5 w-full ${errors.phone ? '!border-rose-400 !bg-rose-50/20' : ''}`}
                  />
                </div>
              </div>
            </div>

            <div>
              <label>Institutional Affiliation / Department</label>
              <select
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full text-xs font-semibold text-[#082e52]"
              >
                <option>India Meteorological Department (IMD) - New Delhi HQ</option>
                <option>IMD Regional Meteorological Centre (Pune / Chennai / Mumbai / Kolkata)</option>
                <option>Indian National Centre for Ocean Information Services (INCOIS)</option>
                <option>Indian Institute of Tropical Meteorology (IITM Pune)</option>
                <option>National Centre for Medium Range Weather Forecasting (NCMRWF)</option>
                <option>National Center for Seismology (NCS)</option>
              </select>
            </div>
          </div>

          {/* Section 2: Role-Specific Fields */}
          <div className="mt-4 pt-4 border-t border-[#edf4fa] space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-[#0b63b6] uppercase tracking-wider mb-2">
              <BookOpen size={14} />
              <span>{role} Profile Attributes</span>
            </div>

            {role === 'Trainee' ? (
              <>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="flex items-center justify-between">
                      <span>Highest Qualification</span>
                      {errors.qualification && (
                        <span className="text-[11px] text-rose-500 font-semibold">{errors.qualification}</span>
                      )}
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. M.Sc. Meteorology"
                      value={qualification}
                      onChange={(e) => setQualification(e.target.value)}
                      className={`w-full ${errors.qualification ? '!border-rose-400' : ''}`}
                    />
                  </div>

                  <div>
                    <label className="flex items-center justify-between">
                      <span>Work Experience</span>
                      {errors.workExperience && (
                        <span className="text-[11px] text-rose-500 font-semibold">{errors.workExperience}</span>
                      )}
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. 2 Years at Forecaster Division"
                      value={workExperience}
                      onChange={(e) => setWorkExperience(e.target.value)}
                      className={`w-full ${errors.workExperience ? '!border-rose-400' : ''}`}
                    />
                  </div>
                </div>

                <div>
                  <label className="flex items-center justify-between">
                    <span>Technical Skills (Comma-separated)</span>
                    {errors.skills && <span className="text-[11px] text-rose-500 font-semibold">{errors.skills}</span>}
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. NWP Models, Doppler Radar, Python, Synoptic Charting"
                    value={skills}
                    onChange={(e) => setSkills(e.target.value)}
                    className={`w-full ${errors.skills ? '!border-rose-400' : ''}`}
                  />
                </div>

                <div>
                  <label>Learning Interests & Specializations</label>
                  <input
                    type="text"
                    placeholder="e.g. Tropical Cyclones, Nowcasting, Agromet Advisories"
                    value={interests}
                    onChange={(e) => setInterests(e.target.value)}
                    className="w-full"
                  />
                </div>
              </>
            ) : (
              <>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="flex items-center justify-between">
                      <span>Academic Qualification</span>
                      {errors.trainerQualification && (
                        <span className="text-[11px] text-rose-500 font-semibold">{errors.trainerQualification}</span>
                      )}
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Ph.D. Atmospheric Sciences"
                      value={trainerQualification}
                      onChange={(e) => setTrainerQualification(e.target.value)}
                      className={`w-full ${errors.trainerQualification ? '!border-rose-400' : ''}`}
                    />
                  </div>

                  <div>
                    <label className="flex items-center justify-between">
                      <span>Teaching / Research Experience</span>
                      {errors.trainerExperience && (
                        <span className="text-[11px] text-rose-500 font-semibold">{errors.trainerExperience}</span>
                      )}
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. 10 Years in NWP Mentorship"
                      value={trainerExperience}
                      onChange={(e) => setTrainerExperience(e.target.value)}
                      className={`w-full ${errors.trainerExperience ? '!border-rose-400' : ''}`}
                    />
                  </div>
                </div>

                <div>
                  <label className="flex items-center justify-between">
                    <span>Primary Areas of Expertise</span>
                    {errors.expertise && (
                      <span className="text-[11px] text-rose-500 font-semibold">{errors.expertise}</span>
                    )}
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Mesoscale Modeling, High Performance Computing, Data Assimilation"
                    value={expertise}
                    onChange={(e) => setExpertise(e.target.value)}
                    className={`w-full ${errors.expertise ? '!border-rose-400' : ''}`}
                  />
                </div>

                <div>
                  <label className="flex items-center justify-between">
                    <span>Subjects / Courses Intended to Instruct</span>
                    {errors.subjects && (
                      <span className="text-[11px] text-rose-500 font-semibold">{errors.subjects}</span>
                    )}
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. WRF Parametrization, Doppler Velocity Interpretation"
                    value={subjects}
                    onChange={(e) => setSubjects(e.target.value)}
                    className={`w-full ${errors.subjects ? '!border-rose-400' : ''}`}
                  />
                </div>
              </>
            )}
          </div>

          {/* Section 3: Password Security */}
          <div className="mt-4 pt-4 border-t border-[#edf4fa] space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="flex items-center justify-between">
                  <span>Create Password</span>
                  {errors.password && (
                    <span className="text-[11px] text-rose-500 font-semibold">{errors.password}</span>
                  )}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#71879c]">
                    <Lock size={16} />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Min 8 characters"
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      if (errors.password) setErrors({ ...errors, password: '' });
                    }}
                    className={`!pl-9.5 !pr-10 w-full ${errors.password ? '!border-rose-400 !bg-rose-50/20' : ''}`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-[#71879c] hover:text-[#0b63b6] cursor-pointer"
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>

              <div>
                <label className="flex items-center justify-between">
                  <span>Confirm Password</span>
                  {errors.confirmPassword && (
                    <span className="text-[11px] text-rose-500 font-semibold">{errors.confirmPassword}</span>
                  )}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#71879c]">
                    <Lock size={16} />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Re-enter password"
                    value={confirmPassword}
                    onChange={(e) => {
                      setConfirmPassword(e.target.value);
                      if (errors.confirmPassword) setErrors({ ...errors, confirmPassword: '' });
                    }}
                    className={`!pl-9.5 w-full ${errors.confirmPassword ? '!border-rose-400 !bg-rose-50/20' : ''}`}
                  />
                </div>
              </div>
            </div>
            <p className="text-[11px] text-[#66798c] m-0">
              Password must contain at least 8 characters. Official governmental workstation rules apply.
            </p>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isLoading || adminNotice}
            className="primary cursor-pointer w-full flex items-center justify-center gap-2 !py-2.5 mt-5"
          >
            {isLoading ? (
              <>
                <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24" fill="none">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                <span>Creating Institutional Account...</span>
              </>
            ) : (
              <>
                <span>Complete Registration as {role}</span>
                <ArrowRight size={16} />
              </>
            )}
          </button>

          {/* Signin Redirect */}
          <div className="mt-5 pt-4 border-t border-[#edf4fa] text-center text-sm text-[#66798c]">
            Already have an account?{' '}
            <button
              type="button"
              className="text font-bold text-[#0b63b6] hover:underline cursor-pointer"
              onClick={() => onNavigate('login')}
            >
              Sign in
            </button>
          </div>
        </form>
      </div>
    </main>
  );
};
