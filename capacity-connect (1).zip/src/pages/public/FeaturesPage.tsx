import React from 'react';
import {
  BookOpen,
  FileQuestion,
  Award,
  Users,
  BarChart3,
  Bell,
  FolderArchive,
  CheckCircle2,
  ShieldCheck,
  Cpu,
  Layers,
  Sparkles,
} from 'lucide-react';
import { AppPage } from '../../types';

interface FeaturesPageProps {
  onNavigate: (page: AppPage) => void;
}

export const FeaturesPage: React.FC<FeaturesPageProps> = ({ onNavigate }) => {
  const featureList = [
    {
      icon: BookOpen,
      title: 'Digital Course Delivery',
      desc: 'Modular multi-week syllabi with lecture presentations, video tutorials, and interactive coding notebooks tailored to earth science disciplines.',
      role: 'Trainees & Trainers',
    },
    {
      icon: FileQuestion,
      title: 'Real-time MCQ Assessments',
      desc: 'Subject-specific quizzes with instant grading, countdown timers, randomized answer shuffle, and in-depth rationales for every question.',
      role: 'All Users',
    },
    {
      icon: Award,
      title: 'Tamper-Proof Certifications',
      desc: 'Cryptographically identifiable digital certificates with verifiable unique ID numbers, QR verification codes, and official MoES honors.',
      role: 'Trainees & Admin',
    },
    {
      icon: Users,
      title: 'Competency Mapping Matrix',
      desc: 'Automated skill gap tracking that benchmarks current personnel capability against target departmental requirements for critical operational roles.',
      role: 'Admin & Trainers',
    },
    {
      icon: BarChart3,
      title: 'Analytical Performance Dashboards',
      desc: 'Visual metrics showing score trends, module completion rates, regional participation from different IMD circles, and batch benchmarks.',
      role: 'All Portals',
    },
    {
      icon: FolderArchive,
      title: 'Central MoES Library',
      desc: 'Shared cloud repository of standard operating procedures (SOPs), radar handbooks, Python NetCDF tutorials, and NWP parameter tables.',
      role: 'All Users',
    },
    {
      icon: Bell,
      title: 'Real-Time Broadcast & Notices',
      desc: 'Targeted notifications for batch schedules, assessment deadlines, emergency bulletin trainings, and administrative circulars.',
      role: 'System Wide',
    },
    {
      icon: ShieldCheck,
      title: 'Role-Based Access Control (RBAC)',
      desc: 'Separation of concerns ensuring trainees focus on learning, trainers focus on authoring content, and administrators supervise compliance.',
      role: 'Security',
    },
  ];

  return (
    <main className="page max-w-6xl mx-auto">
      <div className="head">
        <span>CAPABILITIES & ARCHITECTURE</span>
        <h1>Platform Features</h1>
        <p>
          A comprehensive suite of tools built for modern scientific capacity building and technical workforce readiness.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 my-10">
        {featureList.map((f, i) => {
          const Icon = f.icon;
          return (
            <div
              key={i}
              className="bg-white border border-[#dce8f3] rounded-2xl p-6 hover:shadow-md transition-shadow flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-[#e8f5ff] text-[#0b63b6] flex items-center justify-center">
                    <Icon size={24} />
                  </div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#0b63b6] bg-[#f0f7ff] px-2.5 py-1 rounded-md border border-[#cde2f5]">
                    {f.role}
                  </span>
                </div>
                <h3 className="text-lg font-bold text-[#082e52] mb-2">{f.title}</h3>
                <p className="text-sm text-[#66798c] leading-relaxed mb-4">{f.desc}</p>
              </div>

              <div className="pt-3 border-t border-[#f0f4f8] flex items-center text-xs font-semibold text-emerald-700">
                <CheckCircle2 size={14} className="text-emerald-500 mr-1.5" />
                Operational in Prototype
              </div>
            </div>
          );
        })}
      </div>

      <div className="bg-[#f0f7ff] border border-[#cbe3f7] rounded-2xl p-8 text-center my-8">
        <h3 className="text-2xl font-bold text-[#082e52] mb-2">Ready to explore the portal?</h3>
        <p className="text-sm text-[#506579] max-w-lg mx-auto mb-6">
          Access the specialized meteorological curriculum or test the interactive trainee and trainer roles now.
        </p>
        <div className="flex justify-center gap-3">
          <button
            onClick={() => onNavigate('courses')}
            className="primary text-sm font-bold cursor-pointer"
          >
            Browse Course Catalogue
          </button>
          <button
            onClick={() => onNavigate('trainee-dashboard')}
            className="secondary text-sm font-bold cursor-pointer"
          >
            Open Trainee Workspace
          </button>
        </div>
      </div>
    </main>
  );
};
