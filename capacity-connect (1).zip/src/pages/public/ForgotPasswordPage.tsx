import React, { useState } from 'react';
import { GraduationCap, ArrowLeft, Mail, CheckCircle2, AlertCircle, Send } from 'lucide-react';
import { AppPage } from '../../types';

interface ForgotPasswordPageProps {
  onNavigate: (page: AppPage) => void;
}

export const ForgotPasswordPage: React.FC<ForgotPasswordPageProps> = ({ onNavigate }) => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email.trim()) {
      setError('Please enter your official institutional email address.');
      return;
    }
    if (!emailRegex.test(email.trim())) {
      setError('Please provide a valid email format (e.g. yourname@imd.gov.in).');
      return;
    }

    setIsLoading(true);
    // Simulate secure dispatch latency
    setTimeout(() => {
      setIsLoading(false);
      setSubmitted(true);
    }, 600);
  };

  return (
    <main className="auth">
      <div className="authinfo">
        <GraduationCap size={44} className="text-[#58b9f0]" />
        <h1>Account Recovery</h1>
        <p>
          Recover access to your CAPACITY CONNECT learning workspace. Official security codes and single-use password reset tokens are routed directly to your verified departmental inbox.
        </p>
        <div className="mt-8 text-xs text-[#a2d0f5] leading-relaxed space-y-2">
          <div>
            • <b>MoES Central IT Helpdesk:</b> support.capacity@imd.gov.in
          </div>
          <div>
            • <b>Emergency Desk Intercom:</b> +91 11 2462 8900 (Ext. 402)
          </div>
        </div>
      </div>

      <div className="flex items-center justify-center p-6 bg-[#f6faff]">
        <div className="form">
          <h2>Reset password</h2>
          <p className="subtitle">
            Enter your official email to receive a password reset token.
          </p>

          {error && (
            <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2">
              <AlertCircle size={16} className="shrink-0 text-rose-500" />
              <span>{error}</span>
            </div>
          )}

          {!submitted ? (
            <form onSubmit={handleSubmit} noValidate>
              <label>Official Email Address</label>
              <div className="relative mb-4">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#71879c]">
                  <Mail size={16} />
                </div>
                <input
                  type="email"
                  placeholder="e.g. scientist@imd.gov.in"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (error) setError(null);
                  }}
                  className="!pl-9.5 w-full"
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="primary cursor-pointer w-full flex items-center justify-center gap-2 !py-2.5"
              >
                {isLoading ? (
                  <>
                    <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24" fill="none">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                    <span>Verifying Official Registry...</span>
                  </>
                ) : (
                  <>
                    <Send size={15} />
                    <span>Send Password Reset Instructions</span>
                  </>
                )}
              </button>

              <div className="mt-6 text-center">
                <button
                  type="button"
                  onClick={() => onNavigate('login')}
                  className="inline-flex items-center gap-1.5 text-xs text-[#0b63b6] hover:underline font-bold cursor-pointer"
                >
                  <ArrowLeft size={14} /> Back to Sign In
                </button>
              </div>
            </form>
          ) : (
            <div className="text-center py-4">
              <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-3 shadow-inner">
                <CheckCircle2 size={32} />
              </div>
              <h3 className="text-lg font-bold text-[#082e52] mb-1">Reset Link Dispatched</h3>
              <p className="text-xs text-[#66798c] mb-6 leading-relaxed">
                If an official account exists for <b className="text-[#082e52]">{email}</b>, an automated recovery email has been sent with single-use credentials valid for 30 minutes.
              </p>
              <div className="space-y-2">
                <button
                  onClick={() => onNavigate('login')}
                  className="primary text-xs font-bold py-2.5 px-6 cursor-pointer w-full"
                >
                  Return to Sign In
                </button>
                <button
                  onClick={() => {
                    setSubmitted(false);
                    setEmail('');
                  }}
                  className="text-xs text-[#66798c] hover:text-[#0b63b6] font-semibold py-1 block w-full cursor-pointer"
                >
                  Try another email address
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </main>
  );
};
