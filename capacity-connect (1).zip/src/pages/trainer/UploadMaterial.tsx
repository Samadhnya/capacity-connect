import React, { useState } from 'react';
import { UploadCloud, CheckCircle2, FileText, ArrowRight } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, Resource } from '../../types';

interface UploadMaterialProps {
  onNavigate: (page: AppPage) => void;
  onAddResource: (resource: Resource) => void;
}

export const UploadMaterial: React.FC<UploadMaterialProps> = ({
  onNavigate,
  onAddResource,
}) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Forecasting Guidelines');
  const [type, setType] = useState<Resource['type']>('PDF');
  const [size, setSize] = useState('12.4 MB');
  const [fileName, setFileName] = useState('INSAT_3DR_RGB_Guide.pdf');
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newRes: Resource = {
      id: `r-${Date.now()}`,
      title,
      category,
      type,
      size,
      uploadedBy: 'Dr. Rahul Sharma',
      uploadedDate: '2026-09-28',
      downloads: 0,
    };
    onAddResource(newRes);
    setSuccess(true);
    setTimeout(() => {
      onNavigate('trainer-library');
    }, 1200);
  };

  return (
    <div>
      <PageHeader
        badge="CONTENT AUTHORING"
        title="Upload Learning Material"
        subtitle="Publish handbooks, datasets, Jupyter code notebooks, or lecture slides to the central repository."
        backPage="trainer-library"
        onBack={onNavigate}
      />

      {success && (
        <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-semibold flex items-center gap-2">
          <CheckCircle2 size={18} className="text-emerald-600" />
          <span>Material indexed and dispatched to the MoES Knowledge Base!</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="max-w-2xl bg-white border border-[#dce8f3] rounded-2xl p-6 md:p-8 shadow-xs space-y-6">
        <div>
          <label className="text-xs font-bold text-[#3d546a] block mb-1">Material Title</label>
          <input
            type="text"
            required
            placeholder="e.g. INSAT-3DR Multispectral RGB Composite Guide"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-bold text-[#3d546a] block mb-1">Discipline Category</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
            >
              <option>Forecasting Guidelines</option>
              <option>NWP Models</option>
              <option>Radar Meteorology</option>
              <option>Monsoon Dynamics</option>
              <option>Disaster Warning</option>
              <option>Digital Tools</option>
              <option>Oceanography</option>
            </select>
          </div>

          <div>
            <label className="text-xs font-bold text-[#3d546a] block mb-1">File Format / Media Type</label>
            <select
              value={type}
              onChange={(e) => setType(e.target.value as any)}
              className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
            >
              <option value="PDF">PDF Handbook / Documentation</option>
              <option value="Dataset">Dataset / NetCDF / Python Archive</option>
              <option value="Slides">PowerPoint / Presentation Slides</option>
              <option value="Video">Video Recording (MP4)</option>
            </select>
          </div>
        </div>

        {/* Drag and Drop Zone Simulation */}
        <div>
          <label className="text-xs font-bold text-[#3d546a] block mb-1">Select File Artifact</label>
          <div className="border-2 border-dashed border-[#b8cfe3] rounded-2xl p-8 text-center bg-[#fafcff] hover:bg-[#f2f7fc] transition-colors cursor-pointer">
            <UploadCloud size={36} className="text-[#0b63b6] mx-auto mb-2" />
            <b className="text-sm text-[#082e52] block mb-1">Click to browse or drop file here</b>
            <p className="text-xs text-[#66798c] m-0 mb-3">
              Supports PDF, NetCDF, GRIB2, ZIP, MP4 up to 500 MB
            </p>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-white border border-[#dce8f3] rounded-lg text-xs font-mono font-semibold text-[#082e52]">
              <FileText size={13} className="text-[#0b63b6]" /> {fileName} ({size})
            </span>
          </div>
        </div>

        <div className="pt-2 flex justify-end gap-3 border-t border-[#edf2f6]">
          <button
            type="button"
            onClick={() => onNavigate('trainer-library')}
            className="secondary text-xs font-semibold py-2.5 px-4 cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="primary text-xs font-bold py-2.5 px-6 inline-flex items-center gap-2 cursor-pointer"
          >
            <span>Upload & Publish File</span>
            <ArrowRight size={15} />
          </button>
        </div>
      </form>
    </div>
  );
};
