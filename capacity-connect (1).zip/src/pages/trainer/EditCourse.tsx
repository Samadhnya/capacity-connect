import React, { useState } from 'react';
import { Edit3, CheckCircle2, ArrowRight, Trash2, PlusCircle, Loader2, AlertCircle } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, Course } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { courseApiService } from '../../services/courseApiService';

interface EditCourseProps {
  course: Course | null;
  onNavigate: (page: AppPage) => void;
  onUpdateCourse: (updated: Course) => void;
}

export const EditCourse: React.FC<EditCourseProps> = ({
  course,
  onNavigate,
  onUpdateCourse,
}) => {
  const { user } = useAuth();

  if (!course) {
    return (
      <div>
        <PageHeader
          title="Edit Course"
          backPage="trainer-my-courses"
          onBack={onNavigate}
        />
        <div className="bg-white p-8 rounded-2xl border border-[#dce8f3] text-center">
          <p className="text-sm text-[#66798c]">No course selected for editing.</p>
          <button
            onClick={() => onNavigate('trainer-my-courses')}
            className="primary text-xs font-bold mt-4 cursor-pointer"
          >
            Back to My Courses
          </button>
        </div>
      </div>
    );
  }

  const [title, setTitle] = useState(course.title);
  const [category, setCategory] = useState(course.category);
  const [level, setLevel] = useState(course.level);
  const [duration, setDuration] = useState(course.duration);
  const [description, setDescription] = useState(course.description);
  const [status, setStatus] = useState('PUBLISHED');
  const [syllabus, setSyllabus] = useState(course.syllabus);
  const [newModTitle, setNewModTitle] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleAddModule = async () => {
    if (!newModTitle.trim()) return;
    const titleToAdd = newModTitle.trim();
    setSyllabus([...syllabus, { title: titleToAdd, duration: '1 Week', completed: false }]);
    setNewModTitle('');

    // Persist to DB directly
    try {
      const email = user?.email || 'rahul.sharma@imd.gov.in';
      await courseApiService.addModule(course.id, { title: titleToAdd }, email);
    } catch (err) {
      console.warn('Could not persist module to DB:', err);
    }
  };

  const handleRemoveModule = (idx: number) => {
    setSyllabus(syllabus.filter((_, i) => i !== idx));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setErrorMessage(null);

    try {
      const email = user?.email || 'rahul.sharma@imd.gov.in';
      const res = await courseApiService.updateCourse(
        course.id,
        {
          title,
          category,
          level,
          duration,
          description,
          status,
        },
        email
      );

      if (res.success) {
        const updatedCourse: Course = {
          ...course,
          title,
          category,
          level,
          duration,
          description,
          syllabus,
          modulesCount: syllabus.length,
        };

        onUpdateCourse(updatedCourse);
        setSaved(true);
        setTimeout(() => setSaved(false), 3500);
      } else {
        setErrorMessage(res.error || 'Failed to update course in PostgreSQL');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Error communicating with database');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div>
      <PageHeader
        badge="CURRICULUM EDIT"
        title={`Edit ${course.title}`}
        subtitle={`Updating course records in Cloud SQL PostgreSQL • Owned by ${course.trainer}`}
        backPage="trainer-my-courses"
        onBack={onNavigate}
      />

      {saved && (
        <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-semibold flex items-center gap-2 animate-fade-in">
          <CheckCircle2 size={18} className="text-emerald-600 shrink-0" />
          <span>Course records and curriculum syllabus updated in PostgreSQL database!</span>
        </div>
      )}

      {errorMessage && (
        <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm font-semibold flex items-center gap-2 animate-fade-in">
          <AlertCircle size={18} className="text-rose-600 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      <div className="bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs max-w-4xl">
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="text-xs font-bold text-[#082e52] block mb-1">
              Course Title <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="text-xs font-bold text-[#082e52] block mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-xs font-semibold text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
              >
                <option value="Meteorology">Meteorology</option>
                <option value="Remote Sensing">Remote Sensing</option>
                <option value="Climate & Forecasting">Climate & Forecasting</option>
                <option value="Disaster Management">Disaster Management</option>
                <option value="Oceanography">Oceanography</option>
                <option value="Instrumentation">Instrumentation</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-[#082e52] block mb-1">Difficulty Level</label>
              <select
                value={level}
                onChange={(e) => setLevel(e.target.value as any)}
                className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-xs font-semibold text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
              >
                <option value="Beginner">Beginner</option>
                <option value="Intermediate">Intermediate</option>
                <option value="Advanced">Advanced</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-[#082e52] block mb-1">Duration</label>
              <input
                type="text"
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-[#082e52] block mb-1">Course Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-xs font-semibold text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
              >
                <option value="PUBLISHED">PUBLISHED</option>
                <option value="DRAFT">DRAFT</option>
                <option value="ARCHIVED">ARCHIVED</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-[#082e52] block mb-1">
              Course Description & Competency Objectives
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
            />
          </div>

          {/* Module Syllabus Editor */}
          <div className="pt-2">
            <label className="text-xs font-bold text-[#082e52] block mb-2">
              Curriculum Syllabus Modules ({syllabus.length})
            </label>

            <div className="space-y-2 mb-3">
              {syllabus.map((mod, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-3 rounded-xl bg-[#f8fbfe] border border-[#e2edf6] text-xs"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-md bg-[#e8f5ff] text-[#0b63b6] font-bold flex items-center justify-center text-[10px]">
                      {index + 1}
                    </span>
                    <span className="font-semibold text-[#082e52]">{mod.title}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleRemoveModule(index)}
                    className="text-rose-500 hover:text-rose-700 p-1 cursor-pointer"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Enter new syllabus module title..."
                value={newModTitle}
                onChange={(e) => setNewModTitle(e.target.value)}
                className="flex-1 p-2.5 rounded-xl border border-[#d4e1eb] bg-white text-xs text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
              />
              <button
                type="button"
                onClick={handleAddModule}
                className="secondary !text-xs !py-2 !px-4 font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <PlusCircle size={14} /> Add Module
              </button>
            </div>
          </div>

          <div className="pt-4 border-t border-[#edf2f6] flex justify-end gap-3">
            <button
              type="button"
              onClick={() => onNavigate('trainer-my-courses')}
              className="secondary !text-xs !py-2.5 !px-4 font-bold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="primary !text-xs !py-2.5 !px-6 font-bold cursor-pointer flex items-center gap-2"
            >
              {isSaving ? (
                <>
                  <Loader2 size={14} className="animate-spin" />
                  <span>Saving to PostgreSQL...</span>
                </>
              ) : (
                <span>Save Changes</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
