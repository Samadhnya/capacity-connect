import React from 'react';
import { FileQuestion, PlusCircle, Clock, Award, HelpCircle } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, Assessment } from '../../types';

interface QuestionnairesProps {
  assessments: Assessment[];
  onNavigate: (page: AppPage) => void;
  onSelectAssessment: (assessment: Assessment) => void;
}

export const Questionnaires: React.FC<QuestionnairesProps> = ({
  assessments,
  onNavigate,
  onSelectAssessment,
}) => {
  return (
    <div>
      <PageHeader
        badge="ASSESSMENT REPOSITORY"
        title="Questionnaires"
        subtitle="Manage MCQ question banks, time allotments, and passing score thresholds for courses."
        backPage="trainer-dashboard"
        onBack={onNavigate}
        actionText="Create Assessment"
        actionIcon={<PlusCircle size={16} />}
        onAction={() => onNavigate('trainer-create-assessment')}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {assessments.map((a) => (
          <div
            key={a.id}
            className="bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-2 mb-2">
                <span className="text-[11px] font-bold text-[#0b63b6] bg-[#e7f5ff] px-2.5 py-1 rounded-md uppercase">
                  {a.durationMinutes} Minutes
                </span>
                <span className="text-xs font-semibold text-[#66798c]">
                  {a.questionCount} MCQs in Bank
                </span>
              </div>

              <h3 className="text-base font-bold text-[#082e52] mb-1 leading-snug">
                {a.title}
              </h3>
              <p className="text-xs text-[#66798c] mb-4">
                Assigned to: <b className="text-[#082e52]">{a.courseTitle}</b>
              </p>

              <div className="p-3 bg-[#f8fbfe] rounded-xl border border-[#e2edf6] text-xs space-y-2 mb-4">
                <div className="flex justify-between">
                  <span className="text-[#8295a7]">Total Evaluation Marks:</span>
                  <b className="text-[#082e52]">{a.totalMarks} Marks</b>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8295a7]">Benchmark Passing Score:</span>
                  <b className="text-emerald-700">{a.passingMarks} Marks ({Math.round((a.passingMarks/a.totalMarks)*100)}%)</b>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8295a7]">Auto-Grading & Rationales:</span>
                  <b className="text-emerald-600">Enabled</b>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-[#edf2f6] flex gap-2">
              <button
                onClick={() => {
                  onSelectAssessment(a);
                  alert(`Inspecting ${a.title} (${a.questions.length} questions).`);
                }}
                className="secondary flex-1 !text-xs !py-2 font-bold cursor-pointer"
              >
                Inspect Questions
              </button>
              <button
                onClick={() => onNavigate('trainer-create-assessment')}
                className="secondary flex-1 !text-xs !py-2 font-bold cursor-pointer"
              >
                Duplicate / Edit
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
