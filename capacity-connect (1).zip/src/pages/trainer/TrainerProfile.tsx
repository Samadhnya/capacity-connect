import React, { useState, useEffect } from 'react';
import { User, Award, ShieldCheck, Mail, MapPin, Building, CheckCircle2, Phone, Briefcase, BookOpen } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage } from '../../types';
import { useAuth } from '../../context/AuthContext';

interface TrainerProfileProps {
  onNavigate: (page: AppPage) => void;
}

export const TrainerProfile: React.FC<TrainerProfileProps> = ({ onNavigate }) => {
  const { user, updateProfile } = useAuth();
  const [isSaved, setIsSaved] = useState(false);

  const [trainerData, setTrainerData] = useState({
    name: user?.name || 'Dr. Rahul Sharma',
    designation: user?.designation || 'Scientist "F" & Senior Course Director',
    department: user?.department || 'India Meteorological Department (IMD)',
    division: 'Numerical Weather Prediction Division, Mausam Bhawan',
    location: 'New Delhi 110003',
    email: user?.email || 'rahul.sharma@imd.gov.in',
    phone: user?.phone || '+91 11 2461 8241',
    qualification: user?.qualification || 'Ph.D. in Meteorology, Indian Institute of Science (IISc)',
    experienceYears: user?.workExperience || '18 Years',
    specialization:
      user?.expertise?.join(', ') ||
      'High Resolution NWP Models (WRF, GFS), Data Assimilation (3D/4D-Var), Boundary Layer Parametrization',
    accreditationId: user?.id ? `MOES-TRN-${user.id.slice(-4)}` : 'MoES-TRN-9021',
  });

  useEffect(() => {
    if (user) {
      setTrainerData((prev) => ({
        ...prev,
        name: user.name || prev.name,
        email: user.email || prev.email,
        phone: user.phone || prev.phone,
        department: user.department || prev.department,
        designation: user.designation || prev.designation,
        qualification: user.qualification || prev.qualification,
        experienceYears: user.workExperience || prev.experienceYears,
      }));
    }
  }, [user]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      name: trainerData.name,
      phone: trainerData.phone,
      department: trainerData.department,
      designation: trainerData.designation,
      qualification: trainerData.qualification,
      workExperience: trainerData.experienceYears,
    });
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const userInitials = trainerData.name
    .split(' ')
    .map((n) => n[0])
    .slice(0, 2)
    .join('');

  return (
    <div>
      <PageHeader
        badge="TRAINER CREDENTIALS"
        title="Trainer Profile"
        subtitle="Manage faculty biographical information, research credentials, and mentoring specializations."
        backPage="trainer-dashboard"
        onBack={onNavigate}
      />

      {isSaved && (
        <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-semibold flex items-center gap-2">
          <CheckCircle2 size={18} className="text-emerald-600" />
          <span>Trainer dossier successfully updated and verified in the MoES Faculty Directory.</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Faculty Card */}
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-6 text-center shadow-xs">
          <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-[#082e52] to-[#0b63b6] text-white flex items-center justify-center mx-auto mb-4 text-3xl font-extrabold shadow-md">
            {userInitials}
          </div>
          <h2 className="text-xl font-bold text-[#082e52] m-0 mb-1">{trainerData.name}</h2>
          <p className="text-xs text-[#0b63b6] font-bold uppercase tracking-wider mb-2">
            {trainerData.designation}
          </p>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#e7f5ff] text-[#0b63b6] rounded-full text-xs font-semibold border border-[#cbe6fa] mb-6">
            <ShieldCheck size={14} /> MoES Certified Senior Faculty
          </div>

          <div className="space-y-3 text-left border-t border-[#edf2f6] pt-5 text-xs text-[#506579]">
            <div className="flex items-center gap-2">
              <Building size={15} className="text-[#889cb0] shrink-0" />
              <span>{trainerData.division}</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin size={15} className="text-[#889cb0] shrink-0" />
              <span>{trainerData.location}</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail size={15} className="text-[#889cb0] shrink-0" />
              <span className="font-mono">{trainerData.email}</span>
            </div>
            <div className="flex items-center gap-2">
              <Phone size={15} className="text-[#889cb0] shrink-0" />
              <span>{trainerData.phone}</span>
            </div>
          </div>

          <div className="mt-6 pt-5 border-t border-[#edf2f6] text-left">
            <h4 className="text-xs font-bold text-[#082e52] uppercase mb-2">Subject Expertise</h4>
            <div className="flex flex-wrap gap-1.5">
              {(user?.expertise && user.expertise.length > 0
                ? user.expertise
                : ['NWP Modeling', 'Supercomputing', 'WRF-Chem', '3D-Var']
              ).map((exp, idx) => (
                <span key={idx} className="px-2 py-1 rounded bg-[#e8f5ff] text-[#0b63b6] text-[11px] font-bold">
                  {exp}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Right Dossier Form */}
        <div className="lg:col-span-2 bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs">
          <h3 className="text-lg font-bold text-[#082e52] mb-4 pb-2 border-b border-[#edf2f6]">
            Academic & Mentorship Dossier
          </h3>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-[#3d546a] block mb-1">Faculty Name</label>
                <input
                  type="text"
                  value={trainerData.name}
                  onChange={(e) => setTrainerData({ ...trainerData, name: e.target.value })}
                  className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-[#3d546a] block mb-1">Faculty Accreditation ID</label>
                <input
                  type="text"
                  readOnly
                  value={trainerData.accreditationId}
                  className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#f0f4f8] text-sm text-[#66798c] cursor-not-allowed"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-[#3d546a] block mb-1">Designation</label>
                <input
                  type="text"
                  value={trainerData.designation}
                  onChange={(e) => setTrainerData({ ...trainerData, designation: e.target.value })}
                  className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-[#3d546a] block mb-1">Official Email</label>
                <input
                  type="email"
                  readOnly
                  value={trainerData.email}
                  className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#f0f4f8] text-sm text-[#66798c] cursor-not-allowed"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-[#3d546a] block mb-1">Highest Academic Degree</label>
                <input
                  type="text"
                  value={trainerData.qualification}
                  onChange={(e) => setTrainerData({ ...trainerData, qualification: e.target.value })}
                  className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-[#3d546a] block mb-1">Research & Teaching Experience</label>
                <input
                  type="text"
                  value={trainerData.experienceYears}
                  onChange={(e) => setTrainerData({ ...trainerData, experienceYears: e.target.value })}
                  className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-[#3d546a] block mb-1">
                Primary Core Specializations & Training Domain
              </label>
              <textarea
                rows={3}
                value={trainerData.specialization}
                onChange={(e) => setTrainerData({ ...trainerData, specialization: e.target.value })}
                className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
              />
            </div>

            <div className="pt-4 flex justify-end gap-3 border-t border-[#edf2f6]">
              <button
                type="button"
                onClick={() => onNavigate('trainer-dashboard')}
                className="secondary text-xs font-semibold py-2.5 px-4 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="primary text-xs font-bold py-2.5 px-5 cursor-pointer"
              >
                Update Dossier
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
