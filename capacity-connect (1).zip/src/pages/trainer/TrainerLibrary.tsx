import React, { useState } from 'react';
import { FolderArchive, UploadCloud, Search, Download, Trash2, FileText, FileCode, Video } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, Resource } from '../../types';

interface TrainerLibraryProps {
  resources: Resource[];
  onNavigate: (page: AppPage) => void;
  onDeleteResource?: (id: string) => void;
}

export const TrainerLibrary: React.FC<TrainerLibraryProps> = ({
  resources,
  onNavigate,
  onDeleteResource,
}) => {
  const [search, setSearch] = useState('');

  const filtered = resources.filter((r) =>
    r.title.toLowerCase().includes(search.toLowerCase()) ||
    r.category.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <PageHeader
        badge="CONTENT REPOSITORY"
        title="Trainer Library"
        subtitle="Manage instructional slide decks, radar manuals, and model input files authored for courses."
        backPage="trainer-dashboard"
        onBack={onNavigate}
        actionText="Upload New Material"
        actionIcon={<UploadCloud size={16} />}
        onAction={() => onNavigate('trainer-upload-material')}
      />

      <div className="mb-6 relative max-w-md">
        <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#889eb5]" />
        <input
          type="text"
          placeholder="Filter authored materials..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-[#d4e1eb] bg-white text-sm focus:outline-none focus:border-[#0b63b6]"
        />
      </div>

      <div className="data-table-container shadow-xs">
        <table className="data-table">
          <thead>
            <tr>
              <th>Material Name</th>
              <th>Category</th>
              <th>Format</th>
              <th>File Size</th>
              <th>Uploaded Date</th>
              <th>Downloads</th>
              <th className="text-right">Action</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((res) => (
              <tr key={res.id}>
                <td>
                  <div className="flex items-center gap-2.5">
                    <div className="p-1.5 rounded-lg bg-[#f0f7ff] text-[#0b63b6]">
                      <FileText size={18} />
                    </div>
                    <div>
                      <b className="text-xs text-[#082e52] block">{res.title}</b>
                      <small className="text-[#879bb0] text-[11px] font-medium">{res.uploadedBy}</small>
                    </div>
                  </div>
                </td>
                <td className="text-xs text-[#506579]">{res.category}</td>
                <td>
                  <span className="text-xs font-semibold text-[#0b63b6] bg-[#e7f5ff] px-2 py-0.5 rounded">
                    {res.type}
                  </span>
                </td>
                <td className="text-xs text-[#506579]">{res.size}</td>
                <td className="text-xs text-[#506579]">{res.uploadedDate}</td>
                <td className="text-xs text-[#506579] font-bold">{res.downloads}</td>
                <td className="text-right">
                  <div className="flex justify-end gap-1.5">
                    <button
                      onClick={() => alert(`Downloading ${res.title}...`)}
                      className="secondary !py-1 !px-2 !text-xs"
                      title="Download"
                    >
                      <Download size={13} />
                    </button>
                    {onDeleteResource && (
                      <button
                        onClick={() => onDeleteResource(res.id)}
                        className="secondary !py-1 !px-2 !text-xs text-rose-500 hover:text-rose-700"
                        title="Delete"
                      >
                        <Trash2 size={13} />
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
