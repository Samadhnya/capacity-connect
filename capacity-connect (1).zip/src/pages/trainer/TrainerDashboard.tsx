import React from 'react';
import {
  BookOpen,
  Users,
  FileQuestion,
  BarChart3,
  PlusCircle,
  UploadCloud,
  CheckCircle2,
  TrendingUp,
  ArrowRight,
} from 'lucide-react';
import { AppPage, Course, TraineeUser, Assessment } from '../../types';

interface TrainerDashboardProps {
  courses: Course[];
  trainees: TraineeUser[];
  assessments: Assessment[];
  onNavigate: (page: AppPage) => void;
  onSelectCourse: (course: Course) => void;
}

export const TrainerDashboard: React.FC<TrainerDashboardProps> = ({
  courses,
  trainees,
  assessments,
  onNavigate,
  onSelectCourse,
}) => {
  return (
    <div>
      <p className="text-xs font-bold text-[#8295a7] uppercase tracking-wider mb-1">
        CAPACITY CONNECT / TRAINER CONSOLE
      </p>
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-extrabold text-[#082e52] tracking-tight m-0">
            Trainer Command Hub
          </h1>
          <p className="text-sm text-[#66798c] mt-1 mb-0">
            Dr. Rahul Sharma • Scientist "F", IMD Delhi • Lead Mentor (NWP & High Performance Computing)
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('trainer-upload-material')}
            className="secondary text-xs font-bold py-2.5 px-3.5 inline-flex items-center gap-1.5 cursor-pointer"
          >
            <UploadCloud size={14} /> Upload Material
          </button>
          <button
            onClick={() => onNavigate('trainer-create-course')}
            className="primary text-xs font-bold py-2.5 px-4 inline-flex items-center gap-1.5 cursor-pointer"
          >
            <PlusCircle size={14} /> Create Course
          </button>
        </div>
      </div>

      {/* Trainer Stats (exact numbers from original prototype) */}
      <div className="dashstats">
        <div>
          <BookOpen />
          <small>Total Courses Supervised</small>
          <strong>18</strong>
        </div>
        <div>
          <Users />
          <small>Active Trainees</small>
          <strong>428</strong>
        </div>
        <div>
          <FileQuestion />
          <small>Assessments Authored</small>
          <strong>24</strong>
        </div>
        <div>
          <BarChart3 />
          <small>Avg. Cadre Performance</small>
          <strong>86%</strong>
        </div>
      </div>

      {/* Panels Grid */}
      <div className="panels">
        {/* Left: Courses Supervised */}
        <div className="panel">
          <h2>
            <span>Assigned Courses & Active Batches</span>
            <button
              onClick={() => onNavigate('trainer-my-courses')}
              className="text-xs text-[#0b63b6] hover:underline font-bold"
            >
              Manage All →
            </button>
          </h2>

          <div className="space-y-1">
            {courses.slice(0, 4).map((c) => (
              <div
                key={c.id}
                onClick={() => {
                  onSelectCourse(c);
                  onNavigate('trainer-edit-course');
                }}
                className="row hover:bg-[#f8fbfe] rounded-xl px-2 cursor-pointer transition-colors"
              >
                <div className="w-10 h-10 rounded-xl bg-[#e8f5ff] text-[#0b63b6] flex items-center justify-center shrink-0">
                  <BookOpen size={18} />
                </div>
                <span>
                  <b>{c.title}</b>
                  <small>
                    {c.enrolledCount} Trainees Enrolled • Rating ★ {c.rating} • {c.modulesCount} Modules
                  </small>
                </span>
                <span className="text-xs font-bold text-[#0b63b6] bg-[#f0f7ff] px-2 py-1 rounded-md shrink-0 border border-[#d4e4f5]">
                  Edit Course
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Quick actions & Top Trainee Performers */}
        <div className="space-y-6">
          <div className="panel">
            <h2>
              <span>Top Trainees in Batch</span>
              <button
                onClick={() => onNavigate('trainer-trainees')}
                className="text-xs text-[#0b63b6] hover:underline font-bold"
              >
                All Trainees →
              </button>
            </h2>

            <div className="space-y-3">
              {trainees.slice(0, 3).map((t) => (
                <div
                  key={t.id}
                  className="flex items-center justify-between p-3 rounded-xl bg-[#f8fbfe] border border-[#e2edf6]"
                >
                  <div>
                    <b className="text-xs text-[#082e52] block">{t.name}</b>
                    <small className="text-[#66798c] text-[11px]">{t.department}</small>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-black text-emerald-600 block">{t.avgScore}%</span>
                    <span className="text-[10px] text-[#8295a7]">{t.completedCoursesCount} completed</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="panel">
            <h2>Trainer Shortcuts</h2>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={() => onNavigate('trainer-create-assessment')}
                className="secondary !py-2.5 !text-xs font-bold flex flex-col items-center gap-1.5 cursor-pointer text-center"
              >
                <FileQuestion size={18} className="text-[#0b63b6]" />
                <span>New Assessment</span>
              </button>
              <button
                onClick={() => onNavigate('trainer-upload-material')}
                className="secondary !py-2.5 !text-xs font-bold flex flex-col items-center gap-1.5 cursor-pointer text-center"
              >
                <UploadCloud size={18} className="text-[#0b63b6]" />
                <span>Upload Handbook</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
