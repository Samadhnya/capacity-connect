import React, { useState } from 'react';
import { PlusCircle, Trash2, CheckCircle2, ArrowRight, FileQuestion } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, Course, Assessment, Question } from '../../types';

interface CreateAssessmentProps {
  courses: Course[];
  onNavigate: (page: AppPage) => void;
  onAddAssessment: (assessment: Assessment) => void;
}

export const CreateAssessment: React.FC<CreateAssessmentProps> = ({
  courses,
  onNavigate,
  onAddAssessment,
}) => {
  const [title, setTitle] = useState('');
  const [courseId, setCourseId] = useState(courses[0]?.id || '');
  const [duration, setDuration] = useState(30);
  const [totalMarks, setTotalMarks] = useState(50);
  const [passingMarks, setPassingMarks] = useState(35);

  const [questionText, setQuestionText] = useState('');
  const [opt0, setOpt0] = useState('');
  const [opt1, setOpt1] = useState('');
  const [opt2, setOpt2] = useState('');
  const [opt3, setOpt3] = useState('');
  const [correctIdx, setCorrectIdx] = useState(0);
  const [explanation, setExplanation] = useState('');

  const [questions, setQuestions] = useState<Question[]>([
    {
      id: 1,
      question: 'Which observational platform provides continuous 3-dimensional atmospheric temperature soundings over oceanic basins?',
      options: ['Geostationary Hyperspectral Sounders', 'Surface Cup Anemometers', 'Pilot Balloons', 'Tide Gauges'],
      correctIndex: 0,
      explanation: 'Geostationary and polar sounders retrieve vertical temperature and humidity profiles across open oceans.',
    },
  ]);
  const [success, setSuccess] = useState(false);

  const handleAddQuestion = () => {
    if (!questionText.trim() || !opt0.trim() || !opt1.trim()) {
      alert('Please provide question text and at least 2 options.');
      return;
    }

    const newQ: Question = {
      id: questions.length + 1,
      question: questionText.trim(),
      options: [opt0.trim(), opt1.trim(), opt2.trim() || 'Option C', opt3.trim() || 'Option D'],
      correctIndex: correctIdx,
      explanation: explanation.trim() || 'Operational meteorology standard guideline.',
    };

    setQuestions([...questions, newQ]);
    setQuestionText('');
    setOpt0('');
    setOpt1('');
    setOpt2('');
    setOpt3('');
    setExplanation('');
  };

  const handleRemoveQuestion = (idx: number) => {
    setQuestions(questions.filter((_, i) => i !== idx));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (questions.length === 0) {
      alert('Please add at least 1 question to the assessment.');
      return;
    }

    const selectedCourse = courses.find((c) => c.id === courseId);
    const newAssessment: Assessment = {
      id: `a-${Date.now()}`,
      title,
      courseId,
      courseTitle: selectedCourse?.title || 'Meteorological Course',
      durationMinutes: Number(duration),
      totalMarks: Number(totalMarks),
      passingMarks: Number(passingMarks),
      questionCount: questions.length,
      status: 'Available',
      questions,
    };

    onAddAssessment(newAssessment);
    setSuccess(true);
    setTimeout(() => {
      onNavigate('trainer-questionnaires');
    }, 1200);
  };

  return (
    <div>
      <PageHeader
        badge="EVALUATION BUILDER"
        title="Create Assessment"
        subtitle="Author multiple choice questionnaires, designate rationales, and set passing benchmarks."
        backPage="trainer-questionnaires"
        onBack={onNavigate}
      />

      {success && (
        <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-semibold flex items-center gap-2">
          <CheckCircle2 size={18} className="text-emerald-600" />
          <span>Assessment published and enabled for all enrolled trainees!</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="max-w-3xl space-y-6">
        {/* Meta details */}
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs space-y-4">
          <h3 className="text-base font-bold text-[#082e52] m-0 mb-1">Assessment Configuration</h3>

          <div>
            <label className="text-xs font-bold text-[#3d546a] block mb-1">Assessment Title</label>
            <input
              type="text"
              required
              placeholder="e.g. Cyclone Dynamics & Storm Surge Model Evaluation"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="sm:col-span-2">
              <label className="text-xs font-bold text-[#3d546a] block mb-1">Associated Course</label>
              <select
                value={courseId}
                onChange={(e) => setCourseId(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
              >
                {courses.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.title}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-[#3d546a] block mb-1">Duration (Mins)</label>
              <input
                type="number"
                required
                value={duration}
                onChange={(e) => setDuration(Number(e.target.value))}
                className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-[#3d546a] block mb-1">Passing Mark</label>
              <input
                type="number"
                required
                value={passingMarks}
                onChange={(e) => setPassingMarks(Number(e.target.value))}
                className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
              />
            </div>
          </div>
        </div>

        {/* Existing Questions List */}
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs">
          <h3 className="text-base font-bold text-[#082e52] mb-3 flex items-center justify-between">
            <span>Questions in Bank ({questions.length})</span>
            <span className="text-xs text-[#66798c]">Auto-graded instantly</span>
          </h3>

          <div className="space-y-3 mb-6">
            {questions.map((q, idx) => (
              <div
                key={idx}
                className="p-3.5 rounded-xl bg-[#f8fbfe] border border-[#e2edf6] text-xs space-y-1.5"
              >
                <div className="flex items-start justify-between gap-2">
                  <b className="text-sm text-[#082e52]">
                    {idx + 1}. {q.question}
                  </b>
                  <button
                    type="button"
                    onClick={() => handleRemoveQuestion(idx)}
                    className="text-rose-500 hover:text-rose-700 p-1 cursor-pointer"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-1 text-[#506579] pl-2">
                  {q.options.map((opt, oIdx) => (
                    <div
                      key={oIdx}
                      className={oIdx === q.correctIndex ? 'font-bold text-emerald-700' : ''}
                    >
                      {String.fromCharCode(65 + oIdx)}. {opt} {oIdx === q.correctIndex && '✓ (Correct)'}
                    </div>
                  ))}
                </div>
                <div className="text-[#7e91a3] italic pl-2 pt-1 border-t border-[#edf4f9]">
                  <b>Explanation:</b> {q.explanation}
                </div>
              </div>
            ))}
          </div>

          {/* Add Question Box */}
          <div className="p-4 rounded-xl border border-[#cde2f5] bg-[#fafcff] space-y-3">
            <h4 className="text-xs font-bold text-[#0b63b6] uppercase m-0">
              Add New Question to Assessment
            </h4>

            <div>
              <label className="text-xs font-semibold text-[#3d546a] block mb-1">Question Prompt</label>
              <textarea
                rows={2}
                placeholder="Enter scientific question..."
                value={questionText}
                onChange={(e) => setQuestionText(e.target.value)}
                className="w-full p-2.5 rounded-lg border border-[#d4e1eb] bg-white text-xs text-[#082e52] focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] font-semibold text-[#3d546a] block mb-0.5">Option A</label>
                <input
                  type="text"
                  placeholder="Option A text"
                  value={opt0}
                  onChange={(e) => setOpt0(e.target.value)}
                  className="w-full p-2 rounded-lg border border-[#d4e1eb] bg-white text-xs text-[#082e52]"
                />
              </div>
              <div>
                <label className="text-[11px] font-semibold text-[#3d546a] block mb-0.5">Option B</label>
                <input
                  type="text"
                  placeholder="Option B text"
                  value={opt1}
                  onChange={(e) => setOpt1(e.target.value)}
                  className="w-full p-2 rounded-lg border border-[#d4e1eb] bg-white text-xs text-[#082e52]"
                />
              </div>
              <div>
                <label className="text-[11px] font-semibold text-[#3d546a] block mb-0.5">Option C</label>
                <input
                  type="text"
                  placeholder="Option C text"
                  value={opt2}
                  onChange={(e) => setOpt2(e.target.value)}
                  className="w-full p-2 rounded-lg border border-[#d4e1eb] bg-white text-xs text-[#082e52]"
                />
              </div>
              <div>
                <label className="text-[11px] font-semibold text-[#3d546a] block mb-0.5">Option D</label>
                <input
                  type="text"
                  placeholder="Option D text"
                  value={opt3}
                  onChange={(e) => setOpt3(e.target.value)}
                  className="w-full p-2 rounded-lg border border-[#d4e1eb] bg-white text-xs text-[#082e52]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div>
                <label className="text-[11px] font-semibold text-[#3d546a] block mb-0.5">Correct Option</label>
                <select
                  value={correctIdx}
                  onChange={(e) => setCorrectIdx(Number(e.target.value))}
                  className="w-full p-2 rounded-lg border border-[#d4e1eb] bg-white text-xs text-[#082e52] font-bold"
                >
                  <option value={0}>Option A is Correct</option>
                  <option value={1}>Option B is Correct</option>
                  <option value={2}>Option C is Correct</option>
                  <option value={3}>Option D is Correct</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-[#3d546a] block mb-0.5">Answer Rationale / Explanation</label>
                <input
                  type="text"
                  placeholder="Explanation shown after submission..."
                  value={explanation}
                  onChange={(e) => setExplanation(e.target.value)}
                  className="w-full p-2 rounded-lg border border-[#d4e1eb] bg-white text-xs text-[#082e52]"
                />
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={handleAddQuestion}
                className="secondary !text-xs !py-2 !px-3 font-bold inline-flex items-center gap-1.5 cursor-pointer"
              >
                <PlusCircle size={14} /> Add Question to Bank
              </button>
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-3 pt-4">
          <button
            type="button"
            onClick={() => onNavigate('trainer-questionnaires')}
            className="secondary text-xs font-semibold py-2.5 px-4 cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="primary text-xs font-bold py-2.5 px-6 inline-flex items-center gap-2 cursor-pointer"
          >
            <span>Save & Publish Assessment</span>
            <ArrowRight size={15} />
          </button>
        </div>
      </form>
    </div>
  );
};
