import React, { useState, useEffect } from 'react';
import { Users, Search, Mail, Building, CheckCircle2, TrendingUp, Award, RefreshCw, Loader2, BookOpen } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, TraineeUser } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { courseApiService, DbCourseTrainee } from '../../services/courseApiService';

interface TraineesListProps {
  trainees: TraineeUser[];
  onNavigate: (page: AppPage) => void;
}

export const TraineesList: React.FC<TraineesListProps> = ({
  trainees: fallbackTrainees,
  onNavigate,
}) => {
  const { user } = useAuth();
  const [dbTrainees, setDbTrainees] = useState<DbCourseTrainee[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [search, setSearch] = useState('');
  const [deptFilter, setDeptFilter] = useState('All');

  const fetchEnrolledTrainees = async () => {
    setIsLoading(true);
    try {
      const email = user?.email || 'rahul.sharma@imd.gov.in';
      const res = await courseApiService.getCourseEnrolledTrainees('c-1', email);
      if (res.trainees && res.trainees.length > 0) {
        setDbTrainees(res.trainees);
      }
    } catch (err) {
      console.warn('Error fetching trainees from DB:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchEnrolledTrainees();
  }, [user?.email]);

  const displayList: (TraineeUser & { progress: number })[] =
    dbTrainees.length > 0
      ? dbTrainees.map((dt) => ({
          id: String(dt.userId),
          name: dt.name,
          email: dt.email,
          division: dt.division || 'National Weather Forecasting Centre',
          department: dt.department || 'IMD New Delhi',
          enrolledCoursesCount: 3,
          completedCoursesCount: dt.completed ? 1 : 0,
          avgScore: 92,
          status: 'Active' as const,
          progress: dt.progress,
        }))
      : fallbackTrainees.map((ft) => ({ ...ft, progress: 65 }));

  const filtered = displayList.filter((t) => {
    const matchesSearch =
      t.name.toLowerCase().includes(search.toLowerCase()) ||
      t.email.toLowerCase().includes(search.toLowerCase()) ||
      t.division.toLowerCase().includes(search.toLowerCase());
    const matchesDept = deptFilter === 'All' || t.department.includes(deptFilter);
    return matchesSearch && matchesDept;
  });

  return (
    <div>
      <div className="flex items-center justify-between gap-3 mb-2">
        <PageHeader
          badge="CADRE OVERSIGHT"
          title="Trainees"
          subtitle="Roster of scientific personnel enrolled across your supervised meteorological programs in Cloud SQL."
          backPage="trainer-dashboard"
          onBack={onNavigate}
          actionText="View Performance Analytics"
          actionIcon={<TrendingUp size={16} />}
          onAction={() => onNavigate('trainer-trainee-performance')}
        />
        <button
          onClick={fetchEnrolledTrainees}
          disabled={isLoading}
          className="secondary !py-2 !px-3 !text-xs cursor-pointer flex items-center gap-1.5 shrink-0"
          title="Refresh roster from PostgreSQL"
        >
          <RefreshCw size={13} className={isLoading ? 'animate-spin' : ''} />
          <span>Sync from Database</span>
        </button>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#889eb5]" />
          <input
            type="text"
            placeholder="Search trainee by name, email, or division..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-[#d4e1eb] bg-white text-sm focus:outline-none focus:border-[#0b63b6]"
          />
        </div>
        <select
          value={deptFilter}
          onChange={(e) => setDeptFilter(e.target.value)}
          aria-label="Filter by Department"
          className="py-2.5 px-3 rounded-xl border border-[#d4e1eb] bg-white text-sm font-semibold text-[#082e52] focus:outline-none cursor-pointer"
        >
          <option value="All">All Departments</option>
          <option value="IMD">IMD Stations</option>
          <option value="INCOIS">INCOIS</option>
          <option value="IITM">IITM</option>
          <option value="NCMRWF">NCMRWF</option>
        </select>
      </div>

      {isLoading ? (
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-16 text-center text-[#647b92]">
          <Loader2 size={36} className="animate-spin text-[#0b63b6] mx-auto mb-3" />
          <p className="text-sm font-semibold">Retrieving enrolled personnel from PostgreSQL database...</p>
        </div>
      ) : (
        <div className="bg-white border border-[#dce8f3] rounded-2xl overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#f8fbfe] border-b border-[#e5eef6] text-[#526a80] font-bold uppercase tracking-wider">
                <tr>
                  <th className="py-3.5 px-4">Trainee Officer</th>
                  <th className="py-3.5 px-4">Division & Station</th>
                  <th className="py-3.5 px-4">Enrolled Course Progress</th>
                  <th className="py-3.5 px-4 text-center">Avg Score</th>
                  <th className="py-3.5 px-4 text-center">Status</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#edf3f8]">
                {filtered.map((t) => (
                  <tr key={t.id} className="hover:bg-[#fcfdfe] transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-full bg-[#e8f5ff] text-[#0b63b6] flex items-center justify-center font-bold text-xs shrink-0">
                          {t.name[0]}
                        </div>
                        <div>
                          <b className="text-xs text-[#082e52] block">{t.name}</b>
                          <span className="text-[11px] text-[#6e859b] flex items-center gap-1 font-mono">
                            <Mail size={11} /> {t.email}
                          </span>
                        </div>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-[#506579]">
                      <span className="font-semibold text-[#082e52] block">{t.division}</span>
                      <span className="text-[11px] text-[#7b90a4]">{t.department}</span>
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="w-40">
                        <div className="flex justify-between text-[11px] font-bold mb-1">
                          <span className="text-[#082e52]">Curriculum</span>
                          <span className="text-[#0b63b6]">{t.progress}%</span>
                        </div>
                        <div className="w-full bg-[#e8f1f8] h-1.5 rounded-full overflow-hidden">
                          <div
                            className="bg-[#0b63b6] h-full rounded-full"
                            style={{ width: `${t.progress}%` }}
                          />
                        </div>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-center font-extrabold text-[#082e52]">
                      {t.avgScore}%
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                        {t.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={() => onNavigate('trainer-trainee-performance')}
                        className="secondary !text-[11px] !py-1 !px-2.5 font-bold cursor-pointer"
                      >
                        Analytics
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
