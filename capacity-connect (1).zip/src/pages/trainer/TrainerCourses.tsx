import React, { useState, useEffect } from 'react';
import { BookOpen, PlusCircle, Users, Clock3, Edit3, Trash2, Eye, RefreshCw, Loader2, AlertCircle, CheckCircle } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, Course } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { courseApiService, DbCourse } from '../../services/courseApiService';

interface TrainerCoursesProps {
  courses: Course[];
  onNavigate: (page: AppPage) => void;
  onSelectCourse: (course: Course) => void;
}

export const TrainerCourses: React.FC<TrainerCoursesProps> = ({
  courses: fallbackCourses,
  onNavigate,
  onSelectCourse,
}) => {
  const { user } = useAuth();
  const [trainerCourses, setTrainerCourses] = useState<DbCourse[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const fetchTrainerCourses = async () => {
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const email = user?.email || 'rahul.sharma@imd.gov.in';
      const res = await courseApiService.getTrainerCourses(email);
      if (res.courses) {
        setTrainerCourses(res.courses);
      }
    } catch (err: any) {
      console.warn('Failed to load trainer courses:', err);
      setErrorMsg('Could not load authored courses from database.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchTrainerCourses();
  }, [user?.email]);

  const handleDelete = async (courseId: string) => {
    if (!confirm('Are you sure you want to delete this course from the database? All syllabus modules will be removed.')) {
      return;
    }

    setDeletingId(courseId);
    setErrorMsg(null);
    try {
      const email = user?.email || 'rahul.sharma@imd.gov.in';
      const res = await courseApiService.deleteCourse(courseId, email);
      if (res.success) {
        setSuccessMsg(`Course ${courseId} deleted successfully.`);
        setTrainerCourses((prev) => prev.filter((c) => c.id !== courseId));
        setTimeout(() => setSuccessMsg(null), 4000);
      } else {
        setErrorMsg(res.error || 'Failed to delete course');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Error deleting course');
    } finally {
      setDeletingId(null);
    }
  };

  const handleEdit = (c: DbCourse) => {
    const courseObj: Course = {
      id: c.id,
      title: c.title,
      description: c.description || '',
      trainer: c.trainerName,
      trainerRole: 'Scientist "F", IMD Delhi',
      category: c.category,
      duration: c.duration,
      level: (c.level as any) || 'Intermediate',
      rating: parseFloat(c.rating) || 5.0,
      enrolledCount: c.enrolledCount || 0,
      modulesCount: c.totalModules || 4,
      progress: 0,
      isEnrolled: false,
      syllabus: [],
    };
    onSelectCourse(courseObj);
    onNavigate('trainer-edit-course');
  };

  const displayList: any[] =
    trainerCourses.length > 0
      ? trainerCourses
      : fallbackCourses.map((fc) => ({
          id: fc.id,
          title: fc.title,
          description: fc.description,
          category: fc.category,
          rating: fc.rating,
          enrolledCount: fc.enrolledCount,
          duration: fc.duration,
          totalModules: fc.modulesCount,
          status: 'PUBLISHED',
        }));

  return (
    <div>
      <div className="flex items-center justify-between gap-3 mb-2">
        <PageHeader
          badge="CURRICULUM MANAGEMENT"
          title="My Authored Courses"
          subtitle="Manage meteorological courses authored by your institutional account stored in Cloud SQL PostgreSQL."
          backPage="trainer-dashboard"
          onBack={onNavigate}
          actionText="Create New Course"
          actionIcon={<PlusCircle size={16} />}
          onAction={() => onNavigate('trainer-create-course')}
        />
        <button
          onClick={fetchTrainerCourses}
          disabled={isLoading}
          className="secondary !py-2 !px-3 !text-xs cursor-pointer flex items-center gap-1.5 shrink-0"
          title="Refresh courses from database"
        >
          <RefreshCw size={13} className={isLoading ? 'animate-spin' : ''} />
          <span>Sync from Database</span>
        </button>
      </div>

      {successMsg && (
        <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-semibold flex items-center gap-2 animate-fade-in">
          <CheckCircle size={18} className="text-emerald-600 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {errorMsg && (
        <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm font-semibold flex items-center gap-2 animate-fade-in">
          <AlertCircle size={18} className="text-rose-600 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {isLoading ? (
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-16 text-center text-[#647b92]">
          <Loader2 size={36} className="animate-spin text-[#0b63b6] mx-auto mb-3" />
          <p className="text-sm font-semibold">Loading authored curriculum from Cloud SQL...</p>
        </div>
      ) : displayList.length === 0 ? (
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-12 text-center text-[#647b92]">
          <BookOpen size={36} className="text-[#889eb5] mx-auto mb-2" />
          <h3 className="text-base font-bold text-[#082e52]">No courses authored yet</h3>
          <p className="text-xs text-[#506579] mt-1">Start by authoring your first training program.</p>
          <button
            onClick={() => onNavigate('trainer-create-course')}
            className="primary !text-xs !py-2.5 !px-4 mt-4 font-bold cursor-pointer inline-flex items-center gap-1.5"
          >
            <PlusCircle size={14} /> Create Course
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayList.map((course) => (
            <div
              key={course.id}
              className="bg-white border border-[#dce8f3] rounded-2xl p-6 flex flex-col justify-between hover:shadow-md transition-shadow"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <span className="text-[11px] font-bold uppercase text-[#0b63b6] bg-[#e7f5ff] px-2.5 py-1 rounded-md">
                    {course.category}
                  </span>
                  <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    {course.status || 'PUBLISHED'}
                  </span>
                </div>

                <h3 className="text-base font-bold text-[#082e52] mb-1.5 leading-snug">
                  {course.title}
                </h3>
                <p className="text-xs text-[#66798c] mb-4 line-clamp-2 leading-relaxed">
                  {course.description}
                </p>

                <div className="space-y-1.5 text-xs text-[#506579] mb-4">
                  <div className="flex items-center gap-1.5">
                    <Users size={14} className="text-[#899db0]" />
                    <span><b>{course.enrolledCount ?? 0}</b> Trainees Enrolled</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Clock3 size={14} className="text-[#899db0]" />
                    <span>{course.duration} • {course.totalModules || 4} Modules</span>
                  </div>
                </div>
              </div>

              <div className="border-t border-[#edf2f6] pt-4 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => handleEdit(course)}
                  className="secondary flex-1 !text-xs !py-2 font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Edit3 size={14} /> Edit Course
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('trainer-trainees')}
                  className="secondary !text-xs !py-2 !px-3 font-bold text-[#0b63b6] cursor-pointer"
                  title="View enrolled trainees"
                >
                  <Users size={14} />
                </button>
                <button
                  type="button"
                  disabled={deletingId === course.id}
                  onClick={() => handleDelete(course.id)}
                  className="text-xs text-rose-600 hover:bg-rose-50 p-2 rounded-lg cursor-pointer transition-colors border border-transparent hover:border-rose-200"
                  title="Delete course"
                >
                  <Trash2 size={15} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
