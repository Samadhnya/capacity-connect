import React, { useState } from 'react';
import { PlusCircle, Trash2, CheckCircle2, ArrowRight, BookOpen, Loader2, AlertCircle } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, Course } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { courseApiService } from '../../services/courseApiService';

interface CreateCourseProps {
  onNavigate: (page: AppPage) => void;
  onAddCourse: (course: Course) => void;
}

export const CreateCourse: React.FC<CreateCourseProps> = ({
  onNavigate,
  onAddCourse,
}) => {
  const { user } = useAuth();
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Meteorology');
  const [level, setLevel] = useState<'Beginner' | 'Intermediate' | 'Advanced'>('Intermediate');
  const [duration, setDuration] = useState('6 Weeks');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState('PUBLISHED');
  const [modules, setModules] = useState<string[]>([
    'Fundamental Atmospheric Equations & Thermodynamic Principles',
    'Instrumentation Calibration and Telemetry Pipelines',
    'Real-time Operational Workflow and Hands-on Practical Lab',
  ]);
  const [newModuleTitle, setNewModuleTitle] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleAddModule = () => {
    if (!newModuleTitle.trim()) return;
    setModules([...modules, newModuleTitle.trim()]);
    setNewModuleTitle('');
  };

  const handleRemoveModule = (index: number) => {
    setModules(modules.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      const email = user?.email || 'rahul.sharma@imd.gov.in';
      const res = await courseApiService.createCourse(
        {
          title,
          description,
          category,
          duration,
          level,
          status,
          modules,
        },
        email
      );

      if (res.success && res.course) {
        const createdCourse: Course = {
          id: res.course.id,
          title: res.course.title,
          trainer: res.course.trainerName,
          trainerRole: 'Lead Mentor, IMD',
          level: (res.course.level as any) || level,
          duration: res.course.duration,
          category: res.course.category,
          description: res.course.description || description,
          enrolledCount: 0,
          rating: 5.0,
          modulesCount: modules.length,
          progress: 0,
          isEnrolled: false,
          syllabus: modules.map((m) => ({ title: m, duration: '1 Week', completed: false })),
        };

        onAddCourse(createdCourse);
        setSuccess(true);
        setTimeout(() => {
          onNavigate('trainer-my-courses');
        }, 1500);
      } else {
        setErrorMessage(res.error || 'Failed to author course in database.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Error communicating with database server.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div>
      <PageHeader
        badge="COURSE AUTHORING"
        title="Author New Program"
        subtitle="Design and publish institutional meteorological courses directly into the Cloud SQL PostgreSQL database."
        backPage="trainer-my-courses"
        onBack={onNavigate}
      />

      {success && (
        <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-semibold flex items-center gap-2 animate-fade-in">
          <CheckCircle2 size={18} className="text-emerald-600 shrink-0" />
          <span>Course successfully authored and stored in PostgreSQL database! Redirecting...</span>
        </div>
      )}

      {errorMessage && (
        <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm font-semibold flex items-center gap-2 animate-fade-in">
          <AlertCircle size={18} className="text-rose-600 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      <div className="bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs max-w-4xl">
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="text-xs font-bold text-[#082e52] block mb-1">
              Course Title <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Advanced Numerical Weather Prediction (NWP) Modeling"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="text-xs font-bold text-[#082e52] block mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-xs font-semibold text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
              >
                <option value="Meteorology">Meteorology</option>
                <option value="Remote Sensing">Remote Sensing</option>
                <option value="Climate & Forecasting">Climate & Forecasting</option>
                <option value="Disaster Management">Disaster Management</option>
                <option value="Oceanography">Oceanography</option>
                <option value="Instrumentation">Instrumentation</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-[#082e52] block mb-1">Difficulty Level</label>
              <select
                value={level}
                onChange={(e) => setLevel(e.target.value as any)}
                className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-xs font-semibold text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
              >
                <option value="Beginner">Beginner</option>
                <option value="Intermediate">Intermediate</option>
                <option value="Advanced">Advanced</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-[#082e52] block mb-1">Duration</label>
              <input
                type="text"
                placeholder="e.g. 6 Weeks"
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-[#082e52] block mb-1">Course Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-xs font-semibold text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
              >
                <option value="PUBLISHED">PUBLISHED</option>
                <option value="DRAFT">DRAFT</option>
                <option value="ARCHIVED">ARCHIVED</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-[#082e52] block mb-1">
              Course Description & Competency Objectives
            </label>
            <textarea
              rows={3}
              placeholder="Outline the operational significance, theoretical models covered, and target learner outcomes..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
            />
          </div>

          {/* Module Syllabus Editor */}
          <div className="pt-2">
            <label className="text-xs font-bold text-[#082e52] block mb-2">
              Curriculum Syllabus Modules ({modules.length})
            </label>

            <div className="space-y-2 mb-3">
              {modules.map((mod, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-3 rounded-xl bg-[#f8fbfe] border border-[#e2edf6] text-xs"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-md bg-[#e8f5ff] text-[#0b63b6] font-bold flex items-center justify-center text-[10px]">
                      {index + 1}
                    </span>
                    <span className="font-semibold text-[#082e52]">{mod}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleRemoveModule(index)}
                    className="text-rose-500 hover:text-rose-700 p-1 cursor-pointer"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Enter new syllabus module title..."
                value={newModuleTitle}
                onChange={(e) => setNewModuleTitle(e.target.value)}
                className="flex-1 p-2.5 rounded-xl border border-[#d4e1eb] bg-white text-xs text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
              />
              <button
                type="button"
                onClick={handleAddModule}
                className="secondary !text-xs !py-2 !px-4 font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <PlusCircle size={14} /> Add Module
              </button>
            </div>
          </div>

          <div className="pt-4 border-t border-[#edf2f6] flex justify-end gap-3">
            <button
              type="button"
              onClick={() => onNavigate('trainer-my-courses')}
              className="secondary !text-xs !py-2.5 !px-4 font-bold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="primary !text-xs !py-2.5 !px-6 font-bold cursor-pointer flex items-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <Loader2 size={14} className="animate-spin" />
                  <span>Authoring in Cloud SQL...</span>
                </>
              ) : (
                <span>Publish Course to Database</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
