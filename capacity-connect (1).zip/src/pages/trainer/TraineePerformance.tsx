import React from 'react';
import { BarChart3, TrendingUp, Users, Award, CheckCircle2 } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, TraineeUser } from '../../types';

interface TraineePerformanceProps {
  trainees: TraineeUser[];
  onNavigate: (page: AppPage) => void;
}

export const TraineePerformance: React.FC<TraineePerformanceProps> = ({
  trainees,
  onNavigate,
}) => {
  return (
    <div>
      <PageHeader
        badge="EVALUATION METRICS"
        title="Trainee Performance"
        subtitle="Benchmark cohort proficiency distributions, module completion velocities, and competency gaps."
        backPage="trainer-dashboard"
        onBack={onNavigate}
      />

      {/* Cohort KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-5 shadow-xs">
          <span className="text-[11px] font-bold text-[#8295a7] uppercase tracking-wider block mb-1">
            Cohort Average Score
          </span>
          <strong className="text-3xl font-extrabold text-[#082e52]">86.2%</strong>
          <span className="text-xs text-emerald-600 block mt-2 font-medium">
            +4.1% compared to Q2 batch
          </span>
        </div>

        <div className="bg-white border border-[#dce8f3] rounded-2xl p-5 shadow-xs">
          <span className="text-[11px] font-bold text-[#8295a7] uppercase tracking-wider block mb-1">
            Passing Rate
          </span>
          <strong className="text-3xl font-extrabold text-[#0b63b6]">92.8%</strong>
          <span className="text-xs text-[#66798c] block mt-2 font-medium">
            Threshold: 70% passing mark
          </span>
        </div>

        <div className="bg-white border border-[#dce8f3] rounded-2xl p-5 shadow-xs">
          <span className="text-[11px] font-bold text-[#8295a7] uppercase tracking-wider block mb-1">
            Certified Personnel
          </span>
          <strong className="text-3xl font-extrabold text-emerald-600">312</strong>
          <span className="text-xs text-[#66798c] block mt-2 font-medium">
            Out of 428 active trainees
          </span>
        </div>

        <div className="bg-white border border-[#dce8f3] rounded-2xl p-5 shadow-xs">
          <span className="text-[11px] font-bold text-[#8295a7] uppercase tracking-wider block mb-1">
            Attention Needed
          </span>
          <strong className="text-3xl font-extrabold text-amber-600">14</strong>
          <span className="text-xs text-amber-700 block mt-2 font-medium">
            Scores below 65% threshold
          </span>
        </div>
      </div>

      {/* Distribution visual breakdown */}
      <div className="bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs mb-8">
        <h3 className="text-base font-bold text-[#082e52] mb-4">
          Score Grade Distribution Across Supervised Batches
        </h3>

        <div className="space-y-4">
          {[
            { grade: 'Distinction (90% - 100%)', count: 184, percent: 43, color: 'bg-emerald-500' },
            { grade: 'First Division (75% - 89%)', count: 162, percent: 38, color: 'bg-[#0b63b6]' },
            { grade: 'Passing Range (60% - 74%)', count: 68, percent: 16, color: 'bg-amber-500' },
            { grade: 'Needs Remedial (< 60%)', count: 14, percent: 3, color: 'bg-rose-500' },
          ].map((row, idx) => (
            <div key={idx}>
              <div className="flex justify-between text-xs font-semibold mb-1">
                <span className="text-[#082e52]">{row.grade}</span>
                <span className="text-[#66798c]">{row.count} Trainees ({row.percent}%)</span>
              </div>
              <div className="w-full bg-[#e8f1f8] h-2.5 rounded-full overflow-hidden">
                <div
                  className={`h-full ${row.color} rounded-full`}
                  style={{ width: `${row.percent}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Individual Trainees Leaderboard */}
      <div className="bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs">
        <h3 className="text-base font-bold text-[#082e52] mb-4">
          Trainee Standing & Progress Roster
        </h3>
        <div className="data-table-container shadow-xs">
          <table className="data-table">
            <thead>
              <tr>
                <th>Rank & Name</th>
                <th>Station</th>
                <th>Courses Completed</th>
                <th>Mean Assessment Score</th>
                <th>Proficiency Status</th>
              </tr>
            </thead>
            <tbody>
              {trainees.map((t, idx) => (
                <tr key={t.id}>
                  <td>
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-[#f0f7ff] text-[#0b63b6] text-[10px] font-bold flex items-center justify-center">
                        {idx + 1}
                      </span>
                      <b className="text-xs text-[#082e52]">{t.name}</b>
                    </div>
                  </td>
                  <td className="text-xs text-[#506579]">{t.department}</td>
                  <td className="text-xs text-[#506579]">{t.completedCoursesCount} of {t.enrolledCoursesCount}</td>
                  <td>
                    <b className="text-xs text-[#0b63b6]">{t.avgScore}%</b>
                  </td>
                  <td>
                    <span className={`status-pill ${t.avgScore >= 90 ? 'completed' : 'blue'}`}>
                      {t.avgScore >= 90 ? 'High Distinction' : 'Satisfactory'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
