import React, { useState } from 'react';
import { Settings as SettingsIcon, Bell, Lock, CheckCircle2 } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage } from '../../types';

interface TrainerSettingsProps {
  onNavigate: (page: AppPage) => void;
}

export const TrainerSettings: React.FC<TrainerSettingsProps> = ({ onNavigate }) => {
  const [submissionAlerts, setSubmissionAlerts] = useState(true);
  const [questionBankAlerts, setQuestionBankAlerts] = useState(true);
  const [saved, setSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div>
      <PageHeader
        badge="FACULTY PREFERENCES"
        title="Trainer Settings"
        subtitle="Configure grading notifications, submission alerts, and security settings."
        backPage="trainer-dashboard"
        onBack={onNavigate}
      />

      {saved && (
        <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-semibold flex items-center gap-2">
          <CheckCircle2 size={18} className="text-emerald-600" />
          <span>Trainer preferences updated successfully.</span>
        </div>
      )}

      <div className="max-w-3xl space-y-6">
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs">
          <h3 className="text-base font-bold text-[#082e52] mb-4 flex items-center gap-2">
            <Bell size={18} className="text-[#0b63b6]" /> Assessment & Batch Alerts
          </h3>

          <div className="space-y-4">
            <label className="flex items-center justify-between p-3 rounded-xl border border-[#edf3f8] hover:bg-[#fafcff] cursor-pointer">
              <div>
                <b className="text-sm text-[#082e52] block">Trainee Exam Submission Alerts</b>
                <span className="text-xs text-[#66798c]">
                  Get instant notification when a trainee completes an assessment module.
                </span>
              </div>
              <input
                type="checkbox"
                checked={submissionAlerts}
                onChange={(e) => setSubmissionAlerts(e.target.checked)}
                className="w-4 h-4 accent-[#0b63b6] cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-xl border border-[#edf3f8] hover:bg-[#fafcff] cursor-pointer">
              <div>
                <b className="text-sm text-[#082e52] block">Question Bank Sync & Feedback</b>
                <span className="text-xs text-[#66798c]">
                  Receive alerts on statistical item discrimination and trainee review comments.
                </span>
              </div>
              <input
                type="checkbox"
                checked={questionBankAlerts}
                onChange={(e) => setQuestionBankAlerts(e.target.checked)}
                className="w-4 h-4 accent-[#0b63b6] cursor-pointer"
              />
            </label>
          </div>
        </div>

        <div className="bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs">
          <h3 className="text-base font-bold text-[#082e52] mb-4 flex items-center gap-2">
            <Lock size={18} className="text-[#0b63b6]" /> Update Access Credentials
          </h3>

          <form onSubmit={handleSave} className="space-y-4">
            <div>
              <label className="text-xs font-bold text-[#3d546a] block mb-1">Current Password</label>
              <input
                type="password"
                placeholder="Enter current password"
                className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-[#3d546a] block mb-1">New Password</label>
                <input
                  type="password"
                  placeholder="Min. 8 characters"
                  className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-[#3d546a] block mb-1">Confirm New Password</label>
                <input
                  type="password"
                  placeholder="Confirm password"
                  className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
                />
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                className="primary text-xs font-bold py-2.5 px-5 cursor-pointer"
              >
                Save Security Settings
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
