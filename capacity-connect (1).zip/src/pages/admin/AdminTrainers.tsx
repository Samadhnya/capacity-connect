import React, { useState } from 'react';
import { GraduationCap, Search, Star, BookOpen, Users, Award } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, TrainerUser } from '../../types';

interface AdminTrainersProps {
  trainers: TrainerUser[];
  onNavigate: (page: AppPage) => void;
}

export const AdminTrainers: React.FC<AdminTrainersProps> = ({
  trainers,
  onNavigate,
}) => {
  const [search, setSearch] = useState('');

  const filtered = trainers.filter((t) =>
    t.name.toLowerCase().includes(search.toLowerCase()) ||
    t.specialization.toLowerCase().includes(search.toLowerCase()) ||
    t.designation.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <PageHeader
        badge="FACULTY DIRECTORY"
        title="Trainer Registry"
        subtitle="Roster of authorized senior scientists and domain mentors across Ministry of Earth Sciences."
        backPage="admin-dashboard"
        onBack={onNavigate}
      />

      <div className="mb-6 relative max-w-md">
        <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#889eb5]" />
        <input
          type="text"
          placeholder="Filter faculty by name or domain specialization..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-[#d4e1eb] bg-white text-sm focus:outline-none focus:border-[#0b63b6]"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((t) => (
          <div
            key={t.id}
            className="bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="w-12 h-12 rounded-xl bg-[#e8f5ff] text-[#0b63b6] flex items-center justify-center font-bold text-base">
                  {t.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                </div>
                <span className="text-xs font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                  ★ {t.rating}
                </span>
              </div>

              <h3 className="text-base font-bold text-[#082e52] mb-0.5">{t.name}</h3>
              <p className="text-xs font-semibold text-[#0b63b6] mb-2">{t.designation}</p>
              <p className="text-xs text-[#66798c] mb-4 leading-relaxed">{t.specialization}</p>

              <div className="grid grid-cols-2 gap-2 p-3 bg-[#f8fbfe] rounded-xl border border-[#e2edf6] text-center text-xs mb-2">
                <div>
                  <span className="text-[10px] text-[#8295a7] uppercase font-bold block">Courses</span>
                  <b className="text-[#082e52]">{t.coursesCount} Programs</b>
                </div>
                <div>
                  <span className="text-[10px] text-[#8295a7] uppercase font-bold block">Trainees</span>
                  <b className="text-[#082e52]">{t.traineesCount} Cadres</b>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-[#edf2f6]">
              <button
                onClick={() => alert(`Reviewing course offerings for ${t.name}...`)}
                className="secondary w-full !text-xs !py-2 font-bold cursor-pointer"
              >
                Inspect Faculty Dossier
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
