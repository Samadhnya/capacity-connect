import React, { useState } from 'react';
import { Megaphone, PlusCircle, CheckCircle2, Clock, Trash2, ShieldAlert } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { Modal } from '../../components/common/Modal';
import { AppPage, AnnouncementItem } from '../../types';

interface AdminAnnouncementsProps {
  announcements: AnnouncementItem[];
  onNavigate: (page: AppPage) => void;
  onAddAnnouncement: (item: AnnouncementItem) => void;
}

export const AdminAnnouncements: React.FC<AdminAnnouncementsProps> = ({
  announcements,
  onNavigate,
  onAddAnnouncement,
}) => {
  const [modalOpen, setModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [targetRole, setTargetRole] = useState<'All' | 'Trainee' | 'Trainer'>('All');
  const [priority, setPriority] = useState<'High' | 'Normal'>('Normal');
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newNotice: AnnouncementItem = {
      id: `an-${Date.now()}`,
      title,
      body,
      date: '2026-09-28',
      author: 'Training Board Directorate, MoES',
      targetRole,
      priority,
    };
    onAddAnnouncement(newNotice);
    setSuccess(true);
    setTimeout(() => {
      setSuccess(false);
      setModalOpen(false);
      setTitle('');
      setBody('');
    }, 1000);
  };

  return (
    <div>
      <PageHeader
        badge="INSTITUTIONAL BROADCAST"
        title="Announcements & Circulars"
        subtitle="Publish nationwide training circulars, batch timetables, and mandatory directives."
        backPage="admin-dashboard"
        onBack={onNavigate}
        actionText="Post New Announcement"
        actionIcon={<PlusCircle size={16} />}
        onAction={() => setModalOpen(true)}
      />

      <div className="space-y-4 max-w-4xl">
        {announcements.map((a) => (
          <div
            key={a.id}
            className={`bg-white border rounded-2xl p-6 shadow-xs ${
              a.priority === 'High' ? 'border-amber-300' : 'border-[#dce8f3]'
            }`}
          >
            <div className="flex items-start justify-between gap-3 mb-2">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase text-[#0b63b6] bg-[#e7f5ff] px-2.5 py-0.5 rounded">
                  Target: {a.targetRole}
                </span>
                {a.priority === 'High' && (
                  <span className="text-[10px] font-bold uppercase text-amber-700 bg-amber-100 px-2 py-0.5 rounded">
                    High Priority
                  </span>
                )}
              </div>
              <span className="text-xs text-[#8498ac] flex items-center gap-1">
                <Clock size={12} /> {a.date}
              </span>
            </div>

            <h3 className="text-base font-bold text-[#082e52] mb-1.5">{a.title}</h3>
            <p className="text-xs text-[#506579] leading-relaxed mb-4">{a.body}</p>

            <div className="pt-3 border-t border-[#edf2f6] flex items-center justify-between text-xs text-[#8295a7]">
              <span>Issued by: <b>{a.author}</b></span>
              <span className="text-emerald-700 font-semibold">Active Broadcast</span>
            </div>
          </div>
        ))}
      </div>

      {/* Post Modal */}
      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Post New Circular / Notice"
        subtitle="Broadcast to all trainees and trainers on the portal."
      >
        {success ? (
          <div className="text-center py-6">
            <CheckCircle2 size={40} className="text-emerald-600 mx-auto mb-2" />
            <h4 className="text-lg font-bold text-[#082e52]">Notice Broadcasted</h4>
            <p className="text-xs text-[#66798c]">Dispatched to target personnel dashboards.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 pt-2">
            <div>
              <label className="text-xs font-bold text-[#3d546a] block mb-1">Notice Heading</label>
              <input
                type="text"
                required
                placeholder="e.g. Schedule for Monsoon Season Pre-Deployment Workshops"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-[#3d546a] block mb-1">Target Audience</label>
                <select
                  value={targetRole}
                  onChange={(e) => setTargetRole(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none"
                >
                  <option value="All">All Users (Trainees + Trainers)</option>
                  <option value="Trainee">Trainees Only</option>
                  <option value="Trainer">Trainers Only</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-[#3d546a] block mb-1">Urgency Priority</label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none"
                >
                  <option value="Normal">Normal Notification</option>
                  <option value="High">High Priority Directive</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-[#3d546a] block mb-1">Circular Text Content</label>
              <textarea
                required
                rows={4}
                placeholder="Enter official circular text..."
                value={body}
                onChange={(e) => setBody(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
              />
            </div>

            <div className="pt-3 flex justify-end gap-2 border-t border-[#edf2f6]">
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="secondary text-xs font-semibold py-2 px-4 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="primary text-xs font-bold py-2 px-5 cursor-pointer"
              >
                Publish Broadcast
              </button>
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
};
