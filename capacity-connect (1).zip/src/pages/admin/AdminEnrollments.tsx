import React, { useState } from 'react';
import { CheckCircle2, Search, Filter, Calendar, Award } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, Course, TraineeUser } from '../../types';

interface AdminEnrollmentsProps {
  courses: Course[];
  trainees: TraineeUser[];
  onNavigate: (page: AppPage) => void;
}

export const AdminEnrollments: React.FC<AdminEnrollmentsProps> = ({
  courses,
  trainees,
  onNavigate,
}) => {
  const [search, setSearch] = useState('');

  // Generate realistic enrollment records
  const enrollments = [
    { id: 'en-01', trainee: 'Arjun Singhania', course: 'Numerical Weather Prediction (NWP) Modeling', date: '2026-08-01', progress: 72, status: 'Active' },
    { id: 'en-02', trainee: 'Meera Nambiar', course: 'Ocean-Atmosphere Interaction & Climate Change', date: '2026-08-10', progress: 45, status: 'Active' },
    { id: 'en-03', trainee: 'Rohan Deshmukh', course: 'Monsoon Dynamics & Agrometeorological Forecasting', date: '2026-07-15', progress: 28, status: 'Active' },
    { id: 'en-04', trainee: 'Arjun Singhania', course: 'Disaster Early Warning & Cyclone Tracking', date: '2026-07-01', progress: 100, status: 'Completed' },
    { id: 'en-05', trainee: 'Shreya Chatterjee', course: 'Atmospheric Chemistry & Air Quality Modeling', date: '2026-08-20', progress: 60, status: 'Active' },
    { id: 'en-06', trainee: 'Karthik Ramanathan', course: 'Satellite Meteorology & Radar Data Interpretation', date: '2026-06-12', progress: 100, status: 'Completed' },
    { id: 'en-07', trainee: 'Tanya Sengupta', course: 'Numerical Weather Prediction (NWP) Modeling', date: '2026-08-05', progress: 85, status: 'Active' },
  ];

  const filtered = enrollments.filter((e) =>
    e.trainee.toLowerCase().includes(search.toLowerCase()) ||
    e.course.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <PageHeader
        badge="REGISTRATION DIRECTORY"
        title="Batch Enrollments"
        subtitle="Track active participant registrations, progress statuses, and completion rates."
        backPage="admin-dashboard"
        onBack={onNavigate}
      />

      <div className="mb-6 relative max-w-md">
        <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#889eb5]" />
        <input
          type="text"
          placeholder="Filter enrollments by trainee or course..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-[#d4e1eb] bg-white text-sm focus:outline-none focus:border-[#0b63b6]"
        />
      </div>

      <div className="data-table-container shadow-xs">
        <table className="data-table">
          <thead>
            <tr>
              <th>Enrollment ID</th>
              <th>Trainee Name</th>
              <th>Enrolled Course Program</th>
              <th>Registration Date</th>
              <th>Progress</th>
              <th>Status</th>
              <th className="text-right">Action</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((en) => (
              <tr key={en.id}>
                <td className="font-mono text-xs text-[#0b63b6] font-bold">{en.id}</td>
                <td>
                  <b className="text-xs text-[#082e52]">{en.trainee}</b>
                </td>
                <td className="text-xs text-[#506579] font-medium">{en.course}</td>
                <td className="text-xs text-[#506579]">{en.date}</td>
                <td>
                  <div className="flex items-center gap-2">
                    <div className="w-16 bg-[#e6eff6] h-2 rounded-full overflow-hidden">
                      <div className="bg-[#0b63b6] h-full" style={{ width: `${en.progress}%` }} />
                    </div>
                    <span className="text-xs font-bold text-[#082e52]">{en.progress}%</span>
                  </div>
                </td>
                <td>
                  <span className={`status-pill ${en.status === 'Completed' ? 'completed' : 'progress'}`}>
                    {en.status}
                  </span>
                </td>
                <td className="text-right">
                  <button
                    onClick={() => alert(`Inspecting enrollment ${en.id}...`)}
                    className="secondary !py-1 !px-2.5 !text-xs font-semibold cursor-pointer"
                  >
                    Details
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
