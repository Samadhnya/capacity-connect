import React, { useState } from 'react';
import { BookOpen, Search, PlusCircle, Users, Clock3, Star, CheckCircle2 } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, Course } from '../../types';

interface AdminCoursesProps {
  courses: Course[];
  onNavigate: (page: AppPage) => void;
  onSelectCourse: (course: Course) => void;
}

export const AdminCourses: React.FC<AdminCoursesProps> = ({
  courses,
  onNavigate,
  onSelectCourse,
}) => {
  const [search, setSearch] = useState('');

  const filtered = courses.filter((c) =>
    c.title.toLowerCase().includes(search.toLowerCase()) ||
    c.trainer.toLowerCase().includes(search.toLowerCase()) ||
    c.category.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <PageHeader
        badge="ACADEMIC GOVERNANCE"
        title="Courses Management"
        subtitle="Review, approve, and audit courses offered across Ministry of Earth Sciences institutions."
        backPage="admin-dashboard"
        onBack={onNavigate}
        actionText="Create Course"
        actionIcon={<PlusCircle size={16} />}
        onAction={() => onNavigate('trainer-create-course')}
      />

      <div className="mb-6 relative max-w-md">
        <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#889eb5]" />
        <input
          type="text"
          placeholder="Search by title, instructor, category..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-[#d4e1eb] bg-white text-sm focus:outline-none focus:border-[#0b63b6]"
        />
      </div>

      <div className="data-table-container shadow-xs">
        <table className="data-table">
          <thead>
            <tr>
              <th>Course Program</th>
              <th>Category</th>
              <th>Lead Instructor</th>
              <th>Level</th>
              <th>Duration</th>
              <th>Enrolled Cadre</th>
              <th>Rating</th>
              <th className="text-right">Action</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((c) => (
              <tr key={c.id}>
                <td>
                  <b className="text-xs text-[#082e52] block">{c.title}</b>
                  <small className="text-[#899db0] text-[11px]">{c.modulesCount} Modules in Curriculum</small>
                </td>
                <td className="text-xs text-[#0b63b6] font-semibold">{c.category}</td>
                <td className="text-xs text-[#506579] font-medium">{c.trainer}</td>
                <td>
                  <span className="text-xs font-semibold px-2 py-0.5 rounded bg-[#f0f4f8] text-[#506579]">
                    {c.level}
                  </span>
                </td>
                <td className="text-xs text-[#506579]">{c.duration}</td>
                <td>
                  <b className="text-xs text-[#082e52]">{c.enrolledCount} Trainees</b>
                </td>
                <td>
                  <span className="text-xs font-bold text-amber-600">★ {c.rating}</span>
                </td>
                <td className="text-right">
                  <button
                    onClick={() => {
                      onSelectCourse(c);
                      onNavigate('trainee-course-details');
                    }}
                    className="secondary !py-1 !px-2.5 !text-xs font-semibold cursor-pointer"
                  >
                    View Syllabus
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
