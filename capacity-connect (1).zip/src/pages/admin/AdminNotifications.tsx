import React from 'react';
import { Bell, CheckCheck, Info, CheckCircle2, Clock } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, NotificationItem } from '../../types';

interface AdminNotificationsProps {
  notifications: NotificationItem[];
  onNavigate: (page: AppPage) => void;
  onMarkAllRead: () => void;
  onToggleRead: (id: string) => void;
}

export const AdminNotifications: React.FC<AdminNotificationsProps> = ({
  notifications,
  onNavigate,
  onMarkAllRead,
  onToggleRead,
}) => {
  return (
    <div>
      <PageHeader
        badge="SYSTEM SIGNALS"
        title="Admin Notifications"
        subtitle="System alerts, security audit triggers, and batch completion logs."
        backPage="admin-dashboard"
        onBack={onNavigate}
        actionText="Mark All Read"
        actionIcon={<CheckCheck size={16} />}
        onAction={onMarkAllRead}
      />

      <div className="space-y-3 max-w-3xl">
        {notifications.map((n) => (
          <div
            key={n.id}
            onClick={() => onToggleRead(n.id)}
            className={`p-4 rounded-xl border transition-all flex items-start gap-3.5 cursor-pointer ${
              !n.read
                ? 'bg-white border-[#0b63b6]/40 shadow-xs'
                : 'bg-[#fafcff] border-[#e2edf6] opacity-80'
            }`}
          >
            <div className="mt-0.5 shrink-0 text-[#0b63b6]">
              <Info size={18} />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between gap-2 mb-1">
                <h4
                  className={`text-sm m-0 ${
                    !n.read ? 'font-bold text-[#082e52]' : 'font-medium text-[#486075]'
                  }`}
                >
                  {n.title}
                </h4>
                <span className="text-[11px] text-[#8295a7] flex items-center gap-1 shrink-0">
                  <Clock size={11} /> {n.time}
                </span>
              </div>
              <p className="text-xs text-[#506579] m-0 leading-relaxed">{n.message}</p>
            </div>
            {!n.read && (
              <span className="w-2.5 h-2.5 rounded-full bg-[#0b63b6] shrink-0 mt-1.5" />
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
