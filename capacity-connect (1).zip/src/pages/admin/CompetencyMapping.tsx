import React, { useState } from 'react';
import { Briefcase, Users, Target, ArrowRight, ShieldCheck, TrendingUp, CheckCircle2 } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, CompetencySkill } from '../../types';

interface CompetencyMappingProps {
  competencies: CompetencySkill[];
  onNavigate: (page: AppPage) => void;
}

export const CompetencyMapping: React.FC<CompetencyMappingProps> = ({
  competencies,
  onNavigate,
}) => {
  return (
    <div>
      <PageHeader
        badge="STRATEGIC SKILLS MATRIX"
        title="Competency Mapping"
        subtitle="Benchmark departmental workforce capabilities against target operational standards and pair stations with certified trainers."
        backPage="admin-dashboard"
        onBack={onNavigate}
        actionText="View Trainers"
        actionIcon={<Users size={16} />}
        onAction={() => onNavigate('admin-trainers')}
      />

      {/* Strategic Highlights */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 mb-8">
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-5 shadow-xs">
          <span className="text-[11px] font-bold text-[#8295a7] uppercase tracking-wider block mb-1">
            Core Technical Domains
          </span>
          <strong className="text-3xl font-extrabold text-[#082e52]">6 Competencies</strong>
          <span className="text-xs text-[#66798c] block mt-2 font-medium">
            Operational across 36 regional radar & NWP stations
          </span>
        </div>

        <div className="bg-white border border-[#dce8f3] rounded-2xl p-5 shadow-xs">
          <span className="text-[11px] font-bold text-[#8295a7] uppercase tracking-wider block mb-1">
            Workforce Certified
          </span>
          <strong className="text-3xl font-extrabold text-emerald-600">2,572 Personnel</strong>
          <span className="text-xs text-emerald-700 block mt-2 font-medium">
            Satisfying minimum benchmark proficiency
          </span>
        </div>

        <div className="bg-white border border-[#dce8f3] rounded-2xl p-5 shadow-xs">
          <span className="text-[11px] font-bold text-[#8295a7] uppercase tracking-wider block mb-1">
            Certified Faculty Pool
          </span>
          <strong className="text-3xl font-extrabold text-[#0b63b6]">91 Trainers</strong>
          <span className="text-xs text-[#66798c] block mt-2 font-medium">
            Available for specialized batch rotations
          </span>
        </div>
      </div>

      {/* Competency Gap Analysis Grid */}
      <div className="bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs mb-8">
        <h3 className="text-base font-bold text-[#082e52] mb-1">
          Ministry Skills Gap & Benchmark Analysis
        </h3>
        <p className="text-xs text-[#66798c] mb-6">
          Compare current workforce averages with target proficiency benchmarks set by the MoES Board.
        </p>

        <div className="space-y-6">
          {competencies.map((comp) => {
            const gap = comp.targetProficiency - comp.currentWorkforceAverage;
            return (
              <div key={comp.id} className="border-b border-[#edf4f8] pb-5 last:border-b-0 last:pb-0">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-[#082e52] m-0">{comp.skillName}</h4>
                      <span className="text-[10px] font-bold text-[#0b63b6] bg-[#e7f5ff] px-2 py-0.5 rounded">
                        {comp.category}
                      </span>
                    </div>
                    <span className="text-xs text-[#66798c]">
                      {comp.certifiedPersonnel} certified officers • {comp.trainersAvailable} faculty mentors active
                    </span>
                  </div>

                  <div className="flex items-center gap-4 text-xs font-bold">
                    <span>
                      Current: <b className="text-[#082e52]">{comp.currentWorkforceAverage}%</b>
                    </span>
                    <span>
                      Target: <b className="text-[#0b63b6]">{comp.targetProficiency}%</b>
                    </span>
                    <span className="text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                      Gap: {gap > 0 ? `-${gap}%` : 'Met'}
                    </span>
                  </div>
                </div>

                <div className="w-full bg-[#e6eff6] h-3 rounded-full overflow-hidden relative">
                  {/* Current progress */}
                  <div
                    className="bg-[#0b63b6] h-full rounded-full"
                    style={{ width: `${comp.currentWorkforceAverage}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
