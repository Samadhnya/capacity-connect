import React from 'react';
import { BarChart3, TrendingUp, Users, Award, BookOpen, Globe, CheckCircle2 } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage } from '../../types';

interface AdminAnalyticsProps {
  onNavigate: (page: AppPage) => void;
}

export const AdminAnalytics: React.FC<AdminAnalyticsProps> = ({ onNavigate }) => {
  return (
    <div>
      <PageHeader
        badge="NATIONWIDE METRICS"
        title="Institutional Analytics"
        subtitle="Workforce learning telemetry, regional IMD station participation, and assessment compliance."
        backPage="admin-dashboard"
        onBack={onNavigate}
      />

      {/* Top 4 KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-5 shadow-xs">
          <span className="text-[11px] font-bold text-[#8295a7] uppercase tracking-wider block mb-1">
            Total Portal Registrations
          </span>
          <strong className="text-3xl font-extrabold text-[#082e52]">1,334</strong>
          <span className="text-xs text-emerald-600 block mt-2 font-medium">
            +18% year-over-year
          </span>
        </div>

        <div className="bg-white border border-[#dce8f3] rounded-2xl p-5 shadow-xs">
          <span className="text-[11px] font-bold text-[#8295a7] uppercase tracking-wider block mb-1">
            Course Completion Rate
          </span>
          <strong className="text-3xl font-extrabold text-[#0b63b6]">82.4%</strong>
          <span className="text-xs text-[#66798c] block mt-2 font-medium">
            Benchmark: 75% target
          </span>
        </div>

        <div className="bg-white border border-[#dce8f3] rounded-2xl p-5 shadow-xs">
          <span className="text-[11px] font-bold text-[#8295a7] uppercase tracking-wider block mb-1">
            Certificates Dispatched
          </span>
          <strong className="text-3xl font-extrabold text-emerald-600">3,684</strong>
          <span className="text-xs text-emerald-700 block mt-2 font-medium">
            All cryptographically verified
          </span>
        </div>

        <div className="bg-white border border-[#dce8f3] rounded-2xl p-5 shadow-xs">
          <span className="text-[11px] font-bold text-[#8295a7] uppercase tracking-wider block mb-1">
            Average Exam Score
          </span>
          <strong className="text-3xl font-extrabold text-[#082e52]">87.1%</strong>
          <span className="text-xs text-[#66798c] block mt-2 font-medium">
            Across 24 active evaluations
          </span>
        </div>
      </div>

      {/* Regional Participation Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs">
          <h3 className="text-base font-bold text-[#082e52] mb-1 flex items-center gap-2">
            <Globe size={18} className="text-[#0b63b6]" /> Participation by Institution / Circle
          </h3>
          <p className="text-xs text-[#66798c] mb-5">
            Active personnel distribution across MoES sister departments.
          </p>

          <div className="space-y-4">
            {[
              { label: 'IMD New Delhi (HQ & NWFC)', count: 480, percent: 36, color: 'bg-[#0b63b6]' },
              { label: 'IMD Regional Centres (Pune, Chennai, Kolkata)', count: 350, percent: 26, color: 'bg-sky-500' },
              { label: 'INCOIS Hyderabad (Ocean Forecasts)', count: 210, percent: 16, color: 'bg-indigo-500' },
              { label: 'IITM Pune (Climate Dynamics)', count: 180, percent: 14, color: 'bg-emerald-500' },
              { label: 'NCMRWF Noida (Data Assimilation)', count: 114, percent: 8, color: 'bg-amber-500' },
            ].map((item, idx) => (
              <div key={idx}>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-[#082e52]">{item.label}</span>
                  <span className="text-[#66798c]">{item.count} Personnel ({item.percent}%)</span>
                </div>
                <div className="w-full bg-[#e8f1f8] h-2.5 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${item.color} rounded-full`}
                    style={{ width: `${item.percent}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Course Category Popularity */}
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs">
          <h3 className="text-base font-bold text-[#082e52] mb-1 flex items-center gap-2">
            <BookOpen size={18} className="text-[#0b63b6]" /> Top Course Disciplines by Enrollment
          </h3>
          <p className="text-xs text-[#66798c] mb-5">
            Subject-wise enrollment volumes for academic session 2026.
          </p>

          <div className="space-y-4">
            {[
              { name: 'Disaster Early Warning & Cyclones', trainees: 310, percent: 88 },
              { name: 'Data & Digital Skills (AWS/Python)', trainees: 290, percent: 82 },
              { name: 'Satellite Meteorology & DWR', trainees: 210, percent: 65 },
              { name: 'Monsoon Dynamics & Agromet', trainees: 185, percent: 55 },
              { name: 'Atmospheric Chemistry & Air Quality', trainees: 175, percent: 52 },
              { name: 'Ocean-Atmosphere Coupling (Argo)', trainees: 160, percent: 48 },
            ].map((course, idx) => (
              <div key={idx}>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-[#082e52]">{course.name}</span>
                  <span className="text-[#0b63b6] font-bold">{course.trainees} Trainees</span>
                </div>
                <div className="w-full bg-[#e8f1f8] h-2.5 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-[#0b63b6] to-[#29a9e8] rounded-full"
                    style={{ width: `${course.percent}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
