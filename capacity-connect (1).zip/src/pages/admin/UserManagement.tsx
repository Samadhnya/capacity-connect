import React, { useState } from 'react';
import { Users, Search, UserPlus, Shield, CheckCircle2, Lock } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { Modal } from '../../components/common/Modal';
import { AppPage, TraineeUser, TrainerUser } from '../../types';

interface UserManagementProps {
  trainees: TraineeUser[];
  trainers: TrainerUser[];
  onNavigate: (page: AppPage) => void;
}

export const UserManagement: React.FC<UserManagementProps> = ({
  trainees,
  trainers,
  onNavigate,
}) => {
  const [roleFilter, setRoleFilter] = useState<'All' | 'Trainee' | 'Trainer'>('All');
  const [search, setSearch] = useState('');
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newRole, setNewRole] = useState<'Trainee' | 'Trainer'>('Trainee');
  const [newDept, setNewDept] = useState('IMD New Delhi');
  const [addedSuccess, setAddedSuccess] = useState(false);

  const allUsers = [
    ...trainees.map((t) => ({ ...t, role: 'Trainee' as const })),
    ...trainers.map((t) => ({
      id: t.id,
      name: t.name,
      email: t.email,
      department: t.specialization,
      division: t.designation,
      status: 'Active' as const,
      role: 'Trainer' as const,
    })),
  ];

  const filtered = allUsers.filter((u) => {
    const matchesSearch =
      u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.email.toLowerCase().includes(search.toLowerCase());
    const matchesRole = roleFilter === 'All' || u.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    setAddedSuccess(true);
    setTimeout(() => {
      setAddedSuccess(false);
      setAddModalOpen(false);
      setNewName('');
      setNewEmail('');
    }, 1200);
  };

  return (
    <div>
      <PageHeader
        badge="SECURITY & ACCESS CONTROL"
        title="User Management"
        subtitle="Provision, audit, and manage role-based credentials for trainees, mentors, and system administrators."
        backPage="admin-dashboard"
        onBack={onNavigate}
        actionText="Provision Personnel"
        actionIcon={<UserPlus size={16} />}
        onAction={() => setAddModalOpen(true)}
      />

      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#889eb5]" />
          <input
            type="text"
            placeholder="Search personnel by name or official email..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-[#d4e1eb] bg-white text-sm focus:outline-none focus:border-[#0b63b6]"
          />
        </div>
        <select
          value={roleFilter}
          onChange={(e) => setRoleFilter(e.target.value as any)}
          className="py-2.5 px-3 rounded-xl border border-[#d4e1eb] bg-white text-sm font-semibold text-[#082e52] focus:outline-none cursor-pointer"
        >
          <option value="All">All User Roles</option>
          <option value="Trainee">Trainees Only</option>
          <option value="Trainer">Trainers Only</option>
        </select>
      </div>

      <div className="data-table-container shadow-xs">
        <table className="data-table">
          <thead>
            <tr>
              <th>Personnel Name</th>
              <th>Official Role</th>
              <th>Department / Specialty</th>
              <th>Cadre / Designation</th>
              <th>Status</th>
              <th className="text-right">Action</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((u) => (
              <tr key={u.id}>
                <td>
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-[#f0f7ff] text-[#0b63b6] font-bold text-xs flex items-center justify-center shrink-0">
                      {u.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                    </div>
                    <div>
                      <b className="text-xs text-[#082e52] block">{u.name}</b>
                      <small className="text-[#889eb2] text-[11px] font-mono">{u.email}</small>
                    </div>
                  </div>
                </td>
                <td>
                  <span
                    className={`text-[11px] font-bold px-2 py-0.5 rounded-md uppercase ${
                      u.role === 'Trainer'
                        ? 'bg-purple-100 text-purple-800'
                        : 'bg-sky-100 text-sky-800'
                    }`}
                  >
                    {u.role}
                  </span>
                </td>
                <td className="text-xs text-[#506579]">{u.department}</td>
                <td className="text-xs text-[#506579] font-medium">{u.division}</td>
                <td>
                  <span className="status-pill active">
                    <CheckCircle2 size={12} /> {u.status}
                  </span>
                </td>
                <td className="text-right">
                  <button
                    onClick={() => alert(`Managing permissions for ${u.name}...`)}
                    className="secondary !py-1 !px-2.5 !text-xs font-semibold cursor-pointer"
                  >
                    Edit Access
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add User Modal */}
      <Modal
        isOpen={addModalOpen}
        onClose={() => setAddModalOpen(false)}
        title="Provision New Official Personnel"
        subtitle="Establish verified credentials on the MoES CAPACITY CONNECT network."
      >
        {addedSuccess ? (
          <div className="text-center py-6">
            <CheckCircle2 size={40} className="text-emerald-600 mx-auto mb-2" />
            <h4 className="text-lg font-bold text-[#082e52]">User Provisioned</h4>
            <p className="text-xs text-[#66798c]">Invitation token dispatched to official email.</p>
          </div>
        ) : (
          <form onSubmit={handleAddUser} className="space-y-4 pt-2">
            <div>
              <label className="text-xs font-bold text-[#3d546a] block mb-1">Full Legal Name</label>
              <input
                type="text"
                required
                placeholder="e.g. Dr. Ramesh Chander"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-[#3d546a] block mb-1">Official Email Address</label>
              <input
                type="email"
                required
                placeholder="name@imd.gov.in"
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-[#3d546a] block mb-1">System Role</label>
                <select
                  value={newRole}
                  onChange={(e) => setNewRole(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none"
                >
                  <option value="Trainee">Trainee</option>
                  <option value="Trainer">Trainer</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-[#3d546a] block mb-1">Station / Institute</label>
                <select
                  value={newDept}
                  onChange={(e) => setNewDept(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none"
                >
                  <option>IMD New Delhi</option>
                  <option>IMD Pune</option>
                  <option>INCOIS Hyderabad</option>
                  <option>IITM Pune</option>
                  <option>NCMRWF Noida</option>
                </select>
              </div>
            </div>

            <div className="pt-4 flex justify-end gap-2 border-t border-[#edf2f6]">
              <button
                type="button"
                onClick={() => setAddModalOpen(false)}
                className="secondary text-xs font-semibold py-2 px-4 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="primary text-xs font-bold py-2 px-5 cursor-pointer"
              >
                Confirm Provisioning
              </button>
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
};
