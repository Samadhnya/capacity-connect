import React, { useState } from 'react';
import { FileQuestion, Search, PlusCircle, CheckCircle2, Clock, Award } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, Assessment } from '../../types';

interface AdminAssessmentsProps {
  assessments: Assessment[];
  onNavigate: (page: AppPage) => void;
}

export const AdminAssessments: React.FC<AdminAssessmentsProps> = ({
  assessments,
  onNavigate,
}) => {
  const [search, setSearch] = useState('');

  const filtered = assessments.filter((a) =>
    a.title.toLowerCase().includes(search.toLowerCase()) ||
    a.courseTitle.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <PageHeader
        badge="EXAMINATION BOARD"
        title="Assessments Governance"
        subtitle="Oversight of MCQ assessment banks, duration guidelines, and minimum certification thresholds."
        backPage="admin-dashboard"
        onBack={onNavigate}
        actionText="Create Assessment"
        actionIcon={<PlusCircle size={16} />}
        onAction={() => onNavigate('trainer-create-assessment')}
      />

      <div className="mb-6 relative max-w-md">
        <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#889eb5]" />
        <input
          type="text"
          placeholder="Search assessments..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-[#d4e1eb] bg-white text-sm focus:outline-none focus:border-[#0b63b6]"
        />
      </div>

      <div className="data-table-container shadow-xs">
        <table className="data-table">
          <thead>
            <tr>
              <th>Assessment Name</th>
              <th>Program Course</th>
              <th>Duration</th>
              <th>MCQs Bank</th>
              <th>Total Marks</th>
              <th>Passing Mark</th>
              <th>Grading Mode</th>
              <th className="text-right">Action</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((a) => (
              <tr key={a.id}>
                <td>
                  <b className="text-xs text-[#082e52] block">{a.title}</b>
                  <small className="text-[#889cb2] text-[11px] font-mono">ID: {a.id}</small>
                </td>
                <td className="text-xs text-[#506579] font-medium">{a.courseTitle}</td>
                <td className="text-xs text-[#506579]">{a.durationMinutes} Mins</td>
                <td className="text-xs text-[#082e52] font-bold">{a.questionCount} Questions</td>
                <td className="text-xs text-[#506579]">{a.totalMarks}</td>
                <td className="text-xs text-emerald-700 font-bold">{a.passingMarks}</td>
                <td>
                  <span className="status-pill completed">Automated</span>
                </td>
                <td className="text-right">
                  <button
                    onClick={() => alert(`Reviewing question bank for ${a.title}...`)}
                    className="secondary !py-1 !px-2.5 !text-xs font-semibold cursor-pointer"
                  >
                    Inspect Bank
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
