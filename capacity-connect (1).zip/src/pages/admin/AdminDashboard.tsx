import React from 'react';
import {
  Users,
  GraduationCap,
  BookOpen,
  Award,
  BarChart3,
  Megaphone,
  Briefcase,
  ShieldCheck,
  CheckCircle2,
  TrendingUp,
} from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, Course, TraineeUser, TrainerUser } from '../../types';

interface AdminDashboardProps {
  courses: Course[];
  trainees: TraineeUser[];
  trainers: TrainerUser[];
  onNavigate: (page: AppPage) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  courses,
  trainees,
  trainers,
  onNavigate,
}) => {
  return (
    <div>
      <p className="text-xs font-bold text-[#8295a7] uppercase tracking-wider mb-1">
        CAPACITY CONNECT / ADMIN GOVERNANCE HUB
      </p>
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-extrabold text-[#082e52] tracking-tight m-0">
            Administrative Governance Console
          </h1>
          <p className="text-sm text-[#66798c] mt-1 mb-0">
            Ministry of Earth Sciences (MoES) & India Meteorological Department • Smart Education Oversight
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('admin-announcements')}
            className="secondary text-xs font-bold py-2.5 px-3.5 inline-flex items-center gap-1.5 cursor-pointer"
          >
            <Megaphone size={14} /> New Notice
          </button>
          <button
            onClick={() => onNavigate('admin-users')}
            className="primary text-xs font-bold py-2.5 px-4 inline-flex items-center gap-1.5 cursor-pointer"
          >
            <Users size={14} /> Manage Users
          </button>
        </div>
      </div>

      {/* Admin stats matching prototype numbers */}
      <div className="dashstats">
        <div>
          <Users />
          <small>Registered Trainees</small>
          <strong>1,248</strong>
        </div>
        <div>
          <GraduationCap />
          <small>Certified Trainers</small>
          <strong>86</strong>
        </div>
        <div>
          <BookOpen />
          <small>Active LMS Courses</small>
          <strong>142</strong>
        </div>
        <div>
          <Award />
          <small>Certificates Issued</small>
          <strong>3,684</strong>
        </div>
      </div>

      {/* Panels Grid */}
      <div className="panels">
        {/* Left: System Governance & Enrollments */}
        <div className="panel">
          <h2>
            <span>Institutional Operations & Course Batches</span>
            <button
              onClick={() => onNavigate('admin-courses')}
              className="text-xs text-[#0b63b6] hover:underline font-bold"
            >
              All Courses →
            </button>
          </h2>

          <div className="space-y-1">
            {courses.slice(0, 4).map((c) => (
              <div
                key={c.id}
                onClick={() => onNavigate('admin-courses')}
                className="row hover:bg-[#f8fbfe] rounded-xl px-2 cursor-pointer transition-colors"
              >
                <div className="w-10 h-10 rounded-xl bg-[#e8f5ff] text-[#0b63b6] flex items-center justify-center shrink-0">
                  <BookOpen size={18} />
                </div>
                <span>
                  <b>{c.title}</b>
                  <small>
                    Category: {c.category} • Lead: {c.trainer} • {c.enrolledCount} Active Registrations
                  </small>
                </span>
                <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-1 rounded-md shrink-0 border border-emerald-200">
                  Active
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Quick shortcuts & Audit Trail */}
        <div className="space-y-6">
          <div className="panel">
            <h2>Governance Quick Links</h2>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={() => onNavigate('admin-competency-mapping')}
                className="secondary !py-2.5 !text-xs font-bold flex flex-col items-center gap-1.5 cursor-pointer text-center"
              >
                <Briefcase size={18} className="text-[#0b63b6]" />
                <span>Competency Mapping</span>
              </button>
              <button
                onClick={() => onNavigate('admin-analytics')}
                className="secondary !py-2.5 !text-xs font-bold flex flex-col items-center gap-1.5 cursor-pointer text-center"
              >
                <BarChart3 size={18} className="text-[#0b63b6]" />
                <span>Workforce Analytics</span>
              </button>
            </div>
          </div>

          <div className="panel">
            <h2>System Audit Trail</h2>
            <div className="space-y-0.5">
              {[
                'New course published: Numerical Weather Modeling',
                'Assessment completed: Doppler Radar Storm Quiz',
                'New user registered: Dr. Sunita Rao (SAFAR)',
                'Cryptographic Certificate issued: MoES-IMD-8841',
              ].map((act, i) => (
                <div key={i} className="activity">
                  <CheckCircle2 size={16} className="text-[#0b63b6] shrink-0" />
                  <span className="text-xs font-medium text-[#2d465c]">{act}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
