import React, { useState } from 'react';
import { Settings as SettingsIcon, ShieldCheck, Database, Server, CheckCircle2, Lock } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage } from '../../types';

interface AdminSettingsProps {
  onNavigate: (page: AppPage) => void;
}

export const AdminSettings: React.FC<AdminSettingsProps> = ({ onNavigate }) => {
  const [allowPublicRegistration, setAllowPublicRegistration] = useState(true);
  const [requireGovEmail, setRequireGovEmail] = useState(true);
  const [autoIssueCertificates, setAutoIssueCertificates] = useState(true);
  const [saved, setSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div>
      <PageHeader
        badge="GOVERNANCE CONFIGURATION"
        title="Admin Settings"
        subtitle="Platform-wide governance policies, access enforcement rules, and audit logging parameters."
        backPage="admin-dashboard"
        onBack={onNavigate}
      />

      {saved && (
        <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-semibold flex items-center gap-2">
          <CheckCircle2 size={18} className="text-emerald-600" />
          <span>Governance parameters saved and committed to system configuration.</span>
        </div>
      )}

      <div className="max-w-3xl space-y-6">
        {/* Registration policy */}
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs">
          <h3 className="text-base font-bold text-[#082e52] mb-4 flex items-center gap-2">
            <ShieldCheck size={18} className="text-[#0b63b6]" /> Access & Registration Policies
          </h3>

          <div className="space-y-4">
            <label className="flex items-center justify-between p-3 rounded-xl border border-[#edf3f8] hover:bg-[#fafcff] cursor-pointer">
              <div>
                <b className="text-sm text-[#082e52] block">Enable Open Institutional Registration</b>
                <span className="text-xs text-[#66798c]">
                  Allow staff from IMD, INCOIS, IITM and NCMRWF to sign up autonomously.
                </span>
              </div>
              <input
                type="checkbox"
                checked={allowPublicRegistration}
                onChange={(e) => setAllowPublicRegistration(e.target.checked)}
                className="w-4 h-4 accent-[#0b63b6] cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-xl border border-[#edf3f8] hover:bg-[#fafcff] cursor-pointer">
              <div>
                <b className="text-sm text-[#082e52] block">Require Official NIC / Government Email Domain</b>
                <span className="text-xs text-[#66798c]">
                  Restrict registrations exclusively to @imd.gov.in, @moes.gov.in, @incois.gov.in, @iitm.res.in.
                </span>
              </div>
              <input
                type="checkbox"
                checked={requireGovEmail}
                onChange={(e) => setRequireGovEmail(e.target.checked)}
                className="w-4 h-4 accent-[#0b63b6] cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-xl border border-[#edf3f8] hover:bg-[#fafcff] cursor-pointer">
              <div>
                <b className="text-sm text-[#082e52] block">Automated Certificate Minting</b>
                <span className="text-xs text-[#66798c]">
                  Automatically generate verifiable digital certificates upon achieving ≥ 70% in assessments.
                </span>
              </div>
              <input
                type="checkbox"
                checked={autoIssueCertificates}
                onChange={(e) => setAutoIssueCertificates(e.target.checked)}
                className="w-4 h-4 accent-[#0b63b6] cursor-pointer"
              />
            </label>
          </div>
        </div>

        {/* Server & Node information */}
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs">
          <h3 className="text-base font-bold text-[#082e52] mb-3 flex items-center gap-2">
            <Server size={18} className="text-[#0b63b6]" /> Server Infrastructure Status
          </h3>
          <div className="space-y-2 text-xs text-[#506579]">
            <div className="flex justify-between p-2 rounded-lg bg-[#f8fbfe]">
              <span>System Host Node:</span>
              <span className="font-mono font-bold text-[#082e52]">MoES-DELHI-HPC-CLUSTER-01</span>
            </div>
            <div className="flex justify-between p-2 rounded-lg bg-[#f8fbfe]">
              <span>Database Sync State:</span>
              <span className="font-bold text-emerald-600">Local State (Database Phase Ready)</span>
            </div>
            <div className="flex justify-between p-2 rounded-lg bg-[#f8fbfe]">
              <span>Problem Statement:</span>
              <span className="font-bold text-[#0b63b6]">Smart India Hackathon ID 26075</span>
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <button
            onClick={handleSave}
            className="primary text-xs font-bold py-2.5 px-6 cursor-pointer"
          >
            Apply Governance Policy
          </button>
        </div>
      </div>
    </div>
  );
};
