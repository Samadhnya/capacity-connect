import React, { useState } from 'react';
import { Award, Search, Download, Eye, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { CertificateModal } from '../../components/common/CertificateModal';
import { AppPage, Certificate } from '../../types';

interface AdminCertificationsProps {
  certificates: Certificate[];
  onNavigate: (page: AppPage) => void;
}

export const AdminCertifications: React.FC<AdminCertificationsProps> = ({
  certificates,
  onNavigate,
}) => {
  const [search, setSearch] = useState('');
  const [selectedCert, setSelectedCert] = useState<Certificate | null>(null);

  const filtered = certificates.filter((c) =>
    c.certificateNumber.toLowerCase().includes(search.toLowerCase()) ||
    c.recipientName.toLowerCase().includes(search.toLowerCase()) ||
    c.courseTitle.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <PageHeader
        badge="CERTIFICATION REGISTRY"
        title="Accredited Certifications"
        subtitle="Audit digitally signed certificates and verify authenticity against the central MoES ledger."
        backPage="admin-dashboard"
        onBack={onNavigate}
      />

      <div className="mb-6 relative max-w-md">
        <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#889eb5]" />
        <input
          type="text"
          placeholder="Search by certificate ID, recipient, course..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-[#d4e1eb] bg-white text-sm focus:outline-none focus:border-[#0b63b6]"
        />
      </div>

      <div className="data-table-container shadow-xs">
        <table className="data-table">
          <thead>
            <tr>
              <th>Certificate Serial</th>
              <th>Recipient Name</th>
              <th>Designation</th>
              <th>Certified Program</th>
              <th>Score</th>
              <th>Issue Date</th>
              <th>Verification</th>
              <th className="text-right">Action</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((cert) => (
              <tr key={cert.id}>
                <td className="font-mono text-xs font-bold text-[#0b63b6]">{cert.certificateNumber}</td>
                <td>
                  <b className="text-xs text-[#082e52]">{cert.recipientName}</b>
                </td>
                <td className="text-xs text-[#506579]">{cert.recipientRole}</td>
                <td className="text-xs text-[#506579] font-medium">{cert.courseTitle}</td>
                <td>
                  <span className="text-xs font-bold text-emerald-700">{cert.score} ({cert.grade})</span>
                </td>
                <td className="text-xs text-[#506579]">{cert.issueDate}</td>
                <td>
                  <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    <ShieldCheck size={12} /> Verified
                  </span>
                </td>
                <td className="text-right">
                  <div className="flex justify-end gap-1.5">
                    <button
                      onClick={() => setSelectedCert(cert)}
                      className="secondary !py-1 !px-2.5 !text-xs font-semibold cursor-pointer"
                    >
                      Inspect
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <CertificateModal
        certificate={selectedCert}
        isOpen={!!selectedCert}
        onClose={() => setSelectedCert(null)}
      />
    </div>
  );
};
