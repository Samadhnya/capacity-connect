import React, { useState } from 'react';
import { Users, Search, Building, Award, CheckCircle2, ShieldAlert } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, TraineeUser } from '../../types';

interface AdminTraineesProps {
  trainees: TraineeUser[];
  onNavigate: (page: AppPage) => void;
}

export const AdminTrainees: React.FC<AdminTraineesProps> = ({
  trainees,
  onNavigate,
}) => {
  const [search, setSearch] = useState('');

  const filtered = trainees.filter((t) =>
    t.name.toLowerCase().includes(search.toLowerCase()) ||
    t.department.toLowerCase().includes(search.toLowerCase()) ||
    t.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <PageHeader
        badge="CADRE ADMINISTRATION"
        title="Trainee Registry"
        subtitle="Review nationwide scientific trainee participation, pass percentages, and active enrollments."
        backPage="admin-dashboard"
        onBack={onNavigate}
        actionText="Manage Users"
        onAction={() => onNavigate('admin-users')}
      />

      <div className="mb-6 relative max-w-md">
        <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#889eb5]" />
        <input
          type="text"
          placeholder="Filter trainees by name, email, station..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-[#d4e1eb] bg-white text-sm focus:outline-none focus:border-[#0b63b6]"
        />
      </div>

      <div className="data-table-container shadow-xs">
        <table className="data-table">
          <thead>
            <tr>
              <th>Trainee</th>
              <th>Station / Institute</th>
              <th>Operational Division</th>
              <th>Courses</th>
              <th>Completed</th>
              <th>Mean Score</th>
              <th>Status</th>
              <th className="text-right">Action</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((t) => (
              <tr key={t.id}>
                <td>
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-[#f0f7ff] text-[#0b63b6] font-bold text-xs flex items-center justify-center shrink-0">
                      {t.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                    </div>
                    <div>
                      <b className="text-xs text-[#082e52] block">{t.name}</b>
                      <small className="text-[#889eb2] text-[11px] font-mono">{t.email}</small>
                    </div>
                  </div>
                </td>
                <td className="text-xs text-[#506579] font-medium">{t.department}</td>
                <td className="text-xs text-[#506579]">{t.division}</td>
                <td className="text-xs text-[#082e52] font-bold">{t.enrolledCoursesCount}</td>
                <td className="text-xs text-emerald-700 font-bold">{t.completedCoursesCount}</td>
                <td>
                  <b className="text-xs text-[#0b63b6]">{t.avgScore}%</b>
                </td>
                <td>
                  <span className={`status-pill ${t.status === 'Active' ? 'active' : 'pending'}`}>
                    {t.status}
                  </span>
                </td>
                <td className="text-right">
                  <button
                    onClick={() => alert(`Reviewing record for ${t.name}...`)}
                    className="secondary !py-1 !px-2.5 !text-xs font-semibold cursor-pointer"
                  >
                    View Record
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
