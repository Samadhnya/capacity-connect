import React from 'react';
import { BarChart3, TrendingUp, Clock, CheckCircle2, Award, BookOpen } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, Course } from '../../types';

interface ProgressTrackingProps {
  courses: Course[];
  onNavigate: (page: AppPage) => void;
}

export const ProgressTracking: React.FC<ProgressTrackingProps> = ({
  courses,
  onNavigate,
}) => {
  const enrolled = courses.filter((c) => c.isEnrolled);

  return (
    <div>
      <PageHeader
        badge="LEARNING ANALYTICS"
        title="Progress Tracking"
        subtitle="Detailed breakdown of syllabus completion rates, time invested in lecture modules, and competency milestones."
        backPage="trainee-dashboard"
        onBack={onNavigate}
      />

      {/* High-level KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs text-[#8295a7] font-bold uppercase mb-2">
            <span>Overall Progress</span>
            <TrendingUp size={16} className="text-[#0b63b6]" />
          </div>
          <strong className="text-3xl font-extrabold text-[#082e52]">74%</strong>
          <div className="w-full bg-[#e6eff6] h-1.5 rounded-full overflow-hidden mt-3">
            <div className="bg-[#0b63b6] h-full" style={{ width: '74%' }} />
          </div>
        </div>

        <div className="bg-white border border-[#dce8f3] rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs text-[#8295a7] font-bold uppercase mb-2">
            <span>Study Hours Logged</span>
            <Clock size={16} className="text-[#0b63b6]" />
          </div>
          <strong className="text-3xl font-extrabold text-[#082e52]">64.5 Hrs</strong>
          <span className="text-xs text-emerald-600 block mt-2 font-medium">
            +8.2 hrs this week
          </span>
        </div>

        <div className="bg-white border border-[#dce8f3] rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs text-[#8295a7] font-bold uppercase mb-2">
            <span>Modules Cleared</span>
            <CheckCircle2 size={16} className="text-emerald-600" />
          </div>
          <strong className="text-3xl font-extrabold text-[#082e52]">18 / 24</strong>
          <span className="text-xs text-[#66798c] block mt-2 font-medium">
            6 modules remaining
          </span>
        </div>

        <div className="bg-white border border-[#dce8f3] rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs text-[#8295a7] font-bold uppercase mb-2">
            <span>Certifications</span>
            <Award size={16} className="text-amber-500" />
          </div>
          <strong className="text-3xl font-extrabold text-[#082e52]">2 Earned</strong>
          <span className="text-xs text-[#0b63b6] block mt-2 font-medium">
            1 pending final exam
          </span>
        </div>
      </div>

      {/* Course-by-course Progress Breakdown */}
      <div className="bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs mb-8">
        <h3 className="text-base font-bold text-[#082e52] mb-4">
          Course Completion Trajectory
        </h3>

        <div className="space-y-6">
          {enrolled.map((c) => (
            <div key={c.id} className="border-b border-[#edf4f8] pb-5 last:border-b-0 last:pb-0">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                <div>
                  <h4 className="text-sm font-bold text-[#082e52] m-0">{c.title}</h4>
                  <span className="text-xs text-[#66798c]">
                    Instructor: {c.trainer} • {c.duration}
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-extrabold text-[#0b63b6]">{c.progress ?? 0}%</span>
                  <button
                    onClick={() => onNavigate('trainee-course-details')}
                    className="secondary !py-1 !px-2.5 !text-xs font-bold"
                  >
                    View Modules
                  </button>
                </div>
              </div>

              <div className="w-full bg-[#e6eff6] h-2.5 rounded-full overflow-hidden mb-2">
                <div
                  className="bg-[#0b63b6] h-full rounded-full transition-all"
                  style={{ width: `${c.progress ?? 0}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-[11px] text-[#8295a7]">
                <span>
                  {c.syllabus.filter((s) => s.completed).length} of {c.syllabus.length} Modules Finished
                </span>
                <span>
                  {(c.progress ?? 0) >= 100 ? 'Completed' : 'Estimated completion in 2 weeks'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Weekly Activity Heatmap/Bars simulation */}
      <div className="bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs">
        <h3 className="text-base font-bold text-[#082e52] mb-4">
          Weekly Study Intensity (Past 6 Weeks)
        </h3>

        <div className="grid grid-cols-6 gap-3 items-end h-40 pt-4 px-4 bg-[#f8fbfe] rounded-xl border border-[#e2edf6]">
          {[
            { week: 'W1', hrs: 8.5, height: '55%' },
            { week: 'W2', hrs: 12.0, height: '80%' },
            { week: 'W3', hrs: 9.2, height: '62%' },
            { week: 'W4', hrs: 15.4, height: '100%' },
            { week: 'W5', hrs: 11.2, height: '75%' },
            { week: 'W6 (Current)', hrs: 8.2, height: '58%' },
          ].map((bar, idx) => (
            <div key={idx} className="flex flex-col items-center h-full justify-end">
              <span className="text-[10px] font-bold text-[#0b63b6] mb-1">{bar.hrs}h</span>
              <div
                className="w-full max-w-[40px] bg-gradient-to-t from-[#0b63b6] to-[#42b2f2] rounded-t-md"
                style={{ height: bar.height }}
              />
              <span className="text-[10px] text-[#66798c] font-semibold mt-2 truncate max-w-full">
                {bar.week}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
