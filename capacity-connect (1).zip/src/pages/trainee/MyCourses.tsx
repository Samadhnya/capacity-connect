import React, { useState, useEffect } from 'react';
import { BookOpen, Users, Clock3, CheckCircle2, PlayCircle, ArrowRight, RefreshCw, Loader2, Calendar } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { EmptyState } from '../../components/common/EmptyState';
import { AppPage, Course } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { courseApiService } from '../../services/courseApiService';

interface MyCoursesProps {
  courses: Course[];
  onNavigate: (page: AppPage) => void;
  onSelectCourse: (course: Course) => void;
}

export const MyCourses: React.FC<MyCoursesProps> = ({
  courses: fallbackCourses,
  onNavigate,
  onSelectCourse,
}) => {
  const { user } = useAuth();
  const [tab, setTab] = useState<'All' | 'InProgress' | 'Completed'>('All');
  const [dbCourses, setDbCourses] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const fetchEnrolledCourses = async () => {
    setIsLoading(true);
    try {
      const email = user?.email || 'arjun.singhania@imd.gov.in';
      const result = await courseApiService.getMyEnrolledCourses(email);
      if (result.courses && result.courses.length > 0) {
        setDbCourses(result.courses);
      }
    } catch (err) {
      console.warn('Error fetching enrolled courses:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchEnrolledCourses();
  }, [user?.email]);

  // Combine DB courses or fallback
  const enrolledCourses: Course[] =
    dbCourses.length > 0
      ? dbCourses.map((dc) => {
          const match = fallbackCourses.find((fc) => fc.id === dc.courseId);
          if (match) {
            return {
              ...match,
              progress: dc.progress,
              isEnrolled: true,
            };
          }
          return {
            id: dc.courseId,
            title: dc.title,
            description: dc.description || '',
            trainer: dc.trainerName,
            trainerRole: 'Senior Scientist & Course Director',
            category: dc.category,
            duration: dc.duration,
            level: (dc.level as any) || 'Intermediate',
            rating: 4.9,
            enrolledCount: 160,
            modulesCount: 4,
            progress: dc.progress,
            isEnrolled: true,
            syllabus: [],
          };
        })
      : fallbackCourses.filter((c) => c.isEnrolled);

  const displayed = enrolledCourses.filter((c) => {
    if (tab === 'InProgress') return (c.progress ?? 0) < 100;
    if (tab === 'Completed') return (c.progress ?? 0) >= 100;
    return true;
  });

  return (
    <div>
      <div className="flex items-center justify-between gap-3 mb-2">
        <PageHeader
          badge="TRAINEE PORTAL"
          title="My Courses"
          subtitle="Manage and resume your enrolled meteorological training programs stored in Cloud SQL."
          backPage="trainee-dashboard"
          onBack={onNavigate}
          actionText="Explore More Courses"
          onAction={() => onNavigate('trainee-explore-courses')}
        />
        <button
          onClick={fetchEnrolledCourses}
          disabled={isLoading}
          className="secondary !py-2 !px-3 !text-xs cursor-pointer flex items-center gap-1.5 shrink-0"
          title="Refresh courses from database"
        >
          <RefreshCw size={13} className={isLoading ? 'animate-spin' : ''} />
          <span>Sync from Database</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-[#dce8f3] mb-6 pb-2">
        <button
          onClick={() => setTab('All')}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
            tab === 'All' ? 'bg-[#0b63b6] text-white shadow-xs' : 'text-[#506579] hover:bg-[#f0f7ff]'
          }`}
        >
          All Enrolled ({enrolledCourses.length})
        </button>
        <button
          onClick={() => setTab('InProgress')}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
            tab === 'InProgress' ? 'bg-[#0b63b6] text-white shadow-xs' : 'text-[#506579] hover:bg-[#f0f7ff]'
          }`}
        >
          Active Courses ({enrolledCourses.filter((c) => (c.progress ?? 0) < 100).length})
        </button>
        <button
          onClick={() => setTab('Completed')}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
            tab === 'Completed' ? 'bg-[#0b63b6] text-white shadow-xs' : 'text-[#506579] hover:bg-[#f0f7ff]'
          }`}
        >
          Completed Courses ({enrolledCourses.filter((c) => (c.progress ?? 0) >= 100).length})
        </button>
      </div>

      {isLoading ? (
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-12 text-center text-[#647b92]">
          <Loader2 size={32} className="animate-spin text-[#0b63b6] mx-auto mb-3" />
          <p className="text-sm font-semibold">Loading enrolled courses from Cloud SQL...</p>
        </div>
      ) : displayed.length === 0 ? (
        <EmptyState
          title="No courses found in this category"
          description="Browse the training catalogue to discover courses in Numerical Weather Prediction, Satellite Meteorology, and Oceanography."
          actionText="Explore All Courses"
          onAction={() => onNavigate('trainee-explore-courses')}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayed.map((course) => {
            const isFinished = (course.progress ?? 0) >= 100;
            const dbMatch = dbCourses.find((d) => d.courseId === course.id);
            const statusLabel = isFinished ? 'COMPLETED' : (course.progress ?? 0) > 0 ? 'IN_PROGRESS' : 'NOT_STARTED';
            const lastActivity = dbMatch?.lastActivity || 'Studied curriculum module';
            const enrolledDate = dbMatch?.enrolledAt
              ? new Date(dbMatch.enrolledAt).toLocaleDateString()
              : 'Jan 2026';

            return (
              <div
                key={course.id}
                className="bg-white border border-[#dce8f3] hover:border-[#0b63b6] rounded-2xl p-5 flex flex-col justify-between shadow-xs transition-all hover:shadow-md"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-[#f0f7ff] text-[#0b63b6] border border-[#cde2f5]">
                      {course.category}
                    </span>
                    <span
                      className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                        statusLabel === 'COMPLETED'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-blue-100 text-[#0b63b6]'
                      }`}
                    >
                      {statusLabel}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-[#082e52] mb-1.5 line-clamp-2 leading-snug">
                    {course.title}
                  </h3>
                  <p className="text-xs text-[#506579] mb-3 line-clamp-2 leading-relaxed">
                    {course.description}
                  </p>

                  <div className="flex items-center gap-3 text-xs text-[#71879c] mb-3">
                    <span className="flex items-center gap-1">
                      <Users size={14} /> {course.trainer}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock3 size={14} /> {course.duration}
                    </span>
                  </div>

                  <div className="text-[11px] text-[#6b8296] mb-3 flex items-center gap-1.5">
                    <Calendar size={13} className="text-[#889cb0]" />
                    <span>Enrolled: <b>{enrolledDate}</b></span>
                  </div>

                  {/* Progress Bar */}
                  <div className="mb-4 bg-[#f4f8fb] p-3 rounded-xl border border-[#e2effa]">
                    <div className="flex items-center justify-between text-xs font-bold mb-1.5">
                      <span className="text-[#082e52]">Curriculum Progress</span>
                      <span className={isFinished ? 'text-emerald-700' : 'text-[#0b63b6]'}>
                        {course.progress ?? 0}%
                      </span>
                    </div>
                    <div className="w-full bg-[#d8e6f3] h-2 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          isFinished ? 'bg-emerald-500' : 'bg-[#0b63b6]'
                        }`}
                        style={{ width: `${course.progress ?? 0}%` }}
                      />
                    </div>
                    <div className="text-[10px] text-[#71879c] mt-1.5 truncate">
                      Last Activity: {lastActivity}
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-[#edf2f6] flex items-center justify-between gap-2">
                  <button
                    onClick={() => {
                      onSelectCourse(course);
                      onNavigate('trainee-course-details');
                    }}
                    className="primary w-full !text-xs !py-2.5 font-bold cursor-pointer flex items-center justify-center gap-2"
                  >
                    {isFinished ? (
                      <>
                        <CheckCircle2 size={15} />
                        <span>Review Completed Material</span>
                      </>
                    ) : (
                      <>
                        <PlayCircle size={15} />
                        <span>Continue Learning</span>
                        <ArrowRight size={14} />
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
