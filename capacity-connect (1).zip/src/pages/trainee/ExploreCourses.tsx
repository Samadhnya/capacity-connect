import React, { useState, useEffect } from 'react';
import {
  BookOpen,
  Users,
  Clock3,
  Search,
  Sparkles,
  ArrowRight,
  CheckCircle,
  RefreshCw,
  Loader2,
  AlertCircle,
  Check,
} from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, Course } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { courseApiService, DbCourse } from '../../services/courseApiService';

interface ExploreCoursesProps {
  courses: Course[];
  onNavigate: (page: AppPage) => void;
  onSelectCourse: (course: Course) => void;
  onEnroll: (courseId: string) => void;
}

export const ExploreCourses: React.FC<ExploreCoursesProps> = ({
  courses: fallbackCourses,
  onNavigate,
  onSelectCourse,
  onEnroll,
}) => {
  const { user } = useAuth();
  const [dbCourses, setDbCourses] = useState<DbCourse[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [enrollingId, setEnrollingId] = useState<string | null>(null);
  const [enrollSuccessMessage, setEnrollSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const [search, setSearch] = useState('');
  const [levelFilter, setLevelFilter] = useState('All');
  const [categoryFilter, setCategoryFilter] = useState('All');

  const categories = [
    'All',
    'Meteorology',
    'Remote Sensing',
    'Climate & Forecasting',
    'Disaster Management',
    'Oceanography',
    'Instrumentation',
  ];

  const fetchCourses = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const email = user?.email || 'arjun.singhania@imd.gov.in';
      const result = await courseApiService.getCourses(email);
      if (result.courses && result.courses.length > 0) {
        setDbCourses(result.courses);
      }
    } catch (err: any) {
      console.warn('Error fetching courses:', err);
      setErrorMessage('Could not load courses from PostgreSQL database.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchCourses();
  }, [user?.email]);

  const combinedCourses: Course[] =
    dbCourses.length > 0
      ? dbCourses.map((dc) => {
          const match = fallbackCourses.find((fc) => fc.id === dc.id);
          return {
            id: dc.id,
            title: dc.title,
            description: dc.description || (match?.description ?? ''),
            trainer: dc.trainerName,
            trainerRole: match?.trainerRole || 'Scientist / Course Director',
            category: dc.category,
            duration: dc.duration,
            level: (dc.level as any) || 'Intermediate',
            rating: parseFloat(dc.rating) || 4.9,
            enrolledCount: dc.enrolledCount,
            modulesCount: dc.totalModules || 4,
            progress: dc.progress,
            isEnrolled: dc.isEnrolled,
            syllabus: match?.syllabus || [],
          };
        })
      : fallbackCourses;

  const filtered = combinedCourses.filter((c) => {
    const matchesSearch =
      c.title.toLowerCase().includes(search.toLowerCase()) ||
      c.description.toLowerCase().includes(search.toLowerCase()) ||
      c.trainer.toLowerCase().includes(search.toLowerCase());
    const matchesLevel = levelFilter === 'All' || c.level === levelFilter;
    const matchesCategory = categoryFilter === 'All' || c.category === categoryFilter;
    return matchesSearch && matchesLevel && matchesCategory;
  });

  const handleEnroll = async (course: Course) => {
    setEnrollingId(course.id);
    setErrorMessage(null);
    try {
      const email = user?.email || 'arjun.singhania@imd.gov.in';
      const res = await courseApiService.enrollCourse(course.id, email);
      if (res.success) {
        setEnrollSuccessMessage(res.message || `Successfully enrolled in ${course.title}!`);
        setDbCourses((prev) =>
          prev.map((c) =>
            c.id === course.id
              ? { ...c, isEnrolled: true, enrolledCount: c.enrolledCount + 1, progress: 10, enrollmentStatus: 'IN_PROGRESS' }
              : c
          )
        );
        onEnroll(course.id);
        setTimeout(() => setEnrollSuccessMessage(null), 4000);
      } else {
        setErrorMessage(res.error || 'Failed to complete enrollment.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Error communicating with database.');
    } finally {
      setEnrollingId(null);
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between gap-3 mb-2">
        <PageHeader
          badge="TRAINEE PORTAL"
          title="Explore Courses"
          subtitle="Discover specialized meteorological, computational, and geophysical courses authorized by MoES and stored in PostgreSQL."
          backPage="trainee-dashboard"
          onBack={onNavigate}
        />
        <button
          onClick={fetchCourses}
          disabled={isLoading}
          className="secondary !py-2 !px-3 !text-xs cursor-pointer flex items-center gap-1.5 shrink-0"
          title="Sync courses from database"
        >
          <RefreshCw size={13} className={isLoading ? 'animate-spin' : ''} />
          <span>Sync from Database</span>
        </button>
      </div>

      {enrollSuccessMessage && (
        <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-semibold flex items-center gap-2 animate-fade-in">
          <CheckCircle size={18} className="text-emerald-600 shrink-0" />
          <span>{enrollSuccessMessage}</span>
          <button
            onClick={() => onNavigate('trainee-my-courses')}
            className="ml-auto underline font-bold cursor-pointer text-xs"
          >
            Go to My Courses →
          </button>
        </div>
      )}

      {errorMessage && (
        <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm font-semibold flex items-center gap-2 animate-fade-in">
          <AlertCircle size={18} className="text-rose-600 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#889eb5]" />
          <input
            type="text"
            placeholder="Search topics, models, instruments..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-[#d4e1eb] bg-white text-sm focus:outline-none focus:border-[#0b63b6]"
          />
        </div>
        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          aria-label="Filter by Category"
          className="py-2.5 px-3 rounded-xl border border-[#d4e1eb] bg-white text-xs font-semibold text-[#082e52] focus:outline-none"
        >
          {categories.map((c) => (
            <option key={c} value={c}>
              Category: {c}
            </option>
          ))}
        </select>
        <select
          value={levelFilter}
          onChange={(e) => setLevelFilter(e.target.value)}
          aria-label="Filter by Level"
          className="py-2.5 px-3 rounded-xl border border-[#d4e1eb] bg-white text-xs font-semibold text-[#082e52] focus:outline-none"
        >
          <option value="All">All Levels</option>
          <option value="Beginner">Beginner</option>
          <option value="Intermediate">Intermediate</option>
          <option value="Advanced">Advanced</option>
        </select>
      </div>

      {isLoading ? (
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-16 text-center text-[#647b92]">
          <Loader2 size={36} className="animate-spin text-[#0b63b6] mx-auto mb-3" />
          <p className="text-sm font-semibold">Loading courses from PostgreSQL database...</p>
        </div>
      ) : filtered.length === 0 ? (
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-12 text-center text-[#647b92]">
          <BookOpen size={36} className="text-[#889eb5] mx-auto mb-2" />
          <h3 className="text-base font-bold text-[#082e52]">No courses found</h3>
          <p className="text-xs text-[#506579] mt-1">Try refining your search terms or filters.</p>
        </div>
      ) : (
        <div className="coursegrid">
          {filtered.map((course) => (
            <article key={course.id} className="course flex flex-col justify-between">
              <div>
                <div className="cover">
                  <span>{course.level}</span>
                  <BookOpen size={20} />
                </div>
                <div className="meta">
                  <span>{course.category}</span>
                  <span className="font-bold text-amber-600">★ {course.rating}</span>
                </div>
                <h3>{course.title}</h3>
                <p>{course.description}</p>
                <div className="teacher">
                  <div className="w-6 h-6 rounded-full bg-[#0b63b6] text-white flex items-center justify-center text-[10px] font-bold">
                    {course.trainer[0]}
                  </div>
                  <span>{course.trainer}</span>
                </div>
                <div className="flex items-center gap-3 text-xs text-[#71879c] mt-2 mb-4">
                  <span className="flex items-center gap-1">
                    <Clock3 size={13} /> {course.duration}
                  </span>
                  <span className="flex items-center gap-1">
                    <Users size={13} /> {course.enrolledCount} enrolled
                  </span>
                </div>
              </div>

              <div className="border-t border-[#edf2f6] pt-3 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => {
                    onSelectCourse(course);
                    onNavigate('trainee-course-details');
                  }}
                  className="secondary flex-1 !text-xs !py-2.5 font-bold cursor-pointer"
                >
                  View Details
                </button>

                {course.isEnrolled ? (
                  <button
                    type="button"
                    onClick={() => {
                      onSelectCourse(course);
                      onNavigate('trainee-course-details');
                    }}
                    className="secondary !text-xs !py-2.5 !px-3 font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 cursor-pointer flex items-center gap-1"
                  >
                    <Check size={14} /> Enrolled
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled={enrollingId === course.id}
                    onClick={() => handleEnroll(course)}
                    className="primary flex-1 !text-xs !py-2.5 font-bold cursor-pointer flex items-center justify-center gap-1"
                  >
                    {enrollingId === course.id ? (
                      <>
                        <Loader2 size={13} className="animate-spin" />
                        <span>Enrolling...</span>
                      </>
                    ) : (
                      <>
                        <span>Enroll Now</span>
                        <ArrowRight size={13} />
                      </>
                    )}
                  </button>
                )}
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
};
