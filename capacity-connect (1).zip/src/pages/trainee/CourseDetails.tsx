import React, { useState, useEffect } from 'react';
import {
  BookOpen,
  Users,
  Clock3,
  Award,
  CheckCircle2,
  FileQuestion,
  FolderArchive,
  Download,
  Play,
  ArrowRight,
  ShieldCheck,
  Check,
  Loader2,
  AlertCircle,
  Sparkles,
} from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, Course, Assessment } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { courseApiService, DbCourse, DbCourseModule } from '../../services/courseApiService';

interface CourseDetailsProps {
  course: Course | null;
  assessments: Assessment[];
  onNavigate: (page: AppPage) => void;
  onStartAssessment: (assessment: Assessment) => void;
  onToggleModule: (courseId: string, moduleIndex: number) => void;
}

export const CourseDetails: React.FC<CourseDetailsProps> = ({
  course: initialCourse,
  assessments,
  onNavigate,
  onStartAssessment,
  onToggleModule,
}) => {
  const { user, isAuthenticated } = useAuth();
  const [course, setCourse] = useState<Course | null>(initialCourse);
  const [dbModules, setDbModules] = useState<DbCourseModule[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isEnrolling, setIsEnrolling] = useState<boolean>(false);
  const [enrollSuccess, setEnrollSuccess] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'syllabus' | 'resources' | 'assessments'>('syllabus');

  // Load detailed course data & modules from PostgreSQL
  useEffect(() => {
    if (!initialCourse?.id) return;

    let isMounted = true;
    const loadDetails = async () => {
      setIsLoading(true);
      try {
        const email = user?.email || 'arjun.singhania@imd.gov.in';
        const res = await courseApiService.getCourseById(initialCourse.id, email);
        if (res.course && isMounted) {
          const c = res.course;
          setCourse({
            id: c.id,
            title: c.title,
            description: c.description || initialCourse.description,
            trainer: c.trainerName,
            trainerRole: initialCourse.trainerRole || 'Scientist / Course Director',
            category: c.category,
            duration: c.duration,
            level: (c.level as any) || 'Intermediate',
            rating: parseFloat(c.rating) || 4.9,
            enrolledCount: c.enrolledCount,
            modulesCount: c.totalModules || 4,
            progress: c.progress,
            isEnrolled: c.isEnrolled,
            syllabus:
              c.modules && c.modules.length > 0
                ? c.modules.map((m) => ({
                    title: m.title,
                    duration: m.duration || '1 Week',
                    completed: m.completed,
                  }))
                : initialCourse.syllabus,
          });

          if (c.modules) {
            setDbModules(c.modules);
          }
        }
      } catch (err: any) {
        console.warn('Error loading course details from DB:', err);
      } finally {
        if (isMounted) setIsLoading(false);
      }
    };

    loadDetails();
    return () => {
      isMounted = false;
    };
  }, [initialCourse?.id, user?.email]);

  if (!course) {
    return (
      <div>
        <PageHeader
          title="Course Details"
          backPage="trainee-my-courses"
          onBack={onNavigate}
        />
        <div className="bg-white p-8 rounded-2xl border border-[#dce8f3] text-center">
          <p className="text-sm text-[#66798c]">No course selected. Please select a course to view details.</p>
          <button
            onClick={() => onNavigate('trainee-explore-courses')}
            className="primary text-xs font-bold mt-4 cursor-pointer"
          >
            Explore Courses
          </button>
        </div>
      </div>
    );
  }

  // Handle Enrollment
  const handleEnrollNow = async () => {
    if (!isAuthenticated) {
      onNavigate('login');
      return;
    }

    setIsEnrolling(true);
    setErrorMessage(null);
    try {
      const email = user?.email || 'arjun.singhania@imd.gov.in';
      const res = await courseApiService.enrollCourse(course.id, email);
      if (res.success) {
        setEnrollSuccess(res.message || 'You are now officially enrolled in this course.');
        setCourse((prev) =>
          prev
            ? { ...prev, isEnrolled: true, progress: prev.progress || 10, enrolledCount: prev.enrolledCount + 1 }
            : null
        );
        setTimeout(() => setEnrollSuccess(null), 5000);
      } else {
        setErrorMessage(res.error || 'Failed to enroll');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Error connecting to database');
    } finally {
      setIsEnrolling(false);
    }
  };

  const handleModuleClick = async (moduleIdx: number) => {
    onToggleModule(course.id, moduleIdx);

    // Calculate new progress and update database
    if (course.isEnrolled) {
      const updatedSyllabus = course.syllabus.map((m, idx) =>
        idx === moduleIdx ? { ...m, completed: !m.completed } : m
      );
      const completedCount = updatedSyllabus.filter((m) => m.completed).length;
      const newProgress = Math.round((completedCount / updatedSyllabus.length) * 100);

      setCourse((prev) => (prev ? { ...prev, syllabus: updatedSyllabus, progress: newProgress } : null));

      try {
        const email = user?.email || 'arjun.singhania@imd.gov.in';
        await courseApiService.updateProgress(
          course.id,
          newProgress,
          `Completed module: ${course.syllabus[moduleIdx]?.title || 'Module'}`,
          email
        );
      } catch (err) {
        console.warn('Failed to update progress in DB:', err);
      }
    }
  };

  const linkedAssessment = assessments.find((a) => a.courseId === course.id);

  return (
    <div>
      <PageHeader
        badge={course.category}
        title={course.title}
        subtitle={`${course.duration} • Instructed by ${course.trainer} (${course.trainerRole})`}
        backPage="trainee-explore-courses"
        onBack={onNavigate}
        actionText={linkedAssessment && course.isEnrolled ? 'Take Module Assessment' : undefined}
        actionIcon={<FileQuestion size={16} />}
        onAction={linkedAssessment && course.isEnrolled ? () => onStartAssessment(linkedAssessment) : undefined}
      />

      {/* Success Notification */}
      {enrollSuccess && (
        <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-semibold flex items-center justify-between animate-fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 size={18} className="text-emerald-600 shrink-0" />
            <span>{enrollSuccess}</span>
          </div>
          <button
            onClick={() => onNavigate('trainee-my-courses')}
            className="text-xs underline font-bold cursor-pointer"
          >
            View in My Courses →
          </button>
        </div>
      )}

      {/* Error Notification */}
      {errorMessage && (
        <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm font-semibold flex items-center gap-2 animate-fade-in">
          <AlertCircle size={18} className="text-rose-600 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main 2 Columns: Overview, Syllabus, & Resources */}
        <div className="lg:col-span-2 space-y-6">
          {/* Overview */}
          <div className="bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-base font-bold text-[#082e52] m-0">Course Overview</h3>
              <span className="text-[11px] font-mono text-[#748a9f]">CODE: {course.id.toUpperCase()}</span>
            </div>
            <p className="text-sm text-[#506579] leading-relaxed mb-4">
              {course.description}
            </p>
            <div className="grid grid-cols-3 gap-3 p-4 bg-[#f8fbfe] rounded-xl border border-[#e2edf6] text-center">
              <div>
                <span className="text-[10px] text-[#8295a7] uppercase font-bold block">Difficulty Level</span>
                <span className="font-bold text-[#082e52] text-xs">{course.level}</span>
              </div>
              <div className="border-x border-[#e2edf6]">
                <span className="text-[10px] text-[#8295a7] uppercase font-bold block">Instruction Duration</span>
                <span className="font-bold text-[#082e52] text-xs">{course.duration}</span>
              </div>
              <div>
                <span className="text-[10px] text-[#8295a7] uppercase font-bold block">Enrolled Trainees</span>
                <span className="font-bold text-[#0b63b6] text-xs">{course.enrolledCount} Officers</span>
              </div>
            </div>
          </div>

          {/* Syllabus vs Resources vs Assessments Tabs */}
          <div className="bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs">
            <div className="flex items-center justify-between border-b border-[#edf2f6] pb-3 mb-4">
              <div className="flex gap-4 flex-wrap">
                <button
                  onClick={() => setActiveTab('syllabus')}
                  className={`text-xs font-bold pb-1 cursor-pointer transition-colors ${
                    activeTab === 'syllabus'
                      ? 'text-[#0b63b6] border-b-2 border-[#0b63b6]'
                      : 'text-[#6e8396] hover:text-[#082e52]'
                  }`}
                >
                  Curriculum Modules ({course.syllabus.length})
                </button>
                <button
                  onClick={() => setActiveTab('resources')}
                  className={`text-xs font-bold pb-1 cursor-pointer transition-colors ${
                    activeTab === 'resources'
                      ? 'text-[#0b63b6] border-b-2 border-[#0b63b6]'
                      : 'text-[#6e8396] hover:text-[#082e52]'
                  }`}
                >
                  Learning Resources
                </button>
                <button
                  onClick={() => setActiveTab('assessments')}
                  className={`text-xs font-bold pb-1 cursor-pointer transition-colors flex items-center gap-1.5 ${
                    activeTab === 'assessments'
                      ? 'text-[#0b63b6] border-b-2 border-[#0b63b6]'
                      : 'text-[#6e8396] hover:text-[#082e52]'
                  }`}
                >
                  <FileQuestion size={13} />
                  <span>MCQ Evaluations</span>
                </button>
              </div>

              {course.isEnrolled && (
                <span className="text-xs font-bold text-[#0b63b6]">
                  Progress: {course.progress ?? 0}%
                </span>
              )}
            </div>

            {activeTab === 'syllabus' ? (
              <div className="space-y-3">
                {course.syllabus.map((mod, idx) => (
                  <div
                    key={idx}
                    onClick={() => handleModuleClick(idx)}
                    className={`p-3.5 rounded-xl border flex items-center justify-between gap-3 cursor-pointer transition-colors ${
                      mod.completed
                        ? 'bg-[#f4fcf6] border-[#c2ecd0] text-[#082e52]'
                        : 'bg-white border-[#e2edf6] hover:border-[#0b63b6]'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 ${
                          mod.completed
                            ? 'bg-emerald-500 text-white'
                            : 'bg-[#e8f5ff] text-[#0b63b6]'
                        }`}
                      >
                        {mod.completed ? <Check size={14} /> : idx + 1}
                      </div>
                      <div>
                        <span className="text-xs font-bold block">{mod.title}</span>
                        <span className="text-[10px] text-[#788e9f]">Module {idx + 1} • {mod.duration}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-[#f0f4f8] text-[#556b7f]">
                        {mod.completed ? 'Completed' : course.isEnrolled ? 'Mark Done' : 'Pending'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : activeTab === 'resources' ? (
              <div className="space-y-3">
                <div className="p-3.5 rounded-xl border border-[#e2edf6] bg-[#fbfdff] flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <FolderArchive size={20} className="text-[#0b63b6]" />
                    <div>
                      <b className="text-xs text-[#082e52] block">Operational Technical Manual & Guidelines.pdf</b>
                      <small className="text-[#64798e]">Official IMD High-Performance Modeling Manual • 12.4 MB</small>
                    </div>
                  </div>
                  <button className="secondary !py-1 !px-2.5 !text-xs font-bold cursor-pointer flex items-center gap-1">
                    <Download size={13} /> PDF
                  </button>
                </div>

                <div className="p-3.5 rounded-xl border border-[#e2edf6] bg-[#fbfdff] flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <FolderArchive size={20} className="text-[#0b63b6]" />
                    <div>
                      <b className="text-xs text-[#082e52] block">Numerical Analysis & Simulation Notebooks</b>
                      <small className="text-[#64798e]">Python & Scientific Data Analysis Scripts • 3.2 MB</small>
                    </div>
                  </div>
                  <button className="secondary !py-1 !px-2.5 !text-xs font-bold cursor-pointer flex items-center gap-1">
                    <Download size={13} /> Code
                  </button>
                </div>

                <div className="p-3.5 rounded-xl border border-[#e2edf6] bg-[#fbfdff] flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <FolderArchive size={20} className="text-[#0b63b6]" />
                    <div>
                      <b className="text-xs text-[#082e52] block">Observational & Satellite Datasets (NetCDF/HDF5)</b>
                      <small className="text-[#64798e]">High-Resolution Earth Observation Swaths • 45 MB</small>
                    </div>
                  </div>
                  <button className="secondary !py-1 !px-2.5 !text-xs font-bold cursor-pointer flex items-center gap-1">
                    <Download size={13} /> Data
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                {assessments
                  .filter(
                    (a) =>
                      a.courseId === course.id ||
                      course.id.toLowerCase().includes(a.courseId.toLowerCase()) ||
                      a.courseId.toLowerCase().includes(course.id.toLowerCase()) ||
                      a.courseTitle.toLowerCase().includes(course.title.toLowerCase())
                  )
                  .map((a) => (
                    <div
                      key={a.id}
                      className="p-4 rounded-xl border border-[#dce8f3] bg-[#fbfdff] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                    >
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-[10px] font-bold text-[#0b63b6] bg-[#e7f5ff] px-2 py-0.5 rounded">
                            {a.durationMinutes} Mins
                          </span>
                          <span className="text-[10px] font-bold text-[#556b7f] bg-[#f0f4f8] px-2 py-0.5 rounded">
                            {a.totalMarks} Marks (Pass: {a.passingMarks})
                          </span>
                        </div>
                        <b className="text-xs text-[#082e52] block">{a.title}</b>
                        <small className="text-[#64798e]">{a.questions.length} Multiple Choice Questions</small>
                      </div>
                      <button
                        onClick={() => onStartAssessment(a)}
                        className="primary !py-1.5 !px-3.5 !text-xs font-bold cursor-pointer shrink-0 flex items-center gap-1.5"
                      >
                        <Play size={13} />
                        <span>Start MCQ Test</span>
                      </button>
                    </div>
                  ))}
                {assessments.filter(
                  (a) =>
                    a.courseId === course.id ||
                    course.id.toLowerCase().includes(a.courseId.toLowerCase()) ||
                    a.courseId.toLowerCase().includes(course.id.toLowerCase()) ||
                    a.courseTitle.toLowerCase().includes(course.title.toLowerCase())
                ).length === 0 && (
                  <div className="p-6 text-center text-[#6e8396] text-xs">
                    <FileQuestion size={24} className="mx-auto mb-2 text-[#0b63b6]" />
                    <p className="font-semibold m-0">Module assessment will unlock upon completing syllabus units.</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Instructor & Action Card */}
        <div className="space-y-6">
          {/* Action / Enrollment Card */}
          <div className="bg-white border-2 border-[#dce8f3] rounded-2xl p-6 shadow-xs">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#8296a8] mb-1">
              Curriculum Enrollment
            </h4>
            <div className="text-xl font-extrabold text-[#082e52] mb-3">
              {course.isEnrolled ? (
                <span className="text-emerald-700 flex items-center gap-1.5">
                  <CheckCircle2 size={20} /> Active Enrollment
                </span>
              ) : (
                'Open for Trainee Enrollment'
              )}
            </div>

            {course.isEnrolled ? (
              <div className="space-y-4">
                <div className="p-3 bg-[#f0f7ff] rounded-xl border border-[#cbe3fa]">
                  <div className="flex items-center justify-between text-xs font-bold mb-1">
                    <span>Curriculum Progress</span>
                    <span className="text-[#0b63b6]">{course.progress ?? 0}%</span>
                  </div>
                  <div className="w-full bg-[#d7e7f5] h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-[#0b63b6] h-full rounded-full transition-all"
                      style={{ width: `${course.progress ?? 0}%` }}
                    />
                  </div>
                </div>

                <button
                  onClick={() => onNavigate('trainee-my-courses')}
                  className="primary w-full !text-xs !py-2.5 font-bold cursor-pointer flex items-center justify-center gap-2"
                >
                  <Play size={14} />
                  <span>Resume in My Courses</span>
                </button>

                <button
                  onClick={() => onNavigate('trainee-mcq-assessments')}
                  className="secondary w-full !text-xs !py-2.5 font-bold cursor-pointer flex items-center justify-center gap-2 border-[#b8d7f2] text-[#0b63b6] hover:bg-[#eaf4fd]"
                >
                  <FileQuestion size={14} />
                  <span>Take Course MCQ Assessment</span>
                </button>
              </div>
            ) : (
              <div>
                <p className="text-xs text-[#506579] mb-4 leading-relaxed">
                  Enroll to access official MoES learning resources, syllabus modules, practical lab data, and earn certified institutional accreditation.
                </p>
                <button
                  disabled={isEnrolling}
                  onClick={handleEnrollNow}
                  className="primary w-full !text-xs !py-3 font-bold cursor-pointer flex items-center justify-center gap-2 shadow-sm"
                >
                  {isEnrolling ? (
                    <>
                      <Loader2 size={15} className="animate-spin" />
                      <span>Enrolling in PostgreSQL...</span>
                    </>
                  ) : (
                    <>
                      <span>Enroll Now</span>
                      <ArrowRight size={14} />
                    </>
                  )}
                </button>
              </div>
            )}

            <div className="mt-4 pt-4 border-t border-[#edf2f6] text-[11px] text-[#697f94] space-y-1">
              <div className="flex items-center gap-1.5">
                <ShieldCheck size={14} className="text-emerald-600" />
                <span>Authorized MoES & IMD Training Program</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Award size={14} className="text-[#0b63b6]" />
                <span>Includes Verifiable Digital Certificate</span>
              </div>
            </div>
          </div>

          {/* Instructor Profile Card */}
          <div className="bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#8296a8] mb-3">
              Lead Course Mentor
            </h4>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-[#0b63b6] to-[#49bcf7] text-white flex items-center justify-center text-lg font-extrabold shadow-sm">
                {course.trainer[0]}
              </div>
              <div>
                <h4 className="text-sm font-bold text-[#082e52] m-0">{course.trainer}</h4>
                <p className="text-xs text-[#0b63b6] font-semibold m-0">{course.trainerRole}</p>
              </div>
            </div>
            <p className="text-xs text-[#506579] leading-relaxed">
              Senior research specialist and scientific division head overseeing operational forecasting, computational simulations, and capacity development across national observational centers.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
