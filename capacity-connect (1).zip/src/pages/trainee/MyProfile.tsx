import React, { useState, useEffect } from 'react';
import {
  User,
  Mail,
  MapPin,
  Building,
  Award,
  ShieldCheck,
  CheckCircle2,
  Phone,
  Briefcase,
  GraduationCap,
  Sparkles,
  AlertCircle,
  Loader2,
  RefreshCw,
} from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { traineeApiService, TraineeCertificateItem } from '../../services/traineeApiService';

interface MyProfileProps {
  onNavigate: (page: AppPage) => void;
}

export const MyProfile: React.FC<MyProfileProps> = ({ onNavigate }) => {
  const { user, updateProfile } = useAuth();

  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [isSaved, setIsSaved] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [certificates, setCertificates] = useState<TraineeCertificateItem[]>([]);

  const [formData, setFormData] = useState({
    name: 'Arjun Singhania',
    designation: 'Meteorologist Grade-I',
    department: 'India Meteorological Department (IMD)',
    division: 'National Weather Forecasting Centre (NWFC)',
    location: 'Mausam Bhawan, Lodhi Road, New Delhi',
    email: user?.email || 'arjun.singhania@imd.gov.in',
    phone: '+91 98765 43210',
    qualification: 'M.Sc. Atmospheric Sciences, IIT Delhi',
    workExperience: '3 Years in Operational Forecaster Division',
    skills: 'NWP Models, Satellite Imagery Analysis, Python (MetPy/Cartopy), Synoptic Analysis',
    interests: 'Tropical Cyclogenesis, Extreme Rainfall Nowcasting, Doppler Radar Interpretation',
    specialization: 'Operational NWP Forecasting, Extreme Convection & Severe Weather Nowcasting',
    joiningYear: '2022',
    employeeId: 'IMD-ND-7842',
  });

  // Load trainee profile and certificates from PostgreSQL database
  const loadProfileFromDatabase = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const email = user?.email || 'arjun.singhania@imd.gov.in';
      const [profileResult, certsResult] = await Promise.all([
        traineeApiService.getProfile(email),
        traineeApiService.getCertificates(email),
      ]);

      if (profileResult.profile) {
        const p = profileResult.profile;
        setFormData({
          name: p.name || 'Arjun Singhania',
          designation: p.designation || 'Meteorologist Grade-I',
          department: p.department || 'India Meteorological Department (IMD)',
          division: p.division || 'National Weather Forecasting Centre (NWFC)',
          location: p.location || 'Mausam Bhawan, Lodhi Road, New Delhi',
          email: p.email || email,
          phone: p.phone || '+91 98765 43210',
          qualification: p.qualification || 'M.Sc. Atmospheric Sciences, IIT Delhi',
          workExperience: p.workExperience || '3 Years in Operational Forecaster Division',
          skills: Array.isArray(p.skills) ? p.skills.join(', ') : p.skills || '',
          interests: Array.isArray(p.interests) ? p.interests.join(', ') : p.interests || '',
          specialization: p.specialization || 'Operational NWP Forecasting, Extreme Convection & Severe Weather Nowcasting',
          joiningYear: p.joiningYear || '2022',
          employeeId: p.employeeId || 'IMD-ND-7842',
        });
      }

      if (certsResult.certificates) {
        setCertificates(certsResult.certificates);
      }
    } catch (err: any) {
      console.warn('Database load error:', err);
      setErrorMessage('Could not connect to live database. Displaying cached institutional profile.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadProfileFromDatabase();
  }, [user?.email]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setErrorMessage(null);

    try {
      const email = formData.email || user?.email || 'arjun.singhania@imd.gov.in';
      const result = await traineeApiService.updateProfile(
        {
          name: formData.name,
          phone: formData.phone,
          department: formData.department,
          designation: formData.designation,
          division: formData.division,
          location: formData.location,
          qualification: formData.qualification,
          workExperience: formData.workExperience,
          skills: formData.skills ? formData.skills.split(',').map((s) => s.trim()) : [],
          interests: formData.interests ? formData.interests.split(',').map((s) => s.trim()) : [],
          specialization: formData.specialization,
        },
        email
      );

      if (result.success) {
        updateProfile({
          name: formData.name,
          phone: formData.phone,
          department: formData.department,
          designation: formData.designation,
          qualification: formData.qualification,
          workExperience: formData.workExperience,
        });
        setIsSaved(true);
        setTimeout(() => setIsSaved(false), 4000);
      } else {
        setErrorMessage(result.error || 'Failed to save changes to database.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Error communicating with PostgreSQL server.');
    } finally {
      setIsSaving(false);
    }
  };

  const userInitials = formData.name
    .split(' ')
    .map((n) => n[0])
    .slice(0, 2)
    .join('');

  const skillsList = formData.skills
    ? formData.skills.split(',').map((s) => s.trim()).filter(Boolean)
    : [];

  const interestsList = formData.interests
    ? formData.interests.split(',').map((s) => s.trim()).filter(Boolean)
    : [];

  return (
    <div>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-6">
        <PageHeader
          badge="POSTGRESQL SYNCED"
          title="Trainee Profile"
          subtitle="Manage your personal credentials, organizational postings, and verified competencies stored in Cloud SQL."
          backPage="trainee-dashboard"
          onBack={onNavigate}
        />
        <button
          onClick={loadProfileFromDatabase}
          disabled={isLoading}
          className="secondary !py-2 !px-3 !text-xs cursor-pointer flex items-center gap-1.5 shrink-0"
          title="Refresh database records"
        >
          <RefreshCw size={13} className={isLoading ? 'animate-spin' : ''} />
          <span>Sync from Database</span>
        </button>
      </div>

      {/* Success Notification */}
      {isSaved && (
        <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-semibold flex items-center gap-2 animate-fade-in">
          <CheckCircle2 size={18} className="text-emerald-600 shrink-0" />
          <span>Profile records successfully synchronized and committed to PostgreSQL database.</span>
        </div>
      )}

      {/* Error Notification */}
      {errorMessage && (
        <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm font-semibold flex items-center gap-2 animate-fade-in">
          <AlertCircle size={18} className="text-rose-600 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {isLoading ? (
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-12 text-center text-[#506579]">
          <Loader2 size={32} className="animate-spin text-[#0b63b6] mx-auto mb-3" />
          <p className="text-sm font-semibold">Retrieving trainee dossier from Cloud SQL PostgreSQL...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left ID & Competency Card */}
          <div className="space-y-6">
            <div className="bg-white border border-[#dce8f3] rounded-2xl p-6 text-center shadow-xs">
              <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-[#0b63b6] to-[#49bcf7] text-white flex items-center justify-center mx-auto mb-4 text-3xl font-extrabold shadow-md">
                {userInitials}
              </div>
              <h2 className="text-xl font-bold text-[#082e52] m-0 mb-1">{formData.name}</h2>
              <p className="text-xs text-[#0b63b6] font-bold uppercase tracking-wider mb-2">
                {formData.designation}
              </p>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#f0f9f3] text-emerald-700 rounded-full text-xs font-semibold border border-emerald-200 mb-6">
                <ShieldCheck size={14} /> Cloud SQL Verified Record
              </div>

              <div className="space-y-3 text-left border-t border-[#edf2f6] pt-5 text-xs text-[#506579]">
                <div className="flex items-center gap-2">
                  <Building size={15} className="text-[#889cb0] shrink-0" />
                  <span className="truncate">{formData.division}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin size={15} className="text-[#889cb0] shrink-0" />
                  <span className="truncate">{formData.location}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail size={15} className="text-[#889cb0] shrink-0" />
                  <span className="font-mono truncate">{formData.email}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone size={15} className="text-[#889cb0] shrink-0" />
                  <span>{formData.phone}</span>
                </div>
              </div>

              <div className="mt-6 pt-5 border-t border-[#edf2f6] text-left">
                <h4 className="text-xs font-bold text-[#082e52] uppercase mb-2 flex items-center gap-1.5">
                  <Sparkles size={13} className="text-[#0b63b6]" /> Verified Technical Skills
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {skillsList.length > 0 ? (
                    skillsList.map((s, idx) => (
                      <span key={idx} className="px-2 py-1 rounded bg-[#e8f5ff] text-[#0b63b6] text-[11px] font-bold">
                        {s}
                      </span>
                    ))
                  ) : (
                    <span className="text-xs text-[#8ca0b3]">No skills recorded yet.</span>
                  )}
                </div>
              </div>

              {interestsList.length > 0 && (
                <div className="mt-4 pt-4 border-t border-[#edf2f6] text-left">
                  <h4 className="text-xs font-bold text-[#082e52] uppercase mb-2">Research Interests</h4>
                  <div className="flex flex-wrap gap-1.5">
                    {interestsList.map((interest, idx) => (
                      <span key={idx} className="px-2 py-1 rounded bg-[#f4f8fb] text-[#476079] text-[11px] font-semibold border border-[#d8e6f2]">
                        {interest}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Issued Certificates Overview Card */}
            <div className="bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs">
              <h3 className="text-sm font-bold text-[#082e52] mb-3 flex items-center gap-2">
                <Award size={16} className="text-[#0b63b6]" />
                <span>Verified Certificates ({certificates.length})</span>
              </h3>
              {certificates.length === 0 ? (
                <p className="text-xs text-[#6e859b]">No certificates issued yet.</p>
              ) : (
                <div className="space-y-2.5">
                  {certificates.map((cert) => (
                    <div key={cert.id} className="p-3 bg-[#f8fbfe] border border-[#e1effa] rounded-xl text-xs">
                      <div className="font-bold text-[#082e52] line-clamp-1">{cert.courseName}</div>
                      <div className="text-[11px] text-[#637d97] font-mono mt-0.5">{cert.certificateNumber}</div>
                      <div className="flex items-center justify-between mt-2 pt-1 border-t border-[#eaf2f8] text-[10px] text-[#0b63b6]">
                        <span className="font-semibold">{cert.issueDate}</span>
                        <span className="font-bold bg-[#e8f5ff] px-2 py-0.5 rounded text-emerald-700">
                          {cert.status} • {cert.score}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Right Form Card - Edit Profile */}
          <div className="lg:col-span-2 bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-[#edf2f6] mb-5">
              <h3 className="text-lg font-bold text-[#082e52] m-0">
                Official Personnel Dossier
              </h3>
              <span className="text-xs font-semibold text-[#0b63b6] bg-[#f0f7ff] px-2.5 py-1 rounded-md border border-[#cde2f5]">
                Database Connected
              </span>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-[#3d546a] block mb-1">Full Legal Name</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-[#3d546a] block mb-1">MoES Employee ID</label>
                  <input
                    type="text"
                    readOnly
                    value={formData.employeeId}
                    className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#f0f4f8] text-sm text-[#66798c] cursor-not-allowed"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-[#3d546a] block mb-1">Designation / Cadre</label>
                  <input
                    type="text"
                    value={formData.designation}
                    onChange={(e) => setFormData({ ...formData, designation: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-[#3d546a] block mb-1">Official Email Address</label>
                  <input
                    type="email"
                    readOnly
                    value={formData.email}
                    className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#f0f4f8] text-sm text-[#66798c] cursor-not-allowed"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-[#3d546a] block mb-1">Contact Phone / Intercom</label>
                  <input
                    type="text"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-[#3d546a] block mb-1">Institutional Department</label>
                  <input
                    type="text"
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-[#3d546a] block mb-1">Highest Academic Qualification</label>
                  <input
                    type="text"
                    value={formData.qualification}
                    onChange={(e) => setFormData({ ...formData, qualification: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-[#3d546a] block mb-1">Work Experience</label>
                  <input
                    type="text"
                    value={formData.workExperience}
                    onChange={(e) => setFormData({ ...formData, workExperience: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-[#3d546a] block mb-1">Operational Division</label>
                  <input
                    type="text"
                    value={formData.division}
                    onChange={(e) => setFormData({ ...formData, division: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-[#3d546a] block mb-1">Station Location</label>
                  <input
                    type="text"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-[#3d546a] block mb-1">
                  Technical Skills (Comma separated)
                </label>
                <input
                  type="text"
                  value={formData.skills}
                  onChange={(e) => setFormData({ ...formData, skills: e.target.value })}
                  placeholder="e.g. NWP Models, Satellite Imagery Analysis, Python"
                  className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-[#3d546a] block mb-1">
                  Learning & Research Interests (Comma separated)
                </label>
                <input
                  type="text"
                  value={formData.interests}
                  onChange={(e) => setFormData({ ...formData, interests: e.target.value })}
                  placeholder="e.g. Tropical Cyclones, Severe Convection, Nowcasting"
                  className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-[#3d546a] block mb-1">
                  Technical Research Focus & Specialization
                </label>
                <textarea
                  rows={3}
                  value={formData.specialization}
                  onChange={(e) => setFormData({ ...formData, specialization: e.target.value })}
                  className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
                />
              </div>

              <div className="pt-4 flex justify-end gap-3 border-t border-[#edf2f6]">
                <button
                  type="button"
                  onClick={() => onNavigate('trainee-dashboard')}
                  className="secondary text-xs font-semibold py-2.5 px-4 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="primary text-xs font-bold py-2.5 px-6 cursor-pointer flex items-center gap-2"
                >
                  {isSaving ? (
                    <>
                      <Loader2 size={14} className="animate-spin" />
                      <span>Saving to PostgreSQL...</span>
                    </>
                  ) : (
                    <span>Save Profile to Database</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
