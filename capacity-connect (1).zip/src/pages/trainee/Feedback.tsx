import React, { useState } from 'react';
import { MessageSquare, Star, Send, CheckCircle2 } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, Course } from '../../types';

interface FeedbackProps {
  courses: Course[];
  onNavigate: (page: AppPage) => void;
}

export const Feedback: React.FC<FeedbackProps> = ({ courses, onNavigate }) => {
  const [selectedCourse, setSelectedCourse] = useState(courses[0]?.id || '');
  const [rating, setRating] = useState(5);
  const [trainerRating, setTrainerRating] = useState(5);
  const [clarityRating, setClarityRating] = useState(5);
  const [comments, setComments] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setComments('');
      setSubmitted(false);
    }, 3500);
  };

  return (
    <div>
      <PageHeader
        badge="CONTINUOUS IMPROVEMENT"
        title="Course & Trainer Feedback"
        subtitle="Submit anonymous academic evaluations to help MoES refine curriculum, laboratory practicals, and instructional quality."
        backPage="trainee-dashboard"
        onBack={onNavigate}
      />

      {submitted && (
        <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-semibold flex items-center gap-2">
          <CheckCircle2 size={18} className="text-emerald-600" />
          <span>Thank you! Your feedback has been submitted to the Academic Review Committee.</span>
        </div>
      )}

      <div className="max-w-2xl bg-white border border-[#dce8f3] rounded-2xl p-6 md:p-8 shadow-xs">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="text-xs font-bold text-[#3a5268] block mb-1.5">
              Select Completed or Ongoing Course
            </label>
            <select
              value={selectedCourse}
              onChange={(e) => setSelectedCourse(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
            >
              {courses.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.title} — {c.trainer}
                </option>
              ))}
            </select>
          </div>

          {/* Star ratings */}
          <div className="space-y-4 pt-2 border-t border-[#edf2f6]">
            <div>
              <label className="text-xs font-bold text-[#3a5268] block mb-1">
                Overall Course Content & Relevance (1 to 5 Stars)
              </label>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    className="p-1 cursor-pointer transition-transform hover:scale-110"
                  >
                    <Star
                      size={24}
                      className={
                        star <= rating
                          ? 'text-amber-500 fill-amber-400'
                          : 'text-[#d0dde8]'
                      }
                    />
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-[#3a5268] block mb-1">
                Instructor Responsiveness & Mentorship Quality
              </label>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setTrainerRating(star)}
                    className="p-1 cursor-pointer transition-transform hover:scale-110"
                  >
                    <Star
                      size={24}
                      className={
                        star <= trainerRating
                          ? 'text-amber-500 fill-amber-400'
                          : 'text-[#d0dde8]'
                      }
                    />
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-[#3a5268] block mb-1">
                Clarity of MCQ Assessments & Practical Assignments
              </label>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setClarityRating(star)}
                    className="p-1 cursor-pointer transition-transform hover:scale-110"
                  >
                    <Star
                      size={24}
                      className={
                        star <= clarityRating
                          ? 'text-amber-500 fill-amber-400'
                          : 'text-[#d0dde8]'
                      }
                    />
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-[#3a5268] block mb-1.5">
              Specific Suggestions for Practical Workflows / HPC Exercises
            </label>
            <textarea
              required
              rows={4}
              placeholder="e.g. Include more real-world DWR radar cases from recent monsoon squall lines..."
              value={comments}
              onChange={(e) => setComments(e.target.value)}
              className="w-full p-3 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
            />
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              className="primary text-xs font-bold py-2.5 px-6 inline-flex items-center gap-2 cursor-pointer"
            >
              <Send size={14} /> Submit Confidential Review
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
