import React, { useState, useEffect } from 'react';
import {
  BookOpen,
  CheckCircle2,
  FileQuestion,
  Award,
  ArrowRight,
  TrendingUp,
  Sparkles,
  Calendar,
  Bell,
  RefreshCw,
  Loader2,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';
import { AppPage, Course, Assessment } from '../../types';
import { useAuth } from '../../context/AuthContext';
import {
  traineeApiService,
  TraineeDashboardData,
  TraineeEnrolledCourse,
  TraineeCertificateItem,
  TraineeNotificationItem,
} from '../../services/traineeApiService';

interface TraineeDashboardProps {
  courses: Course[];
  assessments: Assessment[];
  onNavigate: (page: AppPage) => void;
  onSelectCourse: (course: Course) => void;
  onStartAssessment: (assessment: Assessment) => void;
}

export const TraineeDashboard: React.FC<TraineeDashboardProps> = ({
  courses,
  assessments,
  onNavigate,
  onSelectCourse,
  onStartAssessment,
}) => {
  const { user } = useAuth();

  const [dbData, setDbData] = useState<TraineeDashboardData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchDashboardData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const email = user?.email || 'arjun.singhania@imd.gov.in';
      const result = await traineeApiService.getDashboardData(email);
      if (result.dashboard) {
        setDbData(result.dashboard);
      } else if (result.error) {
        setError(result.error);
      }
    } catch (err: any) {
      console.warn('Dashboard fetch error:', err);
      setError('Unable to fetch live database records. Showing default view.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, [user?.email]);

  const handleMarkNotification = async (id: number) => {
    await traineeApiService.markNotificationRead(id, user?.email);
    if (dbData) {
      setDbData({
        ...dbData,
        notifications: dbData.notifications.map((n) =>
          n.id === id ? { ...n, read: true } : n
        ),
        unreadNotificationsCount: Math.max(0, dbData.unreadNotificationsCount - 1),
      });
    }
  };

  const enrolledFromDb: TraineeEnrolledCourse[] = dbData?.enrolledCourses || [];
  const enrolledCount = dbData ? dbData.totalEnrolledCount : courses.filter((c) => c.isEnrolled).length;
  const completedCount = dbData ? dbData.completedCoursesCount : 1;
  const certificatesCount = dbData ? dbData.certificatesCount : 2;
  const unreadNotifsCount = dbData ? dbData.unreadNotificationsCount : 2;

  return (
    <div>
      <div className="flex items-center justify-between gap-3 mb-1">
        <p className="text-xs font-bold text-[#8295a7] uppercase tracking-wider m-0">
          CAPACITY CONNECT / TRAINEE WORKSPACE
        </p>
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#e8f5ff] text-[#0b63b6] border border-[#cbe6fa]">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            Cloud SQL Connected
          </span>
          <button
            onClick={fetchDashboardData}
            disabled={isLoading}
            className="p-1 rounded-md text-[#506579] hover:text-[#0b63b6] hover:bg-white border border-transparent hover:border-[#dce8f3] cursor-pointer"
            title="Refresh database"
          >
            <RefreshCw size={13} className={isLoading ? 'animate-spin' : ''} />
          </button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-extrabold text-[#082e52] tracking-tight m-0">
            Good day, {user?.name ? user.name.split(' ')[0] : 'Arjun'} 👋
          </h1>
          <p className="text-sm text-[#66798c] mt-1 mb-0">
            {user?.designation || 'Meteorologist Grade-I'} • {user?.department || 'India Meteorological Department (IMD)'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('trainee-explore-courses')}
            className="secondary text-xs font-bold py-2.5 px-3.5 cursor-pointer"
          >
            Explore Catalogue
          </button>
          <button
            onClick={() => onNavigate('trainee-mcq-assessments')}
            className="primary text-xs font-bold py-2.5 px-4 cursor-pointer inline-flex items-center gap-1.5"
          >
            <span>Take Assessment</span>
            <ArrowRight size={14} />
          </button>
        </div>
      </div>

      {error && (
        <div className="mb-6 p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle size={16} className="text-amber-600 shrink-0" />
            <span>{error}</span>
          </div>
          <button
            onClick={fetchDashboardData}
            className="font-bold underline text-amber-900 cursor-pointer"
          >
            Retry
          </button>
        </div>
      )}

      {/* Stats row (preserves original CAPACITY CONNECT design tokens) */}
      <div className="dashstats">
        <div>
          <BookOpen />
          <small>Enrolled Courses</small>
          <strong>{enrolledCount}</strong>
        </div>
        <div>
          <CheckCircle2 />
          <small>Completed Courses</small>
          <strong>{completedCount}</strong>
        </div>
        <div>
          <FileQuestion />
          <small>Assessments Passed</small>
          <strong>
            {dbData?.assessmentScores ? dbData.assessmentScores.filter((s) => s.passed).length : 3}
          </strong>
        </div>
        <div>
          <Award />
          <small>Certificates Earned</small>
          <strong>{certificatesCount}</strong>
        </div>
      </div>

      {/* Main Panels Grid (preserves original panels layout) */}
      <div className="panels">
        {/* Left Panel: Course Summary & Continue Learning */}
        <div className="panel">
          <h2>
            <span>Enrolled Courses Summary</span>
            <button
              onClick={() => onNavigate('trainee-my-courses')}
              className="text-xs text-[#0b63b6] hover:underline font-bold"
            >
              View All ({enrolledCount}) →
            </button>
          </h2>

          {isLoading ? (
            <div className="py-12 text-center text-[#66798c]">
              <Loader2 size={24} className="animate-spin text-[#0b63b6] mx-auto mb-2" />
              <p className="text-xs font-semibold">Loading courses from PostgreSQL database...</p>
            </div>
          ) : enrolledFromDb.length > 0 ? (
            <div className="space-y-2">
              {enrolledFromDb.map((c) => (
                <div
                  key={c.enrollmentId || c.courseId}
                  className="row hover:bg-[#f8fbfe] rounded-xl p-3 border border-[#edf3f8] cursor-pointer transition-colors"
                >
                  <div className="w-10 h-10 rounded-xl bg-[#e8f5ff] text-[#0b63b6] flex items-center justify-center shrink-0">
                    <BookOpen size={18} />
                  </div>
                  <div className="flex-1 min-w-0 pr-2">
                    <div className="flex items-center gap-2">
                      <b className="text-xs text-[#082e52] font-bold truncate block">{c.title}</b>
                      {c.completed ? (
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-700 shrink-0">
                          Completed
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-100 text-[#0b63b6] shrink-0">
                          In Progress
                        </span>
                      )}
                    </div>
                    <small className="text-[#64798e] block text-[11px] mt-0.5 truncate">
                      Trainer: {c.trainerName} • Category: {c.category} • {c.duration}
                    </small>
                    <div className="w-full bg-[#e8f1f8] h-1.5 rounded-full overflow-hidden mt-2 max-w-md">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          c.completed ? 'bg-emerald-500' : 'bg-[#0b63b6]'
                        }`}
                        style={{ width: `${c.progress}%` }}
                      />
                    </div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <strong className="text-xs font-extrabold text-[#082e52]">
                      {c.progress}%
                    </strong>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        const foundCourse: Course = courses.find((orig) => orig.id === c.courseId) || {
                          id: c.courseId,
                          title: c.title,
                          description: c.description,
                          trainer: c.trainerName,
                          trainerRole: 'Senior Scientist',
                          category: c.category,
                          duration: c.duration,
                          level: c.level as any,
                          rating: 4.8,
                          enrolledCount: 140,
                          modulesCount: 4,
                          progress: c.progress,
                          isEnrolled: true,
                          syllabus: [],
                        };
                        onSelectCourse(foundCourse);
                        onNavigate('trainee-course-details');
                      }}
                      className="primary !py-1 !px-2.5 !text-[11px] font-bold cursor-pointer shrink-0"
                    >
                      Continue Learning
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-1">
              {courses.filter((c) => c.isEnrolled).map((c) => (
                <div
                  key={c.id}
                  onClick={() => {
                    onSelectCourse(c);
                    onNavigate('trainee-course-details');
                  }}
                  className="row hover:bg-[#f8fbfe] rounded-xl px-2 cursor-pointer transition-colors"
                >
                  <div className="w-10 h-10 rounded-xl bg-[#e8f5ff] text-[#0b63b6] flex items-center justify-center shrink-0">
                    <BookOpen size={18} />
                  </div>
                  <span>
                    <b>{c.title}</b>
                    <small>
                      {c.trainer} • {c.duration} • Category: {c.category}
                    </small>
                    <div className="w-full bg-[#e8f1f8] h-1.5 rounded-full overflow-hidden mt-2 max-w-md">
                      <div
                        className="bg-[#0b63b6] h-full rounded-full"
                        style={{ width: `${c.progress ?? 0}%` }}
                      />
                    </div>
                  </span>
                  <strong className="text-sm font-extrabold text-[#082e52] pl-2 shrink-0">
                    {c.progress ?? 0}%
                  </strong>
                </div>
              ))}
            </div>
          )}

          {/* Database Issued Certificates Section */}
          <div className="mt-6 pt-5 border-t border-[#edf2f6]">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-[#082e52] m-0 flex items-center gap-1.5">
                <Award size={16} className="text-[#0b63b6]" />
                <span>Verified Certificates ({dbData?.certificates?.length ?? 1})</span>
              </h3>
              <button
                onClick={() => onNavigate('trainee-certificates')}
                className="text-xs text-[#0b63b6] hover:underline font-bold"
              >
                All Certificates →
              </button>
            </div>

            {dbData?.certificates && dbData.certificates.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {dbData.certificates.map((cert) => (
                  <div
                    key={cert.id}
                    className="p-3 rounded-xl bg-[#f8fbfe] border border-[#d6e7f5] hover:border-[#0b63b6] transition-colors"
                  >
                    <div className="text-xs font-bold text-[#082e52] line-clamp-1">{cert.courseName}</div>
                    <div className="text-[11px] font-mono text-[#5b738c] mt-0.5">{cert.certificateNumber}</div>
                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-[#e2effa] text-[10px]">
                      <span className="text-[#758ba0]">{cert.issueDate}</span>
                      <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                        {cert.status} • {cert.score}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-3 bg-[#f8fbfe] rounded-xl border border-[#dce8f3] text-xs text-[#506579]">
                Operational Oceanography & Storm Surge Forecasting (MoES-IMD-2026-8842)
              </div>
            )}
          </div>
        </div>

        {/* Right Panel: Notifications & Recent Activity from Database */}
        <div className="space-y-6">
          {/* Notifications Panel */}
          <div className="panel">
            <h2>
              <span className="flex items-center gap-1.5">
                <Bell size={16} className="text-[#0b63b6]" />
                <span>Trainee Notifications</span>
              </span>
              <button
                onClick={() => onNavigate('trainee-notifications')}
                className="text-xs text-[#0b63b6] hover:underline font-bold"
              >
                Inbox ({unreadNotifsCount}) →
              </button>
            </h2>

            <div className="space-y-2">
              {dbData?.notifications && dbData.notifications.length > 0 ? (
                dbData.notifications.slice(0, 3).map((notif) => (
                  <div
                    key={notif.id}
                    className={`p-3 rounded-xl border text-xs transition-colors ${
                      notif.read
                        ? 'bg-white border-[#edf2f6] text-[#6b8094]'
                        : 'bg-[#f0f7ff] border-[#cbe3fa] text-[#082e52]'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <b className="text-xs font-bold leading-tight">{notif.title}</b>
                      {!notif.read && (
                        <button
                          onClick={() => handleMarkNotification(notif.id)}
                          className="text-[10px] text-[#0b63b6] hover:underline font-bold shrink-0 cursor-pointer"
                        >
                          Mark read
                        </button>
                      )}
                    </div>
                    <p className="text-[11px] text-[#4f6479] mt-1 mb-1.5 leading-snug">
                      {notif.message}
                    </p>
                    <div className="text-[10px] text-[#869ab0] font-medium">{notif.date}</div>
                  </div>
                ))
              ) : (
                <p className="text-xs text-[#66798c]">No new notifications.</p>
              )}
            </div>
          </div>

          {/* Pending Assessments */}
          <div className="panel">
            <h2>
              <span>Pending Assessments</span>
              <button
                onClick={() => onNavigate('trainee-mcq-assessments')}
                className="text-xs text-[#0b63b6] hover:underline font-bold"
              >
                All Tests →
              </button>
            </h2>

            {assessments
              .filter((a) => a.status === 'Available')
              .slice(0, 2)
              .map((a) => (
                <div key={a.id} className="p-3.5 bg-[#fbfdff] border border-[#dce8f3] rounded-xl mb-3">
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <b className="text-xs text-[#082e52] font-bold block">{a.title}</b>
                    <span className="text-[10px] font-extrabold bg-[#e8f5ff] text-[#0b63b6] px-2 py-0.5 rounded-md shrink-0">
                      {a.durationMinutes} Mins
                    </span>
                  </div>
                  <p className="text-[11px] text-[#66798c] m-0 mb-3">
                    Course: {a.courseTitle}
                  </p>
                  <button
                    onClick={() => onStartAssessment(a)}
                    className="primary !py-1.5 !px-3 !text-xs font-bold w-full cursor-pointer"
                  >
                    Start Test Now <ArrowRight size={13} />
                  </button>
                </div>
              ))}
          </div>

          {/* Recent Learning Activity from Database */}
          <div className="panel">
            <h2>Recent Learning Activity</h2>
            <div className="space-y-0.5">
              {(dbData?.recentActivities && dbData.recentActivities.length > 0
                ? dbData.recentActivities
                : [
                    { title: 'Completed Module 3 Quiz', description: 'Scored 93% in WRF Boundary Layer Parameterizations', timestamp: '2 hours ago' },
                    { title: 'Studied INSAT-3DR Rapid Scan', description: 'Reviewed convective cloud-top cooling signatures', timestamp: 'Yesterday' },
                    { title: 'Certificate Earned', description: 'Issued certification for Operational Oceanography', timestamp: 'Feb 18, 2026' },
                  ]
              ).map((act, i) => (
                <div key={i} className="activity">
                  <CheckCircle2 size={16} className="text-[#0b63b6] shrink-0" />
                  <div className="text-xs">
                    <span className="text-[#10243e] font-semibold block">{act.title}</span>
                    <span className="text-[11px] text-[#55697d] block">{act.description}</span>
                    <span className="text-[10px] text-[#8ea0b2] mt-0.5 block">{act.timestamp}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
