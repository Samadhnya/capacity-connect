import React from 'react';
import { FileQuestion, Clock, Award, CheckCircle2, Play, RotateCcw } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, Assessment } from '../../types';

interface MCQAssessmentsProps {
  assessments: Assessment[];
  onNavigate: (page: AppPage) => void;
  onStartAssessment: (assessment: Assessment) => void;
}

export const MCQAssessments: React.FC<MCQAssessmentsProps> = ({
  assessments,
  onNavigate,
  onStartAssessment,
}) => {
  return (
    <div>
      <PageHeader
        badge="EVALUATION SYSTEM"
        title="MCQ Assessments"
        subtitle="Attempt module-wise evaluations to benchmark your understanding of theoretical concepts and operational guidelines."
        backPage="trainee-dashboard"
        onBack={onNavigate}
        actionText="View Past Results"
        actionIcon={<Award size={16} />}
        onAction={() => onNavigate('trainee-assessment-result')}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {assessments.map((a) => {
          const isCompleted = a.status === 'Completed';
          return (
            <div
              key={a.id}
              className="bg-white border border-[#dce8f3] rounded-2xl p-6 flex flex-col justify-between hover:shadow-md transition-shadow"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <span className="text-[11px] font-extrabold uppercase text-[#0b63b6] bg-[#e7f5ff] px-2.5 py-1 rounded-md">
                    {a.durationMinutes} Minutes
                  </span>
                  <span
                    className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                      isCompleted
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {isCompleted ? 'Completed' : 'Available'}
                  </span>
                </div>

                <h3 className="text-base font-bold text-[#082e52] mb-1 leading-snug">
                  {a.title}
                </h3>
                <p className="text-xs text-[#66798c] mb-4">
                  Course: <b className="text-[#3b5268]">{a.courseTitle}</b>
                </p>

                <div className="grid grid-cols-2 gap-2 p-3 bg-[#f8fbfe] rounded-xl border border-[#e2edf6] text-center text-xs mb-4">
                  <div>
                    <span className="text-[10px] text-[#8295a7] uppercase font-bold block">
                      Total Marks
                    </span>
                    <span className="font-extrabold text-[#082e52] text-sm">{a.totalMarks}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-[#8295a7] uppercase font-bold block">
                      Passing Marks
                    </span>
                    <span className="font-extrabold text-emerald-700 text-sm">
                      {a.passingMarks}
                    </span>
                  </div>
                </div>

                {isCompleted && a.score !== undefined && (
                  <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-xs font-semibold text-emerald-800 flex items-center justify-between mb-2">
                    <span className="flex items-center gap-1.5">
                      <CheckCircle2 size={16} className="text-emerald-600" /> Score Achieved
                    </span>
                    <span className="font-bold text-sm">
                      {a.score} / {a.maxScore ?? a.totalMarks}
                    </span>
                  </div>
                )}
              </div>

              <div className="pt-4 border-t border-[#edf2f6]">
                <button
                  onClick={() => onStartAssessment(a)}
                  className={`w-full !text-xs !py-2.5 font-bold inline-flex items-center justify-center gap-2 cursor-pointer ${
                    isCompleted ? 'secondary' : 'primary'
                  }`}
                >
                  {isCompleted ? (
                    <>
                      <RotateCcw size={14} /> Retake Test
                    </>
                  ) : (
                    <>
                      <Play size={14} /> Start Assessment
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
