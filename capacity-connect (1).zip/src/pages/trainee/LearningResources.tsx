import React, { useState } from 'react';
import {
  FolderArchive,
  Search,
  Download,
  FileText,
  Video,
  FileCode,
  Filter,
  CheckCircle2,
} from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, Resource } from '../../types';

interface LearningResourcesProps {
  resources: Resource[];
  onNavigate: (page: AppPage) => void;
}

export const LearningResources: React.FC<LearningResourcesProps> = ({
  resources,
  onNavigate,
}) => {
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('All');
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  const filtered = resources.filter((r) => {
    const matchesSearch =
      r.title.toLowerCase().includes(search.toLowerCase()) ||
      r.category.toLowerCase().includes(search.toLowerCase()) ||
      r.uploadedBy.toLowerCase().includes(search.toLowerCase());
    const matchesType = typeFilter === 'All' || r.type === typeFilter;
    return matchesSearch && matchesType;
  });

  const handleDownload = (res: Resource) => {
    setDownloadSuccess(`Downloaded "${res.title}" successfully.`);
    setTimeout(() => setDownloadSuccess(null), 3500);
  };

  const getIcon = (type: Resource['type']) => {
    switch (type) {
      case 'PDF':
        return <FileText className="text-rose-500" size={20} />;
      case 'Video':
        return <Video className="text-sky-500" size={20} />;
      case 'Dataset':
        return <FileCode className="text-emerald-500" size={20} />;
      default:
        return <FolderArchive className="text-amber-500" size={20} />;
    }
  };

  return (
    <div>
      <PageHeader
        badge="CENTRAL REPOSITORY"
        title="Learning Resources"
        subtitle="Access peer-reviewed manuals, lecture slide decks, radar recordings, and meteorological sample datasets."
        backPage="trainee-dashboard"
        onBack={onNavigate}
      />

      {downloadSuccess && (
        <div className="mb-6 p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 size={16} className="text-emerald-600" />
          <span>{downloadSuccess}</span>
        </div>
      )}

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#889eb5]" />
          <input
            type="text"
            placeholder="Search manuals, datasets, lectures by keyword or author..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-[#d4e1eb] bg-white text-sm focus:outline-none focus:border-[#0b63b6]"
          />
        </div>
        <select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
          className="py-2.5 px-3 rounded-xl border border-[#d4e1eb] bg-white text-sm font-semibold text-[#082e52] focus:outline-none cursor-pointer"
        >
          <option value="All">All Resource Types</option>
          <option value="PDF">PDF Handbooks</option>
          <option value="Dataset">Datasets & Code</option>
          <option value="Slides">Lecture Slides</option>
          <option value="Video">Recorded Sessions</option>
        </select>
      </div>

      {/* Resources Table */}
      <div className="data-table-container shadow-xs">
        <table className="data-table">
          <thead>
            <tr>
              <th>Resource Name</th>
              <th>Category</th>
              <th>Format</th>
              <th>Size</th>
              <th>Contributor</th>
              <th>Downloads</th>
              <th className="text-right">Action</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((res) => (
              <tr key={res.id}>
                <td>
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-[#f0f7ff] rounded-lg shrink-0">
                      {getIcon(res.type)}
                    </div>
                    <div>
                      <b className="text-sm text-[#082e52] block">{res.title}</b>
                      <small className="text-[#8498ac] text-[11px]">Added {res.uploadedDate}</small>
                    </div>
                  </div>
                </td>
                <td>
                  <span className="text-xs font-semibold text-[#0b63b6] bg-[#e8f5ff] px-2 py-0.5 rounded">
                    {res.category}
                  </span>
                </td>
                <td className="font-semibold text-xs text-[#506579]">{res.type}</td>
                <td className="text-xs text-[#506579]">{res.size}</td>
                <td className="text-xs text-[#506579] font-medium">{res.uploadedBy}</td>
                <td className="text-xs text-[#506579]">{res.downloads}</td>
                <td className="text-right">
                  <button
                    onClick={() => handleDownload(res)}
                    className="primary !py-1.5 !px-3 !text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <Download size={13} /> Download
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
