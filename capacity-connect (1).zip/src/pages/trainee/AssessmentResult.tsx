import React from 'react';
import { Award, CheckCircle2, RotateCcw, ArrowRight, BarChart3 } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, Assessment } from '../../types';

interface AssessmentResultProps {
  assessments: Assessment[];
  onNavigate: (page: AppPage) => void;
  onStartAssessment: (assessment: Assessment) => void;
}

export const AssessmentResult: React.FC<AssessmentResultProps> = ({
  assessments,
  onNavigate,
  onStartAssessment,
}) => {
  const completed = assessments.filter((a) => a.status === 'Completed');

  return (
    <div>
      <PageHeader
        badge="EVALUATION METRICS"
        title="Assessment Results"
        subtitle="Review your historical examination outcomes, percentile benchmarks, and certificates eligibility."
        backPage="trainee-mcq-assessments"
        onBack={onNavigate}
        actionText="View Certificates"
        actionIcon={<Award size={16} />}
        onAction={() => onNavigate('trainee-certificates')}
      />

      {/* Summary Scorecard */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-5 shadow-xs">
          <span className="text-[11px] font-bold text-[#8295a7] uppercase tracking-wider block mb-1">
            Tests Completed
          </span>
          <strong className="text-3xl font-extrabold text-[#082e52]">{completed.length}</strong>
          <span className="text-xs text-emerald-600 block mt-2 font-medium">
            100% Pass Rate
          </span>
        </div>

        <div className="bg-white border border-[#dce8f3] rounded-2xl p-5 shadow-xs">
          <span className="text-[11px] font-bold text-[#8295a7] uppercase tracking-wider block mb-1">
            Average Score
          </span>
          <strong className="text-3xl font-extrabold text-[#0b63b6]">94.2%</strong>
          <span className="text-xs text-[#66798c] block mt-2 font-medium">
            Top 5% among MoES batches
          </span>
        </div>

        <div className="bg-white border border-[#dce8f3] rounded-2xl p-5 shadow-xs">
          <span className="text-[11px] font-bold text-[#8295a7] uppercase tracking-wider block mb-1">
            Certificates Unlocked
          </span>
          <strong className="text-3xl font-extrabold text-emerald-600">2</strong>
          <span className="text-xs text-[#66798c] block mt-2 font-medium">
            Ready for instant download
          </span>
        </div>
      </div>

      {/* Results Table */}
      <div className="data-table-container shadow-xs">
        <table className="data-table">
          <thead>
            <tr>
              <th>Assessment Title</th>
              <th>Associated Course</th>
              <th>Your Score</th>
              <th>Passing Mark</th>
              <th>Status</th>
              <th className="text-right">Action</th>
            </tr>
          </thead>
          <tbody>
            {completed.map((a) => (
              <tr key={a.id}>
                <td>
                  <b className="text-sm text-[#082e52] block">{a.title}</b>
                  <small className="text-[#8498ac] text-[11px]">{a.questionCount} Questions Answered</small>
                </td>
                <td className="text-xs text-[#506579] font-medium">{a.courseTitle}</td>
                <td>
                  <b className="text-base font-extrabold text-[#0b63b6]">
                    {a.score} / {a.maxScore ?? a.totalMarks}
                  </b>
                  <span className="text-[11px] text-emerald-700 block font-semibold">
                    {Math.round(((a.score ?? 0) / (a.maxScore ?? a.totalMarks)) * 100)}%
                  </span>
                </td>
                <td className="text-xs text-[#506579]">{a.passingMarks}</td>
                <td>
                  <span className="status-pill completed">
                    <CheckCircle2 size={12} /> Passed
                  </span>
                </td>
                <td className="text-right">
                  <div className="flex justify-end gap-2">
                    <button
                      onClick={() => onStartAssessment(a)}
                      className="secondary !py-1 !px-2.5 !text-xs font-semibold inline-flex items-center gap-1 cursor-pointer"
                    >
                      <RotateCcw size={12} /> Review / Retake
                    </button>
                    <button
                      onClick={() => onNavigate('trainee-certificates')}
                      className="primary !py-1 !px-2.5 !text-xs font-bold inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Award size={12} /> Certificate
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
