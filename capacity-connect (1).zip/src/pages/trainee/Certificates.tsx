import React, { useState, useEffect } from 'react';
import { Award, Download, Eye, ShieldCheck, CheckCircle2, RefreshCw, Loader2 } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { CertificateModal } from '../../components/common/CertificateModal';
import { AppPage, Certificate } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { traineeApiService, TraineeCertificateItem } from '../../services/traineeApiService';

interface CertificatesProps {
  certificates: Certificate[];
  onNavigate: (page: AppPage) => void;
}

export const Certificates: React.FC<CertificatesProps> = ({
  certificates: fallbackCerts,
  onNavigate,
}) => {
  const { user } = useAuth();
  const [selectedCert, setSelectedCert] = useState<Certificate | null>(null);
  const [dbCerts, setDbCerts] = useState<TraineeCertificateItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isCopied, setIsCopied] = useState<string | null>(null);

  const fetchCertificates = async () => {
    setIsLoading(true);
    try {
      const email = user?.email || 'arjun.singhania@imd.gov.in';
      const result = await traineeApiService.getCertificates(email);
      if (result.certificates && result.certificates.length > 0) {
        setDbCerts(result.certificates);
      }
    } catch (err) {
      console.warn('Error fetching certificates:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchCertificates();
  }, [user?.email]);

  // Merge database certificates or map them to the Certificate modal format
  const displayCertificates: Certificate[] =
    dbCerts.length > 0
      ? dbCerts.map((dc) => ({
          id: String(dc.id),
          certificateNumber: dc.certificateNumber,
          courseTitle: dc.courseName,
          recipientName: user?.name || 'Arjun Singhania',
          recipientRole: user?.designation || 'Meteorologist Grade-I',
          issueDate: dc.issueDate,
          score: dc.score,
          grade: dc.grade,
          organization: dc.organization,
        }))
      : fallbackCerts;

  return (
    <div>
      <div className="flex items-center justify-between gap-3 mb-2">
        <PageHeader
          badge="ACCREDITATION REGISTRY"
          title="Certificates"
          subtitle="Digitally verifiable credentials awarded by Ministry of Earth Sciences for completed training programs."
          backPage="trainee-dashboard"
          onBack={onNavigate}
        />
        <button
          onClick={fetchCertificates}
          disabled={isLoading}
          className="secondary !py-2 !px-3 !text-xs cursor-pointer flex items-center gap-1.5 shrink-0"
          title="Sync certificates with database"
        >
          <RefreshCw size={13} className={isLoading ? 'animate-spin' : ''} />
          <span>Sync from Database</span>
        </button>
      </div>

      {isLoading ? (
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-12 text-center text-[#647b92] mb-8">
          <Loader2 size={32} className="animate-spin text-[#0b63b6] mx-auto mb-3" />
          <p className="text-sm font-semibold">Retrieving verified certificates from Cloud SQL...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {displayCertificates.map((cert) => (
            <div
              key={cert.id}
              className="bg-white border-2 border-[#dce8f3] hover:border-[#0b63b6] rounded-2xl p-6 transition-all shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="w-12 h-12 rounded-xl bg-[#e7f5ff] text-[#0b63b6] flex items-center justify-center">
                    <Award size={26} />
                  </div>
                  <span className="text-[10px] font-mono font-bold text-[#506579] bg-[#f0f4f8] px-2.5 py-1 rounded-md border border-[#dce5ed]">
                    {cert.certificateNumber}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-[#082e52] mb-1 leading-snug">
                  {cert.courseTitle}
                </h3>
                <p className="text-xs text-[#66798c] mb-4">
                  Awarded to: <b className="text-[#082e52]">{cert.recipientName}</b> ({cert.recipientRole})
                </p>

                <div className="grid grid-cols-3 gap-2 p-3 bg-[#f8fbfe] rounded-xl border border-[#e2edf6] text-center text-xs mb-4">
                  <div>
                    <span className="text-[10px] text-[#8295a7] uppercase font-bold block">Issue Date</span>
                    <span className="font-semibold text-[#082e52]">{cert.issueDate}</span>
                  </div>
                  <div className="border-x border-[#e2edf6]">
                    <span className="text-[10px] text-[#8295a7] uppercase font-bold block">Score</span>
                    <span className="font-extrabold text-[#0b63b6]">{cert.score}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-[#8295a7] uppercase font-bold block">Grade</span>
                    <span className="font-bold text-emerald-700">{cert.grade}</span>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-[#edf2f6] flex gap-2">
                <button
                  onClick={() => setSelectedCert(cert)}
                  className="secondary flex-1 !text-xs !py-2.5 font-bold inline-flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Eye size={14} /> View Certificate
                </button>
                <button
                  onClick={() => {
                    setIsCopied(cert.certificateNumber);
                    setTimeout(() => setIsCopied(null), 2500);
                  }}
                  className="primary flex-1 !text-xs !py-2.5 font-bold inline-flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Download size={14} />
                  <span>{isCopied === cert.certificateNumber ? 'Downloaded' : 'Download PDF'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="p-5 bg-[#e8f5ff] rounded-2xl border border-[#cbe6fa] flex items-center justify-between text-xs text-[#08427b]">
        <div className="flex items-center gap-3">
          <ShieldCheck size={24} className="text-[#0b63b6] shrink-0" />
          <span>
            <b>Verification Guarantee:</b> All CAPACITY CONNECT certificates feature cryptographic hashes registered with the MoES Central Certification Registry in PostgreSQL.
          </span>
        </div>
      </div>

      {/* Official Certificate Modal */}
      <CertificateModal
        certificate={selectedCert}
        isOpen={!!selectedCert}
        onClose={() => setSelectedCert(null)}
      />
    </div>
  );
};
