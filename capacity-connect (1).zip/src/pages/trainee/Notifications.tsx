import React, { useState, useEffect } from 'react';
import { Bell, CheckCheck, Info, CheckCircle2, AlertTriangle, Clock, RefreshCw, Loader2 } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage, NotificationItem } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { traineeApiService, TraineeNotificationItem } from '../../services/traineeApiService';

interface NotificationsProps {
  notifications: NotificationItem[];
  onNavigate: (page: AppPage) => void;
  onMarkAllRead: () => void;
  onToggleRead: (id: string) => void;
}

export const Notifications: React.FC<NotificationsProps> = ({
  notifications: fallbackNotifications,
  onNavigate,
  onMarkAllRead,
  onToggleRead,
}) => {
  const { user } = useAuth();
  const [dbNotifs, setDbNotifs] = useState<TraineeNotificationItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const fetchNotifications = async () => {
    setIsLoading(true);
    try {
      const email = user?.email || 'arjun.singhania@imd.gov.in';
      const result = await traineeApiService.getNotifications(email);
      if (result.notifications && result.notifications.length > 0) {
        setDbNotifs(result.notifications);
      }
    } catch (err) {
      console.warn('Error fetching notifications:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchNotifications();
  }, [user?.email]);

  const handleMarkRead = async (id: number) => {
    setDbNotifs((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
    await traineeApiService.markNotificationRead(id, user?.email);
  };

  const handleMarkAll = async () => {
    setDbNotifs((prev) => prev.map((n) => ({ ...n, read: true })));
    for (const n of dbNotifs.filter((item) => !item.read)) {
      await traineeApiService.markNotificationRead(n.id, user?.email);
    }
    onMarkAllRead();
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'success':
        return <CheckCircle2 size={18} className="text-emerald-500" />;
      case 'alert':
      case 'warning':
        return <AlertTriangle size={18} className="text-amber-500" />;
      default:
        return <Info size={18} className="text-[#0b63b6]" />;
    }
  };

  const items =
    dbNotifs.length > 0
      ? dbNotifs.map((d) => ({
          id: String(d.id),
          numericId: d.id,
          title: d.title,
          message: d.message,
          type: (d.type as any) || 'info',
          displayTime: d.date,
          read: d.read,
        }))
      : fallbackNotifications.map((f) => ({
          ...f,
          numericId: 0,
          displayTime: f.time,
        }));

  return (
    <div>
      <div className="flex items-center justify-between gap-3 mb-2">
        <PageHeader
          badge="REAL-TIME BROADCAST"
          title="Notifications"
          subtitle="Operational announcements, grading notifications, and curriculum updates stored in PostgreSQL."
          backPage="trainee-dashboard"
          onBack={onNavigate}
          actionText="Mark All as Read"
          actionIcon={<CheckCheck size={16} />}
          onAction={handleMarkAll}
        />
        <button
          onClick={fetchNotifications}
          disabled={isLoading}
          className="secondary !py-2 !px-3 !text-xs cursor-pointer flex items-center gap-1.5 shrink-0"
          title="Refresh notifications"
        >
          <RefreshCw size={13} className={isLoading ? 'animate-spin' : ''} />
          <span>Refresh</span>
        </button>
      </div>

      {isLoading ? (
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-12 text-center text-[#647b92] max-w-3xl">
          <Loader2 size={32} className="animate-spin text-[#0b63b6] mx-auto mb-3" />
          <p className="text-sm font-semibold">Retrieving trainee notifications from Cloud SQL...</p>
        </div>
      ) : (
        <div className="space-y-3 max-w-3xl">
          {items.map((n) => (
            <div
              key={n.id}
              onClick={() => {
                if (n.numericId) {
                  handleMarkRead(n.numericId);
                } else {
                  onToggleRead(n.id);
                }
              }}
              className={`p-4 rounded-xl border transition-all flex items-start gap-3.5 cursor-pointer ${
                !n.read
                  ? 'bg-white border-[#0b63b6]/40 shadow-xs ring-1 ring-[#0b63b6]/20'
                  : 'bg-[#fafcff] border-[#e2edf6] opacity-80'
              }`}
            >
              <div className="mt-0.5 shrink-0">{getIcon(n.type)}</div>
              <div className="flex-1">
                <div className="flex items-center justify-between gap-2 mb-1">
                  <h4
                    className={`text-sm m-0 ${
                      !n.read ? 'font-bold text-[#082e52]' : 'font-medium text-[#486075]'
                    }`}
                  >
                    {n.title}
                  </h4>
                  <span className="text-[10px] text-[#869ab0] flex items-center gap-1 shrink-0">
                    <Clock size={11} /> {n.displayTime}
                  </span>
                </div>
                <p className="text-xs text-[#506579] m-0 leading-relaxed">{n.message}</p>
              </div>
              {!n.read && (
                <span className="w-2 h-2 rounded-full bg-[#0b63b6] shrink-0 mt-2" />
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
