import React, { useState } from 'react';
import { Settings as SettingsIcon, Bell, Shield, Lock, Eye, CheckCircle2 } from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { AppPage } from '../../types';

interface SettingsProps {
  onNavigate: (page: AppPage) => void;
}

export const Settings: React.FC<SettingsProps> = ({ onNavigate }) => {
  const [emailAlerts, setEmailAlerts] = useState(true);
  const [assessmentReminders, setAssessmentReminders] = useState(true);
  const [weeklyDigest, setWeeklyDigest] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  return (
    <div>
      <PageHeader
        badge="PREFERENCES"
        title="Settings"
        subtitle="Manage your learning preferences, notification alerts, and security credentials."
        backPage="trainee-dashboard"
        onBack={onNavigate}
      />

      {isSaved && (
        <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-semibold flex items-center gap-2">
          <CheckCircle2 size={18} className="text-emerald-600" />
          <span>Your preferences have been saved successfully.</span>
        </div>
      )}

      <div className="max-w-3xl space-y-6">
        {/* Notification preferences */}
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs">
          <h3 className="text-base font-bold text-[#082e52] mb-4 flex items-center gap-2">
            <Bell size={18} className="text-[#0b63b6]" /> Notification Channels
          </h3>

          <div className="space-y-4">
            <label className="flex items-center justify-between p-3 rounded-xl border border-[#edf3f8] hover:bg-[#fafcff] cursor-pointer">
              <div>
                <b className="text-sm text-[#082e52] block">Assessment Deadlines & Reminders</b>
                <span className="text-xs text-[#66798c]">
                  Get alerted 48 hours before examination windows close.
                </span>
              </div>
              <input
                type="checkbox"
                checked={assessmentReminders}
                onChange={(e) => setAssessmentReminders(e.target.checked)}
                className="w-4 h-4 accent-[#0b63b6] cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-xl border border-[#edf3f8] hover:bg-[#fafcff] cursor-pointer">
              <div>
                <b className="text-sm text-[#082e52] block">Official MoES Email Circulars</b>
                <span className="text-xs text-[#66798c]">
                  Receive new syllabus releases directly in your official IMD inbox.
                </span>
              </div>
              <input
                type="checkbox"
                checked={emailAlerts}
                onChange={(e) => setEmailAlerts(e.target.checked)}
                className="w-4 h-4 accent-[#0b63b6] cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-xl border border-[#edf3f8] hover:bg-[#fafcff] cursor-pointer">
              <div>
                <b className="text-sm text-[#082e52] block">Weekly Learning Digest</b>
                <span className="text-xs text-[#66798c]">
                  Summary of your study hours, completed modules, and upcoming webinars.
                </span>
              </div>
              <input
                type="checkbox"
                checked={weeklyDigest}
                onChange={(e) => setWeeklyDigest(e.target.checked)}
                className="w-4 h-4 accent-[#0b63b6] cursor-pointer"
              />
            </label>
          </div>
        </div>

        {/* Security & Credentials */}
        <div className="bg-white border border-[#dce8f3] rounded-2xl p-6 shadow-xs">
          <h3 className="text-base font-bold text-[#082e52] mb-4 flex items-center gap-2">
            <Lock size={18} className="text-[#0b63b6]" /> Password & Credentials
          </h3>

          <form onSubmit={handleSave} className="space-y-4">
            <div>
              <label className="text-xs font-bold text-[#3d546a] block mb-1">Current Password</label>
              <input
                type="password"
                placeholder="Enter current password"
                className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-[#3d546a] block mb-1">New Password</label>
                <input
                  type="password"
                  placeholder="Min. 8 characters"
                  className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-[#3d546a] block mb-1">Confirm New Password</label>
                <input
                  type="password"
                  placeholder="Repeat new password"
                  className="w-full p-2.5 rounded-xl border border-[#d4e1eb] bg-[#fbfdff] text-sm text-[#082e52] focus:outline-none focus:border-[#0b63b6]"
                />
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                className="primary text-xs font-bold py-2.5 px-5 cursor-pointer"
              >
                Update Security Credentials
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
