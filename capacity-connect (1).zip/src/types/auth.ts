import { AppPage, UserRole } from './index';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone?: string;
  role: UserRole;
  department?: string;
  designation?: string;
  qualification?: string;
  workExperience?: string;
  skills?: string[];
  interests?: string[];
  expertise?: string[];
  subjects?: string[];
  avatarUrl?: string;
  registeredAt?: string;
}

export interface AuthContextType {
  user: UserProfile | null;
  role: UserRole | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string, role: UserRole, rememberMe?: boolean) => Promise<{ success: boolean; error?: string }>;
  signup: (userData: SignupPayload) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  updateProfile: (updatedData: Partial<UserProfile>) => void;
}

export interface SignupPayload {
  name: string;
  email: string;
  phone: string;
  password: string;
  confirmPassword: string;
  role: UserRole;
  department?: string;
  // Trainee specific
  qualification?: string;
  workExperience?: string;
  skills?: string;
  interests?: string;
  // Trainer specific
  expertise?: string;
  subjects?: string;
}
