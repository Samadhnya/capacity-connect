export type UserRole = 'Trainee' | 'Trainer' | 'Admin';

export type PublicPage = 
  | 'home'
  | 'about'
  | 'features'
  | 'courses'
  | 'login'
  | 'signup'
  | 'forgot-password';

export type TraineePage =
  | 'trainee-dashboard'
  | 'trainee-profile'
  | 'trainee-explore-courses'
  | 'trainee-my-courses'
  | 'trainee-course-details'
  | 'trainee-learning-resources'
  | 'trainee-mcq-assessments'
  | 'trainee-assessment-result'
  | 'trainee-progress-tracking'
  | 'trainee-certificates'
  | 'trainee-feedback'
  | 'trainee-notifications'
  | 'trainee-settings';

export type TrainerPage =
  | 'trainer-dashboard'
  | 'trainer-profile'
  | 'trainer-my-courses'
  | 'trainer-create-course'
  | 'trainer-edit-course'
  | 'trainer-questionnaires'
  | 'trainer-create-assessment'
  | 'trainer-trainees'
  | 'trainer-trainee-performance'
  | 'trainer-library'
  | 'trainer-upload-material'
  | 'trainer-notifications'
  | 'trainer-settings';

export type AdminPage =
  | 'admin-dashboard'
  | 'admin-users'
  | 'admin-trainees'
  | 'admin-trainers'
  | 'admin-courses'
  | 'admin-enrollments'
  | 'admin-assessments'
  | 'admin-certifications'
  | 'admin-competency-mapping'
  | 'admin-notifications'
  | 'admin-announcements'
  | 'admin-analytics'
  | 'admin-settings';

export type AppPage = PublicPage | TraineePage | TrainerPage | AdminPage;

export interface Course {
  id: string;
  title: string;
  trainer: string;
  trainerRole?: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  duration: string;
  category: string;
  description: string;
  enrolledCount: number;
  rating: number;
  modulesCount: number;
  syllabus: { title: string; duration: string; completed?: boolean }[];
  progress?: number;
  isEnrolled?: boolean;
}

export interface Resource {
  id: string;
  title: string;
  type: 'PDF' | 'Video' | 'Slides' | 'Dataset';
  size: string;
  category: string;
  uploadedBy: string;
  uploadedDate: string;
  downloads: number;
}

export interface Question {
  id: number;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface Assessment {
  id: string;
  title: string;
  courseId: string;
  courseTitle: string;
  durationMinutes: number;
  totalMarks: number;
  passingMarks: number;
  questionCount: number;
  status: 'Available' | 'Completed' | 'Pending';
  score?: number;
  maxScore?: number;
  questions: Question[];
}

export interface Certificate {
  id: string;
  certificateNumber: string;
  courseTitle: string;
  recipientName: string;
  recipientRole: string;
  issueDate: string;
  score: string;
  grade: string;
  organization: string;
}

export interface TraineeUser {
  id: string;
  name: string;
  email: string;
  department: string;
  division: string;
  enrolledCoursesCount: number;
  completedCoursesCount: number;
  avgScore: number;
  status: 'Active' | 'On Leave' | 'Inactive';
}

export interface TrainerUser {
  id: string;
  name: string;
  email: string;
  designation: string;
  specialization: string;
  coursesCount: number;
  traineesCount: number;
  rating: number;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  read: boolean;
  type: 'info' | 'success' | 'alert' | 'update';
}

export interface AnnouncementItem {
  id: string;
  title: string;
  body: string;
  date: string;
  author: string;
  targetRole: 'All' | 'Trainee' | 'Trainer';
  priority: 'High' | 'Normal';
}

export interface CompetencySkill {
  id: string;
  skillName: string;
  category: string;
  targetProficiency: number;
  currentWorkforceAverage: number;
  certifiedPersonnel: number;
  trainersAvailable: number;
}
